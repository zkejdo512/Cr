from __future__ import annotations

from dataclasses import dataclass
import random
from typing import Sequence
import torch

from .action_codec import NUM_ACTIONS, encode_action
from .contracts import PlayerObservationV1, TransitionV1
from .envs.toy_duel import ToyDuelEnv, ToyConfig
from .opponent_codec import OpponentActionBatch, encode_observed_action
from .tensorizer import BattleTensorizer
from .vocab import CardVocabulary


@dataclass
class TransitionTensorBatch:
    state: object
    next_state: object
    own_action: torch.Tensor
    opp_action: OpponentActionBatch
    reward: torch.Tensor
    done: torch.Tensor
    dt_s: torch.Tensor
    opp_action_known: torch.Tensor
    legal_mask: torch.Tensor
    next_legal_mask: torch.Tensor
    legal_mask_known: torch.Tensor
    next_legal_mask_known: torch.Tensor
    return_target: torch.Tensor | None = None

    def to(self, device):
        self.state = self.state.to(device); self.next_state = self.next_state.to(device)
        self.opp_action = self.opp_action.to(device)
        for k in ("own_action", "reward", "done", "dt_s", "opp_action_known",
                  "legal_mask", "next_legal_mask", "legal_mask_known", "next_legal_mask_known"):
            setattr(self, k, getattr(self, k).to(device))
        if self.return_target is not None:
            self.return_target = self.return_target.to(device)
        return self


def _state_card_ids(s: PlayerObservationV1):
    for c in s.hand: yield c.card_id
    if s.next_card is not None: yield s.next_card.card_id
    for ev in s.recent_events:
        if ev.card_id >= 0: yield ev.card_id


def _state_entity_ids(s: PlayerObservationV1):
    for e in s.entities:
        if e.card_id >= 0: yield e.card_id


def build_card_vocab(transitions: Sequence[TransitionV1]) -> CardVocabulary:
    """Vocabulary for playable/deployed card identities, never entity species."""
    ids = []
    for tr in transitions:
        ids.extend(_state_card_ids(tr.state)); ids.extend(_state_card_ids(tr.next_state))
        if not tr.opponent_action.is_pass:
            ids.append(int(tr.opponent_action.card_id))
    return CardVocabulary.from_card_ids(ids)


def build_entity_vocab(transitions: Sequence[TransitionV1]) -> CardVocabulary:
    """Separate vocabulary for battlefield entity/species identities.

    Spawned forms (Skeleton, Golemite, temporary hero forms, etc.) are not
    necessarily playable cards and must not collapse to the card UNK token.
    """
    ids=[]
    for tr in transitions:
        ids.extend(_state_entity_ids(tr.state)); ids.extend(_state_entity_ids(tr.next_state))
    return CardVocabulary.from_card_ids(ids)


def _mask_from_indices(indices):
    if indices is None:
        # Fail closed. Unknown legality must never silently mean 'everything is legal',
        # especially now that ability actions exist. Callers that need a target
        # action must reconstruct legality first.
        mask = torch.zeros(NUM_ACTIONS, dtype=torch.bool)
        mask[0] = True
        return mask, False
    mask = torch.zeros(NUM_ACTIONS, dtype=torch.bool)
    for idx in indices:
        if not 0 <= int(idx) < NUM_ACTIONS: raise ValueError(f"bad action index {idx}")
        mask[int(idx)] = True
    mask[0] = True
    return mask, True


def discounted_return_targets(transitions: Sequence[TransitionV1], gamma: float = 0.997,
                              base_dt_s: float = 0.5):
    """Time-aware discounted returns.

    `gamma` is defined for one `base_dt_s` decision interval. This matters for
    real/replay data where decision spacing may differ from Hasty's 500 ms.
    """
    if not (0.0 < gamma <= 1.0) or base_dt_s <= 0:
        raise ValueError('invalid gamma/base_dt_s')
    out = [0.0] * len(transitions); acc = 0.0
    for i in reversed(range(len(transitions))):
        tr=transitions[i]
        dt=float(tr.next_state.t_s-tr.state.t_s)
        if dt <= 0:
            raise ValueError(f'non-positive transition dt at {i}: {dt}')
        if tr.done: acc = 0.0
        discount = gamma ** (dt / base_dt_s)
        acc = float(tr.reward) + discount * acc
        out[i] = acc
    return out


def collect_toy_expert(episodes=50, seed=0):
    env = ToyDuelEnv(ToyConfig(seed=seed)); out = []
    for ep in range(episodes):
        s = env.reset(habit=ep % 2); done = False
        while not done:
            legal = tuple(env.legal_action_indices()); a = env.expert_action(); oa = env.opponent_action()
            ns, r, done, _ = env.step(a, oa)
            out.append(TransitionV1(s, a, oa, r, ns, done, True, legal, tuple(env.legal_action_indices())))
            s = ns
    return out


def sample_transition_batch(transitions, tensorizer, batch_size=32, rng=None, return_targets=None):
    if not transitions: raise ValueError("empty transition set")
    rng = rng or random; n = min(batch_size, len(transitions)); idxs = rng.sample(range(len(transitions)), n)
    xs = [transitions[i] for i in idxs]
    legal_pairs = [_mask_from_indices(x.legal_action_indices) for x in xs]
    next_pairs = [_mask_from_indices(x.next_legal_action_indices) for x in xs]
    dt = [float(x.next_state.t_s - x.state.t_s) for x in xs]
    if any(d <= 0 for d in dt): raise ValueError(f"non-positive dt {dt}")
    enc_opp = [encode_observed_action(x.opponent_action, tensorizer.vocab) for x in xs]
    rt = None if return_targets is None else torch.tensor([return_targets[i] for i in idxs], dtype=torch.float32)
    return TransitionTensorBatch(
        tensorizer.batch([x.state for x in xs]), tensorizer.batch([x.next_state for x in xs]),
        torch.tensor([encode_action(x.action) for x in xs], dtype=torch.long),
        OpponentActionBatch(torch.tensor([x[0] for x in enc_opp], dtype=torch.long),
                            torch.tensor([x[1] for x in enc_opp], dtype=torch.long),
                            torch.tensor([x[2] for x in enc_opp], dtype=torch.long)),
        torch.tensor([x.reward for x in xs], dtype=torch.float32), torch.tensor([x.done for x in xs], dtype=torch.bool),
        torch.tensor(dt), torch.tensor([x.opponent_action_known for x in xs], dtype=torch.bool),
        torch.stack([x[0] for x in legal_pairs]), torch.stack([x[0] for x in next_pairs]),
        torch.tensor([x[1] for x in legal_pairs]), torch.tensor([x[1] for x in next_pairs]), rt)
