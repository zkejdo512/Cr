from __future__ import annotations
from dataclasses import dataclass,asdict
from crgod.action_codec import NUM_ACTIONS
from crgod.contracts import OBSERVATION_SCHEMA_VERSION
from crgod.vocab import CardVocabulary


@dataclass(frozen=True)
class RuntimeContractV4:
    observation_schema:str
    action_count:int
    card_vocab_fingerprint:str
    entity_vocab_fingerprint:str
    simulator_fingerprint:str
    model_family:str='crgod-v4'
    trainer_schema:str='4.0'

    @classmethod
    def build(cls,card_vocab:CardVocabulary,entity_vocab:CardVocabulary,simulator_fingerprint:str,
              *,model_family:str='crgod-v4',trainer_schema:str='4.0'):
        if not simulator_fingerprint:raise ValueError('simulator_fingerprint is required')
        return cls(OBSERVATION_SCHEMA_VERSION,NUM_ACTIONS,card_vocab.fingerprint(),entity_vocab.fingerprint(),
                   str(simulator_fingerprint),str(model_family),str(trainer_schema))
    def metadata(self)->dict:return {'runtime_contract_v4':asdict(self)}


def assert_checkpoint_compatible_v4(metadata:dict,card_vocab:CardVocabulary,entity_vocab:CardVocabulary,
                                    simulator_fingerprint:str,*,model_family:str='crgod-v4',trainer_schema:str='4.0'):
    raw=(metadata or {}).get('runtime_contract_v4')
    if not isinstance(raw,dict):raise RuntimeError('checkpoint has no v4 runtime contract')
    want=RuntimeContractV4.build(card_vocab,entity_vocab,simulator_fingerprint,model_family=model_family,trainer_schema=trainer_schema)
    try:got=RuntimeContractV4(**raw)
    except Exception as e:raise RuntimeError(f'invalid v4 runtime contract: {e}') from e
    errors=[]
    for field in RuntimeContractV4.__dataclass_fields__:
        if getattr(got,field)!=getattr(want,field):errors.append(f'{field} mismatch')
    if errors:raise RuntimeError('checkpoint/runtime contract mismatch: '+'; '.join(errors))
    return got
