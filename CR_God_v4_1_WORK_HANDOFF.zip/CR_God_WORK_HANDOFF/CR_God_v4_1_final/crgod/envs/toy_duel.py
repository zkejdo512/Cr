from __future__ import annotations

from dataclasses import dataclass
import random
from crgod.action_codec import encode_action
from crgod.contracts import (
    ActionV2, CardRef, DeploymentEvent, TowerState, ObservedOpponentActionV1,
    TrueBattleStateV1, to_player_observation, OBSERVATION_SCHEMA_VERSION,
)


@dataclass
class ToyConfig:
    horizon: int = 60
    seed: int = 0


class ToyDuelEnv:
    """POMDP smoke-test environment. It is not a CR simulator."""
    def __init__(self, cfg: ToyConfig = ToyConfig()):
        self.cfg = cfg
        self.rng = random.Random(cfg.seed)
        self.reset()

    def reset(self, habit: int | None = None):
        self.t = 0
        self.habit = self.rng.randrange(2) if habit is None else int(habit)
        self.events = []
        self.own_hp = [1.0, 1.0, 1.0]
        self.opp_hp = [1.0, 1.0, 1.0]
        return self.state()

    @staticmethod
    def _towers(team, hp):
        return tuple(TowerState(team, lane, h, h > 0, x, y, max_hp=1.0,
                                active=(lane != 'king'))
                     for lane, h, x, y in [
                         ('left', hp[0], .25, .18 if team == 'self' else .82),
                         ('right', hp[1], .75, .18 if team == 'self' else .82),
                         ('king', hp[2], .50, .08 if team == 'self' else .92),
                     ])

    def true_state(self):
        own_hand = tuple(CardRef(i, i, f'toy-{i}') for i in range(4))
        # Deliberately different hidden opponent hand/elixir so leakage tests
        # can prove policy observations cannot access them.
        opp_hand = tuple(CardRef(100+i, i, f'hidden-{i}') for i in range(4))
        return TrueBattleStateV1(
            OBSERVATION_SCHEMA_VERSION, float(self.t), min(10.0, 4.0 + self.t * .2), 9.25,
            self._towers('self', self.own_hp), self._towers('opponent', self.opp_hp),
            own_hand, CardRef(4, 4, 'toy-next'),
            opp_hand, CardRef(104, 4, 'hidden-next'),
            (), tuple(self.events[-16:]), 'toy')

    def state(self):
        return to_player_observation(self.true_state(), 'self')

    @staticmethod
    def _lane_action(slot: int, lane: int, y: float):
        return ActionV2.play_card(slot, .25 if lane == 0 else .75, y)

    def legal_action_indices(self):
        yield 0
        for slot in range(4):
            for lane in (0, 1):
                yield encode_action(self._lane_action(slot, lane, .30))
        # Toy env has no hero; all 16 ability buttons stay illegal.

    def opponent_action(self):
        lane = self.habit if self.rng.random() < .82 else 1 - self.habit
        return ObservedOpponentActionV1(0, .25 if lane == 0 else .75, .78)

    def expert_action(self):
        left = sum(ev.team == 'opponent' and ev.x is not None and ev.x < .5 for ev in self.events[-8:])
        right = sum(ev.team == 'opponent' and ev.x is not None and ev.x >= .5 for ev in self.events[-8:])
        lane = 0 if left >= right else 1
        return self._lane_action(1, lane, .30)

    @staticmethod
    def _lane(a):
        if getattr(a, 'is_pass', False):
            return None
        return 0 if a.x < .5 else 1

    def step(self, own: ActionV2, opp: ObservedOpponentActionV1 | None = None):
        if encode_action(own) not in set(self.legal_action_indices()):
            raise ValueError('toy own action is illegal')
        opp = self.opponent_action() if opp is None else opp
        self.events.append(DeploymentEvent(self.t, 'self', 1 if not own.is_pass else -1, own.x, own.y))
        self.events.append(DeploymentEvent(self.t, 'opponent', -1 if opp.is_pass else int(opp.card_id), opp.x, opp.y))
        own_lane, opp_lane = self._lane(own), self._lane(opp)
        reward = 0.0
        if own_lane is not None and opp_lane is not None:
            if own_lane == opp_lane:
                reward += .08
                self.opp_hp[opp_lane] = max(0.0, self.opp_hp[opp_lane] - .018)
            else:
                reward -= .08
                self.own_hp[opp_lane] = max(0.0, self.own_hp[opp_lane] - .018)
        self.t += 1
        done = self.t >= self.cfg.horizon
        if done:
            reward += (sum(self.own_hp) - sum(self.opp_hp)) * .5
        return self.state(), reward, done, {'habit': self.habit}
