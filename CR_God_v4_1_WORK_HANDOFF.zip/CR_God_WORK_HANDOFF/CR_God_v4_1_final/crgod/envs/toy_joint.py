from __future__ import annotations

from dataclasses import dataclass
import random

from crgod.action_codec import decode_action, encode_action
from crgod.contracts import (
    ActionV2, CardRef, DeploymentEvent, ObservedOpponentActionV1, TowerState,
    TrueBattleStateV1, to_player_observation, OBSERVATION_SCHEMA_VERSION,
)
from crgod.sim_protocol import JointFrame, JointStepResult, RewardComponents, SeatFrame


@dataclass(frozen=True)
class ToyJointConfig:
    horizon: int = 24
    decision_interval_s: float = .5


class ToyJointSimulator:
    """Tiny simultaneous POMDP used only to validate the training stack."""
    simulator_id='toy-joint-v1'
    def __init__(self,cfg:ToyJointConfig=ToyJointConfig()):
        self.cfg=cfg; self.decision_interval_s=cfg.decision_interval_s; self.rng=random.Random(0)

    def _towers(self,team,hp):
        y=.16 if team=='self' else .84
        return tuple(TowerState(team,lane,h,h>0,x,y if lane!='king' else (.08 if team=='self' else .92),1.0,lane!='king')
                     for lane,h,x in [('left',hp[0],.25),('right',hp[1],.75),('king',hp[2],.50)])

    def _true(self):
        a_hand=tuple(CardRef(10+i,i,f'A{i}') for i in range(4)); b_hand=tuple(CardRef(20+i,i,f'B{i}') for i in range(4))
        return TrueBattleStateV1(OBSERVATION_SCHEMA_VERSION,self.t*self.decision_interval_s,
                                  10.0,10.0,self._towers('self',self.hp_a),self._towers('opponent',self.hp_b),
                                  a_hand,CardRef(14,4,'A4'),b_hand,CardRef(24,4,'B4'),(),tuple(self.events[-16:]),'toy')

    @staticmethod
    def _legal():
        out=[0]
        for slot in range(4):
            out.append(encode_action(ActionV2.play_card(slot,.25,.30)))
            out.append(encode_action(ActionV2.play_card(slot,.75,.30)))
        return tuple(out)

    def _frame(self):
        true=self._true(); legal=self._legal()
        f=JointFrame(SeatFrame(to_player_observation(true,'self'),legal),SeatFrame(to_player_observation(true,'opponent'),legal),
                     true.t_s,true,{'toy':True}); f.validate(); return f

    def reset(self,*,seed=None,matchup=None):
        self.rng=random.Random(0 if seed is None else seed); self.t=0; self.hp_a=[1.,1.,1.]; self.hp_b=[1.,1.,1.]; self.events=[]
        return self._frame()

    @staticmethod
    def _lane(a):
        if a.is_pass or a.is_ability:return None
        return 0 if a.x<.5 else 1

    def _observed(self,action:ActionV2,own_hand,rotate:bool):
        if action.is_pass:return ObservedOpponentActionV1.pass_action()
        if action.is_ability:return ObservedOpponentActionV1.activate_ability(own_hand[0].card_id)
        card_id=own_hand[action.slot].card_id; x=float(action.x); y=float(action.y)
        if rotate:x,y=1-x,1-y
        return ObservedOpponentActionV1.play_card(card_id,x,y)

    def step(self,action_a_index:int,action_b_index:int):
        legal=set(self._legal())
        if action_a_index not in legal or action_b_index not in legal: raise ValueError('toy joint illegal action')
        true_before=self._true(); aa=decode_action(action_a_index); ab=decode_action(action_b_index)
        la,lb=self._lane(aa),self._lane(ab); dmg_a=dmg_b=0.
        if la is not None and la!=lb: self.hp_b[la]=max(0.,self.hp_b[la]-.04); dmg_b=.04
        if lb is not None and lb!=la: self.hp_a[lb]=max(0.,self.hp_a[lb]-.04); dmg_a=.04
        if la is not None:self.events.append(DeploymentEvent(true_before.t_s,'self',true_before.self_hand[aa.slot].card_id,aa.x,aa.y))
        if lb is not None:
            # store B deployment in global A frame
            self.events.append(DeploymentEvent(true_before.t_s,'opponent',true_before.opponent_hand[ab.slot].card_id,1-ab.x,1-ab.y))
        self.t+=1; done=self.t>=self.cfg.horizon or min(self.hp_a[:2])<=0 or min(self.hp_b[:2])<=0
        score_a=sum(self.hp_a)-sum(self.hp_b); terminal=0.
        outcome=None
        if done:
            outcome=1. if score_a>1e-9 else 0. if score_a<-1e-9 else .5
            terminal=(outcome-.5)*2.0
        reward_a=terminal + (dmg_b-dmg_a); reward_b=-terminal + (dmg_a-dmg_b)
        nextf=self._frame(); oa=self._observed(aa,true_before.self_hand,rotate=True); ob=self._observed(ab,true_before.opponent_hand,rotate=True)
        res=JointStepResult(nextf,reward_a,reward_b,done,oa,ob,True,True,self.decision_interval_s,outcome,
                            RewardComponents(terminal=terminal,tower_damage=dmg_b-dmg_a),
                            RewardComponents(terminal=-terminal,tower_damage=dmg_a-dmg_b),{'toy':True})
        res.validate(); return res


def make_toy_training_simulator():
    """Factory used by end-to-end trainer/preflight tests."""
    return ToyJointSimulator(ToyJointConfig())
