from __future__ import annotations

from dataclasses import dataclass, field
import random


@dataclass
class CheckpointEntry:
    name: str
    path: str
    elo: float = 1000.0
    games: int = 0


@dataclass
class OpponentLeague:
    """Small AlphaStar-style checkpoint pool.

    Sampling mixes similarly-rated checkpoints with random historical policies,
    reducing the risk of overfitting one frozen opponent.
    """
    entries: list[CheckpointEntry] = field(default_factory=list)

    def add(self, entry: CheckpointEntry) -> None:
        self.entries.append(entry)

    def sample(self, current_elo: float, temperature: float = 250.0) -> CheckpointEntry:
        if not self.entries:
            raise RuntimeError("league is empty")
        if random.random() < 0.2:
            return random.choice(self.entries)
        weights = [pow(2.718281828, -abs(e.elo - current_elo) / temperature) for e in self.entries]
        return random.choices(self.entries, weights=weights, k=1)[0]

    @staticmethod
    def update_elo(a: CheckpointEntry, b: CheckpointEntry, score_a: float, k: float = 24.0):
        expected_a = 1.0 / (1.0 + 10 ** ((b.elo - a.elo) / 400.0))
        delta = k * (score_a - expected_a)
        a.elo += delta; b.elo -= delta
        a.games += 1; b.games += 1
