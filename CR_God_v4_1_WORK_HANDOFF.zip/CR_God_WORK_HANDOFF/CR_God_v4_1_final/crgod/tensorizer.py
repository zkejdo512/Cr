from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable
import math
import torch

from .contracts import PlayerObservationV1, TrueBattleStateV1, OBSERVATION_SCHEMA_VERSION
from .vocab import CardVocabulary

TEAM_TO_ID = {"self": 0, "opponent": 1}
KIND_TO_ID = {"troop": 0, "building": 1, "projectile": 2, "other": 3}
SOURCE_TO_ID = {"sim": 0, "memory": 1, "vision": 2, "replay": 3, "toy": 4}


@dataclass
class TensorBatch:
    global_features: torch.Tensor
    hand_ids: torch.Tensor
    entity_card_ids: torch.Tensor
    entity_team_ids: torch.Tensor
    entity_kind_ids: torch.Tensor
    entity_features: torch.Tensor
    entity_mask: torch.Tensor
    event_card_ids: torch.Tensor
    event_team_ids: torch.Tensor
    event_features: torch.Tensor
    event_mask: torch.Tensor
    source_ids: torch.Tensor

    def to(self, device):
        return TensorBatch(**{k: v.to(device) for k, v in self.__dict__.items()})


class BattleTensorizer:
    def __init__(self, vocab: CardVocabulary, max_entities: int = 64, max_events: int = 32,
                 entity_vocab: CardVocabulary | None = None):
        # Card identities (hand/history/opponent actions) and battlefield entity
        # identities are intentionally separate namespaces. Spawned/temporary
        # units such as Golemites or Skeletons are not necessarily playable cards.
        self.vocab = vocab
        self.entity_vocab = entity_vocab if entity_vocab is not None else vocab
        self.max_entities = max_entities
        self.max_events = max_events

    @staticmethod
    def _norm_hp(hp: float | None, max_hp: float | None) -> tuple[float, float]:
        if hp is None or not math.isfinite(float(hp)):
            return 0.0, 0.0
        hp = max(0.0, float(hp))
        if max_hp is not None and math.isfinite(float(max_hp)) and max_hp > 0:
            return min(hp / float(max_hp), 1.5), 1.0
        return min(math.log1p(hp) / math.log1p(10000.0), 1.5), 1.0

    @classmethod
    def _tower_features(cls, towers) -> list[float]:
        by_lane = {t.lane: t for t in towers}
        out = []
        for lane in ("left", "right", "king"):
            t = by_lane.get(lane)
            if t is None:
                out.extend([0.0, 0.0, 0.0])
                continue
            hp, known = cls._norm_hp(t.hp, t.max_hp)
            active = 1.0 if (t.active is True or (t.active is None and lane != "king")) else 0.0
            out.extend([hp, known, active])
        return out

    def one(self, s: PlayerObservationV1) -> TensorBatch:
        if isinstance(s, TrueBattleStateV1):
            raise TypeError('policy tensorizer refuses privileged TrueBattleStateV1')
        return self.batch([s])

    def batch(self, states: Iterable[PlayerObservationV1]) -> TensorBatch:
        states = list(states)
        if any(isinstance(s, TrueBattleStateV1) for s in states):
            raise TypeError('policy tensorizer refuses privileged TrueBattleStateV1')
        if not states:
            raise ValueError("cannot tensorize empty batch")
        b = len(states)
        g = torch.zeros(b, 21)
        hand = torch.zeros(b, 5, dtype=torch.long)
        e_card = torch.zeros(b, self.max_entities, dtype=torch.long)
        e_team = torch.zeros(b, self.max_entities, dtype=torch.long)
        e_kind = torch.zeros(b, self.max_entities, dtype=torch.long)
        e_feat = torch.zeros(b, self.max_entities, 9)
        e_mask = torch.zeros(b, self.max_entities, dtype=torch.bool)
        h_card = torch.zeros(b, self.max_events, dtype=torch.long)
        h_team = torch.zeros(b, self.max_events, dtype=torch.long)
        h_feat = torch.zeros(b, self.max_events, 3)
        h_mask = torch.zeros(b, self.max_events, dtype=torch.bool)
        source_ids = torch.zeros(b, dtype=torch.long)

        for i, s in enumerate(states):
            if s.version != OBSERVATION_SCHEMA_VERSION:
                raise ValueError(f"unsupported observation schema {s.version}; expected {OBSERVATION_SCHEMA_VERSION}")
            g[i] = torch.tensor([
                min(max(s.t_s / 300.0, 0.0), 1.5),
                min(max(s.own_elixir / 10.0, 0.0), 1.0),
                *self._tower_features(s.own_towers),
                *self._tower_features(s.opponent_towers),
                min(len(s.entities) / max(self.max_entities, 1), 1.0),
            ])
            source_ids[i] = SOURCE_TO_ID[s.source]
            ids = [self.vocab.encode(c.card_id) for c in s.hand]
            ids.append(self.vocab.encode(s.next_card.card_id if s.next_card else None))
            hand[i] = torch.tensor(ids)

            entities = sorted(s.entities, key=lambda x: (-x.confidence, x.track_id))[:self.max_entities]
            for j, ent in enumerate(entities):
                if not (math.isfinite(ent.x) and math.isfinite(ent.y)):
                    continue
                e_mask[i, j] = True
                e_card[i, j] = self.entity_vocab.encode(ent.card_id)
                e_team[i, j] = TEAM_TO_ID[ent.team]
                e_kind[i, j] = KIND_TO_ID[ent.kind]
                hp, hp_known = self._norm_hp(ent.hp, ent.max_hp)
                e_feat[i, j] = torch.tensor([
                    min(max(ent.x, 0.0), 1.0), min(max(ent.y, 0.0), 1.0), hp,
                    max(min(ent.vx, 4.0), -4.0) / 4.0,
                    max(min(ent.vy, 4.0), -4.0) / 4.0,
                    min(max(ent.age_s / 30.0, 0.0), 1.0),
                    min(max(ent.confidence, 0.0), 1.0), hp_known,
                    1.0 if ent.max_hp is not None else 0.0,
                ])

            events = list(s.recent_events)[-self.max_events:]
            start = self.max_events - len(events)
            for j, ev in enumerate(events, start=start):
                h_mask[i, j] = True
                h_card[i, j] = self.vocab.encode(ev.card_id)
                h_team[i, j] = TEAM_TO_ID[ev.team]
                h_feat[i, j] = torch.tensor([
                    min(max((s.t_s - ev.t_s) / 30.0, 0.0), 1.0),
                    -1.0 if ev.x is None else min(max(ev.x, 0.0), 1.0),
                    -1.0 if ev.y is None else min(max(ev.y, 0.0), 1.0),
                ])

        return TensorBatch(g, hand, e_card, e_team, e_kind, e_feat, e_mask,
                           h_card, h_team, h_feat, h_mask, source_ids)


def concat_tensor_batches(xs:list[TensorBatch])->TensorBatch:
    """Concatenate compatible TensorBatch objects along batch dimension."""
    if not xs:raise ValueError('cannot concatenate empty TensorBatch list')
    keys=tuple(xs[0].__dict__.keys())
    if any(tuple(x.__dict__.keys())!=keys for x in xs):raise ValueError('TensorBatch schema mismatch')
    out={}
    for k in keys:
        vals=[getattr(x,k) for x in xs]
        ref=vals[0].shape[1:]
        if any(v.shape[1:]!=ref for v in vals):raise ValueError(f'TensorBatch field shape mismatch: {k}')
        out[k]=torch.cat(vals,dim=0)
    return TensorBatch(**out)
