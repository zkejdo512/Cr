from __future__ import annotations

from dataclasses import dataclass
import json
import hashlib
from pathlib import Path
from typing import Iterable

PAD_TOKEN = 0
UNK_TOKEN = 1


@dataclass(frozen=True)
class CardVocabulary:
    """Stable raw-card-id -> compact embedding-id mapping.

    Real Clash Royale card ids are not 0..N. Clamping raw ids into a small
    embedding table aliases unrelated cards and is therefore forbidden.
    """
    raw_to_token: dict[int, int]

    @classmethod
    def from_card_ids(cls, card_ids: Iterable[int]) -> "CardVocabulary":
        unique = sorted({int(x) for x in card_ids if x is not None and int(x) >= 0})
        return cls({raw: i + 2 for i, raw in enumerate(unique)})

    @property
    def size(self) -> int:
        return max([UNK_TOKEN, *self.raw_to_token.values()], default=UNK_TOKEN) + 1

    def encode(self, raw_id: int | None) -> int:
        if raw_id is None or int(raw_id) < 0:
            return PAD_TOKEN
        return self.raw_to_token.get(int(raw_id), UNK_TOKEN)

    def fingerprint(self) -> str:
        payload=json.dumps({str(k):int(v) for k,v in sorted(self.raw_to_token.items())},separators=(',',':'),sort_keys=True).encode('utf8')
        return hashlib.sha256(payload).hexdigest()

    def save(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps({str(k): v for k, v in self.raw_to_token.items()}, indent=2))

    @classmethod
    def load(cls, path: str | Path) -> "CardVocabulary":
        raw = json.loads(Path(path).read_text())
        return cls({int(k): int(v) for k, v in raw.items()})

    def missing_card_ids(self, card_ids: Iterable[int]) -> list[int]:
        return sorted({int(x) for x in card_ids if x is not None and int(x) >= 0 and int(x) not in self.raw_to_token})

    def assert_covers(self, card_ids: Iterable[int], context: str = 'card vocabulary') -> None:
        missing = self.missing_card_ids(card_ids)
        if missing:
            preview = ', '.join(map(str, missing[:12]))
            suffix = '' if len(missing) <= 12 else f' ... (+{len(missing)-12})'
            raise RuntimeError(f'{context} is incomplete; missing raw card ids: {preview}{suffix}')
