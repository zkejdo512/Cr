from __future__ import annotations
from dataclasses import dataclass,asdict
import json
from typing import Callable
from crgod.contracts import ObservedOpponentActionV1


@dataclass(frozen=True)
class DecisionRecord:
    t_s:float
    action_a:int
    action_b:int
    legal_count_a:int
    legal_count_b:int
    value_a:float
    value_b:float


@dataclass(frozen=True)
class MatchTrace:
    seed:int
    outcome_a:float
    decisions:tuple[DecisionRecord,...]
    simulator_id:str
    metadata:dict
    def to_json(self)->str:return json.dumps(asdict(self),ensure_ascii=False)


def run_trace_match(sim,actor_a,actor_b,*,seed:int,max_steps:int=2000)->MatchTrace:
    frame=sim.reset(seed=seed);frame.validate();actor_a.reset();actor_b.reset()
    prev_own=[0,0];prev_opp=[ObservedOpponentActionV1.pass_action(),ObservedOpponentActionV1.pass_action()]
    known=[False,False];dt=[0.,0.];rows=[]
    for _ in range(max_steps):
        ia,_,va,_=actor_a.act(frame.seat_a.observation,frame.seat_a.legal_action_indices,prev_own_action=prev_own[0],prev_opp_action=prev_opp[0],prev_opp_known=known[0],dt_s=dt[0],deterministic=True)
        ib,_,vb,_=actor_b.act(frame.seat_b.observation,frame.seat_b.legal_action_indices,prev_own_action=prev_own[1],prev_opp_action=prev_opp[1],prev_opp_known=known[1],dt_s=dt[1],deterministic=True)
        rows.append(DecisionRecord(float(frame.t_s),ia,ib,len(frame.seat_a.legal_action_indices),len(frame.seat_b.legal_action_indices),va,vb))
        tr=sim.step(ia,ib);tr.validate()
        if tr.done:
            if tr.outcome_a is None:
                raise RuntimeError('terminal trace requires explicit outcome_a; shaped reward may not define wins')
            return MatchTrace(int(seed),float(tr.outcome_a),tuple(rows),str(sim.simulator_id),dict(tr.metadata))
        frame=tr.next_frame;prev_own=[ia,ib];prev_opp=[tr.action_b_observed_by_a,tr.action_a_observed_by_b]
        known=[tr.action_b_known_to_a,tr.action_a_known_to_b];dt=[tr.elapsed_s,tr.elapsed_s]
    raise RuntimeError(f'trace eval did not terminate within {max_steps} decisions')


@dataclass(frozen=True)
class EvalSuiteV4:
    name:str
    kind:str  # capability | regression | hidden
    seeds:tuple[int,...]
    matchup:dict|None=None

    def __post_init__(self):
        if self.kind not in ('capability','regression','hidden'):raise ValueError('unknown eval suite kind')
        if not self.seeds:raise ValueError('eval suite needs seeds')
