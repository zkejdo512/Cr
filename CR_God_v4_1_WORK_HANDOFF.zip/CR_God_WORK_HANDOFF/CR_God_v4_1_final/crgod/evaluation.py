from dataclasses import dataclass
import torch
from .data import sample_transition_batch
@dataclass
class BCEval: accuracy:float; value_mae:float|None; illegal_argmax_rate:float
@torch.no_grad()
def evaluate_bc(model,transitions,tensorizer,return_targets=None,device='cpu'):
    model.eval(); b=sample_transition_batch(transitions,tensorizer,len(transitions),return_targets=return_targets).to(device); _,logits,v=model(b.state,legal_mask=b.legal_mask); pred=logits.argmax(-1); acc=(pred==b.own_action).float().mean(); rows=torch.arange(pred.shape[0],device=pred.device); illegal=(~b.legal_mask[rows,pred]).float().mean(); mae=None if b.return_target is None else float((v-b.return_target).abs().mean()); return BCEval(float(acc),mae,float(illegal))
