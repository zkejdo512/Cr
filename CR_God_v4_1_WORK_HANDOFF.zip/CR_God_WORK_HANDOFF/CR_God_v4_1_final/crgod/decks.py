from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class DeckSpec:
    name: str
    card_ids: tuple[int, ...]
    enabled: bool = True

    def validate(self) -> None:
        if len(self.card_ids) != 8:
            raise ValueError(f"deck '{self.name}' must contain exactly 8 cards, got {len(self.card_ids)}")
        if len(set(self.card_ids)) != 8:
            raise ValueError(f"deck '{self.name}' contains duplicate card ids")
        if any(int(x) < 0 for x in self.card_ids):
            raise ValueError(f"deck '{self.name}' contains invalid card id")
