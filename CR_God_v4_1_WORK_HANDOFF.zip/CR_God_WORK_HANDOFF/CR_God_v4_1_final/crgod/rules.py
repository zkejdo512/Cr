from __future__ import annotations
from .contracts import TowerState


def tiebreak_min_absolute_hp(towers: tuple[TowerState, ...]) -> float:
    """Return the minimum HP among surviving crown towers.

    This deliberately uses *absolute* HP, never hp_fraction. Destroyed towers
    are excluded because the match would normally already have resolved via
    crowns; callers should handle terminal crown wins before tiebreak.
    """
    alive = [float(t.hp) for t in towers if t.alive and t.hp > 0]
    return min(alive) if alive else 0.0


def tiebreak_compare(self_towers: tuple[TowerState, ...], opponent_towers: tuple[TowerState, ...]) -> int:
    """+1 self wins, -1 opponent wins, 0 tie under lowest-single-tower HP."""
    a = tiebreak_min_absolute_hp(self_towers)
    b = tiebreak_min_absolute_hp(opponent_towers)
    return 1 if a > b else (-1 if a < b else 0)
