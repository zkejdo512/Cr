from __future__ import annotations
from dataclasses import dataclass, asdict
import json
import math
from typing import Callable
import torch


@dataclass(frozen=True)
class RolloutEstimate:
    mean_value: float
    std_value: float = 0.0
    samples: int = 1


@dataclass
class CandidateTrace:
    action_index: int
    policy_logprob: float
    rollout_mean: float
    rollout_std: float
    score: float


@dataclass
class DecisionTrace:
    fast_action: int
    chosen_action: int
    used_slow: bool
    normalized_entropy: float
    top_margin: float
    candidates: list[CandidateTrace]

    def to_json(self) -> str:
        return json.dumps(asdict(self), ensure_ascii=False, indent=2)


class FastSlowPlanner:
    """Adaptive test-time compute.

    Fast path returns policy argmax. Slow path evaluates top-K policy proposals
    using an external simulator/rollout callback. The callback boundary keeps
    planning independent of a specific simulator implementation.
    """
    def __init__(self, top_k: int = 8, entropy_threshold: float = .55,
                 margin_threshold: float = .75, uncertainty_penalty: float = .5,
                 prior_weight: float = .03):
        self.top_k = int(top_k)
        self.entropy_threshold = float(entropy_threshold)
        self.margin_threshold = float(margin_threshold)
        self.uncertainty_penalty = float(uncertainty_penalty)
        self.prior_weight = float(prior_weight)

    @staticmethod
    def _uncertainty(logits: torch.Tensor, legal_mask: torch.Tensor):
        legal_logits = logits[legal_mask]
        if legal_logits.numel() <= 1:
            return 0.0, float('inf')
        lp = torch.log_softmax(legal_logits, dim=-1)
        p = lp.exp()
        ent = float((-(p * lp).sum() / math.log(legal_logits.numel())).detach())
        top2 = torch.topk(legal_logits, k=2).values
        margin = float((top2[0] - top2[1]).detach())
        return ent, margin

    @torch.no_grad()
    def decide(self, logits: torch.Tensor, legal_mask: torch.Tensor,
               rollout: Callable[[int], RolloutEstimate] | None = None,
               force_slow: bool = False) -> DecisionTrace:
        if logits.ndim != 1 or legal_mask.ndim != 1 or logits.shape != legal_mask.shape:
            raise ValueError('planner expects one 1-D action distribution and matching mask')
        if not bool(legal_mask[0]):
            raise ValueError('pass must be legal')
        masked = logits.masked_fill(~legal_mask, -1e9)
        fast = int(masked.argmax().item())
        ent, margin = self._uncertainty(masked, legal_mask)
        use_slow = force_slow or (rollout is not None and (ent >= self.entropy_threshold or margin <= self.margin_threshold))
        if not use_slow:
            return DecisionTrace(fast, fast, False, ent, margin, [])
        legal_count = int(legal_mask.sum().item())
        k = min(self.top_k, legal_count)
        top = torch.topk(masked, k=k)
        logp = torch.log_softmax(masked, dim=-1)
        traces = []
        for idx in top.indices.tolist():
            est = rollout(int(idx))
            score = float(est.mean_value - self.uncertainty_penalty * est.std_value + self.prior_weight * float(logp[idx]))
            traces.append(CandidateTrace(int(idx), float(logp[idx]), float(est.mean_value),
                                         float(est.std_value), score))
        best = max(traces, key=lambda x: x.score)
        return DecisionTrace(fast, best.action_index, True, ent, margin, traces)
