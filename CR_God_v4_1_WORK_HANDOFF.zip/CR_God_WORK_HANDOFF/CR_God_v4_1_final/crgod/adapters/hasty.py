from __future__ import annotations

from dataclasses import dataclass, asdict
from hashlib import blake2b
import importlib
import json
from pathlib import Path
import subprocess
import ast
import sys
from typing import Any
import numpy as np

from crgod.action_codec import (GRID_W, GRID_H, NUM_ACTIONS, ABILITY_BASE,
                                encode_action, decode_action, tile_xy)
from crgod.contracts import (ActionV2, CardRef, TowerState, EntityState,
                             TrueBattleStateV1, PlayerObservationV1,
                             ObservedOpponentActionV1, TransitionV1,
                             to_player_observation, OBSERVATION_SCHEMA_VERSION)


def stable_name_id(name: str) -> int:
    """Deterministic positive 31-bit id for Hasty string identities.

    The persisted name->id map remains the source of truth; the hash simply
    makes fixture ids stable across processes before a real Supercell id table
    is wired in.
    """
    raw=blake2b(name.encode('utf8'),digest_size=8,person=b'crgod-v21').digest()
    return int.from_bytes(raw,'little') & 0x7fffffff


class HastyNameRegistry:
    def __init__(self): self.name_to_id: dict[str,int]={}; self.id_to_name: dict[int,str]={}
    def id(self,name: str) -> int:
        name=str(name)
        if name in self.name_to_id: return self.name_to_id[name]
        value=stable_name_id(name)
        other=self.id_to_name.get(value)
        if other is not None and other != name:
            raise RuntimeError(f'Hasty name hash collision: {name!r} vs {other!r}; use explicit registry ids')
        self.name_to_id[name]=value; self.id_to_name[value]=name; return value
    def to_json(self) -> dict: return dict(sorted(self.name_to_id.items()))


class _LoggingOpponent:
    def __init__(self,inner): self.inner=inner; self.last_result=None; self.calls=0
    def reset(self):
        self.last_result=None; self.calls=0
        return self.inner.reset()
    def act(self,match):
        self.calls+=1; self.last_result=self.inner.act(match); return self.last_result
    def __getattr__(self,name): return getattr(self.inner,name)


ABILITY_CAPABILITY_FIELDS = frozenset({
    "ability_buff", "ability_buff_ms", "ability_dash_range_mt",
    "ability_spawn_character", "ability_area_damage", "ability_deploy_character",
    "ability_lane_switch", "ability_link_target", "ability_level_adjustments",
    "ability_taunt_radius_mt", "ability_hurl_radius_mt", "ability_siege_range_mt",
    "ability_split_character", "ability_reroll_range_mt", "ability_spin_seek_radius_mt",
    "ability_reinforcement_character", "ability_transform_character",
    "ability_warp_backward_mt", "ability_warp_to_target_speed",
    "ability_temporary_character", "ability_summon_character",
    "ability_extra_projectiles", "ability_drop_character",
})


@dataclass
class HastySourceAuditReport:
    tiebreak_absolute_hp_ok: bool
    ability_enumeration_ok: bool
    missing_ability_fields: tuple[str, ...]
    errors: list[str]

    @property
    def ok(self): return not self.errors
    def assert_ok(self):
        if self.errors: raise RuntimeError('Hasty source audit failed:\n- '+'\n- '.join(self.errors))
    def to_json(self): return json.dumps(asdict(self),indent=2)


@dataclass
class HastyParityReport:
    action_count_ok: bool
    grid_ok: bool
    decision_ms_ok: bool
    full_codec_ok: bool
    mask_ok: bool
    deterministic_pass_probe_ok: bool
    observation_shapes: dict[str, tuple]
    errors: list[str]

    @property
    def ok(self): return not self.errors
    def assert_ok(self):
        if self.errors: raise RuntimeError('Hasty parity failed:\n- '+'\n- '.join(self.errors))
    def to_json(self): return json.dumps(asdict(self),indent=2)


class HastyRuntime:
    """Dynamic, commit-local bridge to a checked-out Hasty-CR repository.

    No Hasty code is vendored here.  We import the user's pinned checkout and
    verify its live constants/codec before collecting a single training sample.
    """
    def __init__(self,hasty_root: str | Path):
        self.root=Path(hasty_root).resolve()
        if not (self.root/'sim'/'env.py').exists(): raise FileNotFoundError(self.root/'sim'/'env.py')
        if str(self.root) not in sys.path: sys.path.insert(0,str(self.root))
        self.envmod=importlib.import_module('sim.env')
        env_file=Path(getattr(self.envmod,'__file__','')).resolve()
        if self.root not in env_file.parents:
            raise RuntimeError(f'sim.env was already imported from a different checkout: {env_file}')
        self.arena=None
        try:
            self.arena=importlib.import_module('sim.arena')
            arena_file=Path(getattr(self.arena,'__file__','')).resolve()
            if self.root not in arena_file.parents:
                raise RuntimeError(f'sim.arena came from a different checkout: {arena_file}')
        except ModuleNotFoundError:
            # Runtime audit only needs env.py. Full state conversion requires arena.py.
            pass

    def commit_sha(self) -> str | None:
        try:
            r=subprocess.run(["git","-C",str(self.root),"rev-parse","HEAD"],
                             check=True,capture_output=True,text=True,timeout=5)
            sha=r.stdout.strip()
            return sha if len(sha)>=7 else None
        except Exception:
            marker=self.root/'CRGOD_PINNED_COMMIT'
            if marker.exists():
                sha=marker.read_text().strip()
                return sha or None
            return None

    @staticmethod
    def _function_attribute_names(path: Path, function_name: str) -> set[str]:
        tree=ast.parse(path.read_text(encoding='utf8'))
        found=None
        for node in ast.walk(tree):
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==function_name:
                found=node; break
        if found is None:
            return set()
        attrs={n.attr for n in ast.walk(found) if isinstance(n,ast.Attribute)}
        # Patched source intentionally uses getattr(..., "ability_x", default)
        # to stay compatible with cards whose dataclass predates a newer field.
        for n in ast.walk(found):
            if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='getattr' and len(n.args)>=2:
                key=n.args[1]
                if isinstance(key,ast.Constant) and isinstance(key.value,str): attrs.add(key.value)
        return attrs

    def source_audit(self) -> HastySourceAuditReport:
        errors=[]
        env_path=self.root/'sim'/'env.py'; match_path=self.root/'sim'/'match.py'
        ability_attrs=self._function_attribute_names(env_path,'ability_entities')
        missing=tuple(sorted(ABILITY_CAPABILITY_FIELDS-ability_attrs))
        ability_ok=not missing
        if missing:
            errors.append('ability_entities misses capability fields: '+', '.join(missing))
        text=match_path.read_text(encoding='utf8')
        try:
            start=text.index('    def _tiebreak')
            tail=text[start:start+900]
        except ValueError:
            tail=''
        tiebreak_ok=('"king"' in tail or "'king'" in tail) and 'hitpoints' in tail and 'hp_fraction' not in tail
        if not tiebreak_ok:
            errors.append('tiebreak is not verified as absolute HP across remaining crown towers')
        return HastySourceAuditReport(tiebreak_ok,ability_ok,missing,errors)

    def audit(self,seed: int=991) -> HastyParityReport:
        errors=[]; E=self.envmod
        action_ok=int(getattr(E,'ACTIONS',-1))==NUM_ACTIONS
        if not action_ok: errors.append(f'action count {getattr(E,"ACTIONS",None)} != {NUM_ACTIONS}')
        grid_ok=(int(getattr(E,'GRID_W',-1)),int(getattr(E,'GRID_H',-1)))==(GRID_W,GRID_H)
        if not grid_ok: errors.append('grid shape mismatch')
        decision_ok=int(getattr(E,'DECIDE_EVERY_MS',-1))==500
        if not decision_ok: errors.append(f'unexpected decision interval {getattr(E,"DECIDE_EVERY_MS",None)}ms')
        codec_ok=True
        try:
            for idx in range(NUM_ACTIONS):
                ours=decode_action(idx); theirs=E.ClashEnv.decode(idx)
                if idx==0:
                    if theirs is not None: raise AssertionError((idx,theirs))
                elif idx>=ABILITY_BASE:
                    if theirs != ('ability',idx-ABILITY_BASE): raise AssertionError((idx,theirs))
                    if int(E.ClashEnv.encode_ability(idx-ABILITY_BASE)) != idx: raise AssertionError(('ability encode',idx))
                else:
                    gx,gy=tile_xy(idx)
                    expected=(int(ours.slot),gx,gy)
                    if theirs != expected: raise AssertionError((idx,theirs,expected))
                    if int(E.ClashEnv.encode(*expected)) != idx: raise AssertionError(('encode',idx))
        except Exception as exc:
            codec_ok=False; errors.append(f'codec parity: {exc}')
        mask_ok=False; shapes={}
        try:
            env=E.ClashEnv(seed=seed); obs,info=env.reset(seed=seed)
            shapes={k:tuple(np.asarray(v).shape) for k,v in obs.items()}
            mask=np.asarray(info['action_mask'],dtype=bool)
            mask_ok=(mask.shape==(NUM_ACTIONS,) and bool(mask[0]))
            if not mask_ok: errors.append(f'action mask invalid shape/pass: {mask.shape}, {bool(mask[0]) if mask.size else None}')
        except Exception as exc: errors.append(f'reset/mask probe: {exc}')
        det_ok=False
        try:
            a=E.ClashEnv(seed=seed); b=E.ClashEnv(seed=seed)
            oa,ia=a.reset(seed=seed); ob,ib=b.reset(seed=seed)
            def same_obs(x,y): return x.keys()==y.keys() and all(np.array_equal(np.asarray(x[k]),np.asarray(y[k])) for k in x)
            if not same_obs(oa,ob): raise AssertionError('reset observation differs')
            for _ in range(8):
                ra=a.step(0); rb=b.step(0)
                if ra[1:4] != rb[1:4] or not same_obs(ra[0],rb[0]) or not np.array_equal(ra[4]['action_mask'],rb[4]['action_mask']):
                    raise AssertionError('same-seed pass trajectory diverged')
            det_ok=True
        except Exception as exc: errors.append(f'determinism probe: {exc}')
        return HastyParityReport(action_ok,grid_ok,decision_ok,codec_ok,mask_ok,det_ok,shapes,errors)


class HastyEnvAdapter:
    """Convert Hasty's privileged Match into CR-God's strict state contract."""
    def __init__(self,hasty_root: str | Path,seed: int=0,level: int=11,opponent: str='brain',
                 max_ms: int | None = None, require_source_audit: bool = True):
        self.rt=HastyRuntime(hasty_root); self.rt.audit(seed=max(1,seed)).assert_ok()
        if require_source_audit:
            self.rt.source_audit().assert_ok()
        if self.rt.arena is None: raise RuntimeError('full Hasty adapter requires sim/arena.py')
        kwargs=dict(seed=seed,level=level,opponent=opponent)
        if max_ms is not None: kwargs['max_ms']=int(max_ms)
        self.env=self.rt.envmod.ClashEnv(**kwargs)
        self.registry=HastyNameRegistry(); self._prev_entity: dict[int,tuple[float,float,float]]={}
        self._last_obs: PlayerObservationV1 | None=None; self._last_legal: tuple[int,...] | None=None
        self._proxy: _LoggingOpponent | None=None

    def supported_card_ids(self) -> tuple[int, ...]:
        names=set(getattr(self.env,'_cards',{}).keys())
        names.update(getattr(self.rt.envmod,'DECK_26',()))
        return tuple(sorted(self.registry.id(str(x)) for x in names))

    def build_vocab(self):
        from crgod.vocab import CardVocabulary
        ids=self.supported_card_ids()
        if not ids:
            raise RuntimeError('Hasty adapter could not enumerate supported cards for vocabulary')
        return CardVocabulary.from_card_ids(ids)

    def _card(self,name: str,player) -> CardRef:
        try: deck_index=list(player.deck).index(name)
        except ValueError: deck_index=-1
        return CardRef(self.registry.id(name),deck_index,name)

    def _tower(self,t,team,lane):
        return TowerState(team,lane,float(t.hitpoints),bool(t.alive),float(t.pos.x)/self.rt.arena.WIDTH,
                          float(t.pos.y)/self.rt.arena.HEIGHT,float(t.max_hitpoints),
                          (not bool(t.target_only_buildings)) if lane=='king' else True)

    def true_state(self) -> TrueBattleStateV1:
        m=self.env.match
        if m is None: raise RuntimeError('Hasty environment is not reset')
        now=float(m.elapsed_ms)/1000.0
        p1,p2=m.players[1],m.players[-1]
        if len(p1.hand)!=4 or len(p2.hand)!=4: raise RuntimeError('expected four-card hands')
        own_t=tuple(self._tower(m.towers[1][lane],'self',lane) for lane in ('left','right','king'))
        opp_t=tuple(self._tower(m.towers[-1][lane],'opponent',lane) for lane in ('left','right','king'))
        entities=[]; next_cache={}
        for e in m.battle.entities.values():
            if not e.alive or getattr(e,'is_tower',False): continue
            x=float(e.pos.x)/self.rt.arena.WIDTH; y=float(e.pos.y)/self.rt.arena.HEIGHT
            old=self._prev_entity.get(int(e.uid)); vx=vy=0.0
            if old is not None and now>old[2]: vx=(x-old[0])/(now-old[2]); vy=(y-old[1])/(now-old[2])
            next_cache[int(e.uid)]=(x,y,now)
            kind='building' if getattr(e,'is_building',False) else 'troop'
            # Fail conservative on exact position information the real player
            # cannot observe. Own units remain known to their owner; enemy units
            # that are underground/invisible/hidden are removed by TrueState ->
            # PlayerObservation projection instead of leaking simulator truth.
            now_ms=int(m.elapsed_ms)
            hidden = bool(
                getattr(e,'underground',False)
                or (callable(getattr(e,'invisible',None)) and e.invisible(now_ms))
                or int(getattr(e,'hidden_until_ms',0) or 0) > now_ms
                or bool(getattr(e,'ability_digging',False))
                or bool(getattr(e,'spell_captured',False))
            )
            v_self = True if e.side>0 else not hidden
            v_opp = True if e.side<0 else not hidden
            entities.append(EntityState(int(e.uid),'self' if e.side>0 else 'opponent',self.registry.id(e.name),kind,x,y,
                                        float(e.hitpoints),float(e.max_hitpoints),vx,vy,max(0.0,now-float(getattr(e,'spawned_at_ms',0))/1000.0),1.0,
                                        v_self,v_opp))
        self._prev_entity=next_cache
        return TrueBattleStateV1(OBSERVATION_SCHEMA_VERSION,now,p1.elixir/1000.0,p2.elixir/1000.0,own_t,opp_t,
            tuple(self._card(x,p1) for x in p1.hand),None if p1.next_card is None else self._card(p1.next_card,p1),
            tuple(self._card(x,p2) for x in p2.hand),None if p2.next_card is None else self._card(p2.next_card,p2),
            tuple(entities),tuple(), 'sim')

    @staticmethod
    def _indices(mask) -> tuple[int,...]: return tuple(int(x) for x in np.flatnonzero(np.asarray(mask,dtype=bool)))

    def _wrap_opponent(self):
        if self.env.opponent is None: self._proxy=None; return
        self._proxy=_LoggingOpponent(self.env.opponent); self.env.opponent=self._proxy

    def reset(self,seed: int|None=None):
        raw,info=self.env.reset(seed=seed); self._wrap_opponent(); self._prev_entity={}
        true=self.true_state(); obs=to_player_observation(true,'self'); legal=self._indices(info['action_mask'])
        self._last_obs=obs; self._last_legal=legal
        return obs, np.asarray(info['action_mask'],dtype=bool), true

    def _opponent_action(self) -> tuple[ObservedOpponentActionV1,bool]:
        if self._proxy is None or self._proxy.calls==0: return ObservedOpponentActionV1.pass_action(),False
        if self._proxy.calls > 1:
            calls=self._proxy.calls
            self._proxy.calls=0; self._proxy.last_result=None
            raise RuntimeError(f'opponent acted {calls} times inside one CR-God decision interval; single-action TransitionV1 would lose history')
        r=self._proxy.last_result
        self._proxy.calls=0; self._proxy.last_result=None
        if r is None: return ObservedOpponentActionV1.pass_action(),True
        if isinstance(r,(tuple,list)) and len(r)>=4 and r[0]=='ability':
            return ObservedOpponentActionV1.activate_ability(self.registry.id(str(r[3]))),True
        if isinstance(r,(tuple,list)) and len(r)>=3:
            card,x,y=str(r[0]),int(r[1]),int(r[2])
            p=self.rt.envmod.grid_to_point(x,y,-1)
            return ObservedOpponentActionV1.play_card(self.registry.id(card),float(p.x)/self.rt.arena.WIDTH,float(p.y)/self.rt.arena.HEIGHT),True
        return ObservedOpponentActionV1.pass_action(),False

    def step(self,action: ActionV2|int) -> TransitionV1:
        if self._last_obs is None or self._last_legal is None: raise RuntimeError('call reset() first')
        idx=int(action) if isinstance(action,int) else encode_action(action)
        act=decode_action(idx)
        state=self._last_obs; legal=self._last_legal
        _,reward,terminated,truncated,info=self.env.step(idx)
        opp,known=self._opponent_action(); true=self.true_state(); nxt=to_player_observation(true,'self')
        next_legal=self._indices(info['action_mask']); done=bool(terminated or truncated)
        tr=TransitionV1(state,act,opp,float(reward),nxt,done,known,legal,next_legal)
        self._last_obs=nxt; self._last_legal=next_legal
        return tr
