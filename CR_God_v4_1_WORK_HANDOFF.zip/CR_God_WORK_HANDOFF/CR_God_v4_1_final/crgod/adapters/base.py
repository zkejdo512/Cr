from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol
from crgod.action_codec import NUM_ACTIONS, NUM_CARD_ACTIONS, NUM_ABILITY_ACTIONS
from crgod.contracts import PlayerObservationV1, TrueBattleStateV1


class ObservationAdapter(Protocol):
    def convert(self, raw: Any) -> PlayerObservationV1: ...


class TrueStateAdapter(Protocol):
    def convert_true(self, raw: Any) -> TrueBattleStateV1: ...


@dataclass(frozen=True)
class HastyParitySpec:
    """Pinned upstream action-space invariants that must be fixture-verified."""
    expected_actions: int = NUM_ACTIONS
    expected_card_actions: int = NUM_CARD_ACTIONS
    expected_ability_actions: int = NUM_ABILITY_ACTIONS

    def validate_counts(self, actions: int, card_actions: int, ability_actions: int) -> None:
        got = (int(actions), int(card_actions), int(ability_actions))
        exp = (self.expected_actions, self.expected_card_actions, self.expected_ability_actions)
        if got != exp:
            raise RuntimeError(f'Hasty action-space mismatch: got={got}, expected={exp}')


class HastySimAdapter:
    """Boundary for Hasty-CR.

    Policy conversion MUST call upstream player-observation logic, not serialize
    the simulator's privileged match object. True-state conversion is allowed
    only for teacher/calibration/world-model auxiliary targets.
    """
    parity = HastyParitySpec()

    def convert_observation(self, raw: Any) -> PlayerObservationV1:
        raise NotImplementedError('Pin Hasty commit and map observe(side) with parity fixtures first.')

    def convert_true(self, raw: Any) -> TrueBattleStateV1:
        raise NotImplementedError('Privileged mapping is teacher/calibration-only.')


class MemoryReaderAdapter:
    def convert_observation(self, raw: dict) -> PlayerObservationV1:
        raise NotImplementedError('Map visible/reconstructable fields only; hidden opponent hand is forbidden.')


class VisionAdapter:
    def convert_observation(self, raw: dict) -> PlayerObservationV1:
        raise NotImplementedError('Map YOLO+tracker+UI readers to PlayerObservationV1.')
