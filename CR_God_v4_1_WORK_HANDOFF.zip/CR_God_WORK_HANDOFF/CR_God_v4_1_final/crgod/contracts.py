from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Literal, Optional

Team = Literal['self', 'opponent']
EntityKind = Literal['troop', 'building', 'projectile', 'other']
Source = Literal['sim', 'memory', 'vision', 'replay', 'toy']
ActionKind = Literal['pass', 'play_card', 'activate_ability']
OBSERVATION_SCHEMA_VERSION = '1.0'


@dataclass(frozen=True)
class CardRef:
    card_id: int
    deck_index: int = -1
    name: Optional[str] = None


@dataclass(frozen=True)
class TowerState:
    team: Team
    lane: Literal['left', 'right', 'king']
    hp: float
    alive: bool
    x: float
    y: float
    max_hp: Optional[float] = None
    active: Optional[bool] = None


@dataclass(frozen=True)
class EntityState:
    track_id: int
    team: Team
    card_id: int
    kind: EntityKind
    x: float
    y: float
    hp: Optional[float]
    max_hp: Optional[float] = None
    vx: float = 0.0
    vy: float = 0.0
    age_s: float = 0.0
    confidence: float = 1.0
    # Visibility is privileged metadata used only while projecting TrueState.
    # A PlayerObservation contains only entities visible to that seat, so these
    # flags must never be used as a shortcut feature by the policy.
    visible_to_self: bool = True
    visible_to_opponent: bool = True


@dataclass(frozen=True)
class DeploymentEvent:
    t_s: float
    team: Team
    card_id: int
    x: Optional[float]
    y: Optional[float]


@dataclass(frozen=True)
class TrueBattleStateV1:
    """Privileged simulator/replay state. NEVER feed directly to the policy.

    Hidden opponent information lives only here.  The only supported route to
    the policy is `to_player_observation(...)`.
    """
    version: str
    t_s: float
    self_elixir: float
    opponent_elixir: float
    self_towers: tuple[TowerState, ...]
    opponent_towers: tuple[TowerState, ...]
    self_hand: tuple[CardRef, CardRef, CardRef, CardRef]
    self_next_card: Optional[CardRef]
    opponent_hand: tuple[CardRef, CardRef, CardRef, CardRef]
    opponent_next_card: Optional[CardRef]
    entities: tuple[EntityState, ...] = field(default_factory=tuple)
    recent_events: tuple[DeploymentEvent, ...] = field(default_factory=tuple)
    source: Source = 'sim'

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass(frozen=True)
class PlayerObservationV1:
    """Only information a real player/vision stack is allowed to expose."""
    version: str
    t_s: float
    own_elixir: float
    own_towers: tuple[TowerState, ...]
    opponent_towers: tuple[TowerState, ...]
    hand: tuple[CardRef, CardRef, CardRef, CardRef]
    next_card: Optional[CardRef]
    entities: tuple[EntityState, ...] = field(default_factory=tuple)
    recent_events: tuple[DeploymentEvent, ...] = field(default_factory=tuple)
    source: Source = 'sim'

    def as_dict(self) -> dict:
        return asdict(self)


def to_player_observation(state: TrueBattleStateV1, side: Team = 'self') -> PlayerObservationV1:
    """Project privileged state into a non-cheating player observation.

    For the opponent perspective we swap teams and mirror team labels in the
    visible entities/events. Hidden hand/elixir are never copied across.
    """
    if side == 'self':
        visible = tuple(e for e in state.entities if e.visible_to_self)
        return PlayerObservationV1(
            state.version, state.t_s, state.self_elixir,
            state.self_towers, state.opponent_towers,
            state.self_hand, state.self_next_card,
            visible, state.recent_events, state.source,
        )

    def swap_team(t: Team) -> Team:
        return 'opponent' if t == 'self' else 'self'

    def mirror(v: Optional[float]) -> Optional[float]:
        return None if v is None else 1.0 - float(v)

    def swap_lane(lane: str) -> str:
        # A 180-degree canonical-view rotation swaps screen-left and screen-right.
        # Keeping the old lane label would make opponent-seat self-play learn a
        # spatially inconsistent tower identity.
        if lane == 'left': return 'right'
        if lane == 'right': return 'left'
        return lane

    # Both seats are presented in the same canonical 'I am bottom' frame.
    # A 180-degree rotation changes both coordinates and velocity directions.
    entities = tuple(EntityState(
        e.track_id, swap_team(e.team), e.card_id, e.kind,
        1.0 - e.x, 1.0 - e.y, e.hp, e.max_hp, -e.vx, -e.vy,
        e.age_s, e.confidence,
        e.visible_to_opponent, e.visible_to_self,
    ) for e in state.entities if e.visible_to_opponent)
    events = tuple(DeploymentEvent(ev.t_s, swap_team(ev.team), ev.card_id, mirror(ev.x), mirror(ev.y))
                   for ev in state.recent_events)
    own_towers = tuple(TowerState('self', swap_lane(t.lane), t.hp, t.alive, 1.0-t.x, 1.0-t.y, t.max_hp, t.active)
                       for t in state.opponent_towers)
    opp_towers = tuple(TowerState('opponent', swap_lane(t.lane), t.hp, t.alive, 1.0-t.x, 1.0-t.y, t.max_hp, t.active)
                       for t in state.self_towers)
    return PlayerObservationV1(
        state.version, state.t_s, state.opponent_elixir,
        own_towers, opp_towers, state.opponent_hand, state.opponent_next_card,
        entities, events, state.source,
    )


# Backward-compatible import name for v1.1 user code.  New code should use
# PlayerObservationV1 explicitly; keeping the alias prevents accidental breakage.
BattleStateV1 = PlayerObservationV1


@dataclass(frozen=True)
class ActionV2:
    kind: ActionKind = 'pass'
    slot: Optional[int] = None
    x: Optional[float] = None
    y: Optional[float] = None
    ability_slot: Optional[int] = None

    @classmethod
    def pass_action(cls) -> 'ActionV2':
        return cls('pass')

    @classmethod
    def play_card(cls, slot: int, x: float, y: float) -> 'ActionV2':
        return cls('play_card', slot=slot, x=x, y=y)

    @classmethod
    def activate_ability(cls, ability_slot: int) -> 'ActionV2':
        return cls('activate_ability', ability_slot=ability_slot)

    @property
    def is_pass(self) -> bool:
        return self.kind == 'pass'

    @property
    def is_play_card(self) -> bool:
        return self.kind == 'play_card'

    @property
    def is_ability(self) -> bool:
        return self.kind == 'activate_ability'

    def validate(self) -> None:
        if self.kind == 'pass':
            if any(v is not None for v in (self.slot, self.x, self.y, self.ability_slot)):
                raise ValueError('pass action cannot carry payload')
            return
        if self.kind == 'play_card':
            if self.slot not in (0, 1, 2, 3):
                raise ValueError(f'invalid slot: {self.slot}')
            if self.x is None or not 0.0 <= self.x <= 1.0:
                raise ValueError(f'invalid x: {self.x}')
            if self.y is None or not 0.0 <= self.y <= 1.0:
                raise ValueError(f'invalid y: {self.y}')
            if self.ability_slot is not None:
                raise ValueError('play_card cannot carry ability_slot')
            return
        if self.kind == 'activate_ability':
            if self.ability_slot is None or not 0 <= self.ability_slot < 16:
                raise ValueError(f'invalid ability slot: {self.ability_slot}')
            if any(v is not None for v in (self.slot, self.x, self.y)):
                raise ValueError('ability action cannot carry card-placement payload')
            return
        raise ValueError(f'unknown action kind {self.kind}')


# v1 name retained as an alias, but semantics are v2 and include abilities.
ActionV1 = ActionV2


@dataclass(frozen=True)
class ObservedOpponentActionV1:
    """An action that was visible to the player after it happened.

    `card_id` identifies the deployed card for a placement, or the visible
    champion/hero identity for an ability press.  The fourth field was added in
    v2.1 so opponent ability activations are not collapsed into pass.  The
    three-argument constructor remains backward compatible with v1/v2 replays.
    """
    card_id: Optional[int]
    x: Optional[float]
    y: Optional[float]
    ability: bool = False

    @classmethod
    def pass_action(cls) -> 'ObservedOpponentActionV1':
        return cls(None, None, None, False)

    @classmethod
    def play_card(cls, card_id: int, x: float, y: float) -> 'ObservedOpponentActionV1':
        return cls(int(card_id), float(x), float(y), False)

    @classmethod
    def activate_ability(cls, source_card_id: int) -> 'ObservedOpponentActionV1':
        return cls(int(source_card_id), None, None, True)

    @property
    def is_pass(self) -> bool:
        return self.card_id is None and not self.ability

    @property
    def is_ability(self) -> bool:
        return bool(self.ability)

    def validate(self) -> None:
        if self.is_pass:
            if self.x is not None or self.y is not None:
                raise ValueError('opponent pass must not have coordinates')
            return
        if self.card_id is None:
            raise ValueError('non-pass opponent action requires a visible card/entity id')
        if self.is_ability:
            if self.x is not None or self.y is not None:
                raise ValueError('opponent ability action must not carry placement coordinates')
            return
        if self.x is None or not 0.0 <= self.x <= 1.0:
            raise ValueError(f'invalid opponent x: {self.x}')
        if self.y is None or not 0.0 <= self.y <= 1.0:
            raise ValueError(f'invalid opponent y: {self.y}')


@dataclass(frozen=True)
class TransitionV1:
    state: PlayerObservationV1
    action: ActionV2
    opponent_action: ObservedOpponentActionV1
    reward: float
    next_state: PlayerObservationV1
    done: bool
    opponent_action_known: bool = True
    legal_action_indices: Optional[tuple[int, ...]] = None
    next_legal_action_indices: Optional[tuple[int, ...]] = None
