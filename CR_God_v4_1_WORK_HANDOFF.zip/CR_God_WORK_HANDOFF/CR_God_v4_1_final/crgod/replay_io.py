from __future__ import annotations
import json
from pathlib import Path
from typing import Iterable
from .contracts import (CardRef,TowerState,EntityState,DeploymentEvent,
                        PlayerObservationV1,ActionV2,ObservedOpponentActionV1,TransitionV1,TrueBattleStateV1)
from .sequence import Episode


def _card(d): return CardRef(int(d['card_id']),int(d.get('deck_index',-1)),d.get('name'))
def _tower(d): return TowerState(d['team'],d['lane'],float(d['hp']),bool(d['alive']),float(d['x']),float(d['y']),None if d.get('max_hp') is None else float(d['max_hp']),d.get('active'))
def _entity(d): return EntityState(int(d['track_id']),d['team'],int(d['card_id']),d['kind'],float(d['x']),float(d['y']),None if d.get('hp') is None else float(d['hp']),None if d.get('max_hp') is None else float(d['max_hp']),float(d.get('vx',0)),float(d.get('vy',0)),float(d.get('age_s',0)),float(d.get('confidence',1)),bool(d.get('visible_to_self',True)),bool(d.get('visible_to_opponent',True)))
def _event(d): return DeploymentEvent(float(d['t_s']),d['team'],int(d['card_id']),d.get('x'),d.get('y'))

def observation_from_dict(d):
    hand=tuple(_card(x) for x in d['hand'])
    if len(hand)!=4: raise ValueError('replay observation hand must contain exactly four cards')
    return PlayerObservationV1(str(d['version']),float(d['t_s']),float(d['own_elixir']),tuple(_tower(x) for x in d['own_towers']),tuple(_tower(x) for x in d['opponent_towers']),hand,None if d.get('next_card') is None else _card(d['next_card']),tuple(_entity(x) for x in d.get('entities',[])),tuple(_event(x) for x in d.get('recent_events',[])),d.get('source','replay'))


def true_state_from_dict(d):
    self_hand=tuple(_card(x) for x in d['self_hand']); opp_hand=tuple(_card(x) for x in d['opponent_hand'])
    if len(self_hand)!=4 or len(opp_hand)!=4: raise ValueError('privileged true state hands must contain exactly four cards')
    return TrueBattleStateV1(
        str(d['version']),float(d['t_s']),float(d['self_elixir']),float(d['opponent_elixir']),
        tuple(_tower(x) for x in d['self_towers']),tuple(_tower(x) for x in d['opponent_towers']),
        self_hand,None if d.get('self_next_card') is None else _card(d['self_next_card']),
        opp_hand,None if d.get('opponent_next_card') is None else _card(d['opponent_next_card']),
        tuple(_entity(x) for x in d.get('entities',[])),tuple(_event(x) for x in d.get('recent_events',[])),d.get('source','replay'))

def action_from_dict(d):
    k=d['kind']
    if k=='pass': return ActionV2.pass_action()
    if k=='play_card': return ActionV2.play_card(int(d['slot']),float(d['x']),float(d['y']))
    if k=='activate_ability': return ActionV2.activate_ability(int(d['ability_slot']))
    raise ValueError(f'unknown action kind {k}')

def opponent_action_from_dict(d):
    return ObservedOpponentActionV1(d.get('card_id'),d.get('x'),d.get('y'),bool(d.get('ability',False)))

def transition_from_dict(d):
    tr=TransitionV1(observation_from_dict(d['state']),action_from_dict(d['action']),opponent_action_from_dict(d['opponent_action']),float(d['reward']),observation_from_dict(d['next_state']),bool(d['done']),bool(d.get('opponent_action_known',True)),None if d.get('legal_action_indices') is None else tuple(int(x) for x in d['legal_action_indices']),None if d.get('next_legal_action_indices') is None else tuple(int(x) for x in d['next_legal_action_indices']))
    tr.action.validate(); tr.opponent_action.validate(); return tr

def _obs_dict(o): return o.as_dict()
def _act_dict(a): return {'kind':a.kind,'slot':a.slot,'x':a.x,'y':a.y,'ability_slot':a.ability_slot}
def _opp_dict(a): return {'card_id':a.card_id,'x':a.x,'y':a.y,'ability':a.ability}
def transition_to_dict(tr):
    return {'state':_obs_dict(tr.state),'action':_act_dict(tr.action),'opponent_action':_opp_dict(tr.opponent_action),'reward':tr.reward,'next_state':_obs_dict(tr.next_state),'done':tr.done,'opponent_action_known':tr.opponent_action_known,'legal_action_indices':tr.legal_action_indices,'next_legal_action_indices':tr.next_legal_action_indices}

def save_jsonl(episodes:Iterable[Episode],path:str|Path):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('w',encoding='utf8') as f:
        for ep in episodes:
            ep.validate()
            for step,tr in enumerate(ep.transitions):
                row={'schema':'crgod.replay.v2.1','episode_id':ep.episode_id,'step':step,'transition':transition_to_dict(tr)}
                if ep.privileged_states is not None:
                    row['privileged_state']=ep.privileged_states[step].as_dict()
                f.write(json.dumps(row,separators=(',',':'))+'\n')

def load_jsonl(path:str|Path)->list[Episode]:
    groups={}; privileged={}; privileged_seen={}; last_step={}
    current_eid=None; closed_eids=set()
    with Path(path).open('r',encoding='utf8') as f:
        for line_no,line in enumerate(f,1):
            if not line.strip(): continue
            row=json.loads(line)
            if row.get('schema')!='crgod.replay.v2.1': raise ValueError(f'line {line_no}: unsupported schema')
            eid=str(row['episode_id']); step=int(row['step'])
            if current_eid is None:
                current_eid=eid
            elif eid!=current_eid:
                closed_eids.add(current_eid)
                if eid in closed_eids:
                    raise ValueError(f'line {line_no}: episode {eid} is non-contiguous; chronological split would be ambiguous')
                current_eid=eid
            expected=last_step.get(eid,-1)+1
            if step!=expected: raise ValueError(f'line {line_no}: episode {eid} step {step}, expected {expected}')
            last_step[eid]=step; groups.setdefault(eid,[]).append(transition_from_dict(row['transition']))
            has_priv='privileged_state' in row
            if eid in privileged_seen and privileged_seen[eid] != has_priv:
                raise ValueError(f'line {line_no}: privileged_state must be present for all or none of an episode')
            privileged_seen[eid]=has_priv
            if has_priv: privileged.setdefault(eid,[]).append(true_state_from_dict(row['privileged_state']))
    out=[]
    for eid,trs in groups.items():
        ps=tuple(privileged[eid]) if privileged_seen.get(eid,False) else None
        ep=Episode(tuple(trs),eid,ps); ep.validate(); out.append(ep)
    return out
