from __future__ import annotations
import torch
from torch import nn
from crgod.tensorizer import TensorBatch


class StructuredStateEncoder(nn.Module):
    def __init__(self, card_vocab_size: int, card_dim=48, token_dim=96, latent_dim=256,
                 nhead=4, entity_layers=2, history_layers=1, entity_vocab_size: int | None = None):
        super().__init__(); self.latent_dim = latent_dim
        self.card_emb = nn.Embedding(card_vocab_size, card_dim, padding_idx=0)
        self.entity_emb = nn.Embedding(entity_vocab_size or card_vocab_size, card_dim, padding_idx=0)
        self.team_emb = nn.Embedding(2, 8); self.kind_emb = nn.Embedding(4, 8)
        self.entity_in = nn.Sequential(nn.Linear(card_dim+8+8+9, token_dim), nn.SiLU(), nn.LayerNorm(token_dim))
        el = nn.TransformerEncoderLayer(token_dim, nhead, token_dim*3, 0.0, batch_first=True, norm_first=True)
        self.entity_tf = nn.TransformerEncoder(el, entity_layers, enable_nested_tensor=False)
        self.event_in = nn.Sequential(nn.Linear(card_dim+8+3, token_dim), nn.SiLU(), nn.LayerNorm(token_dim))
        hl = nn.TransformerEncoderLayer(token_dim, nhead, token_dim*2, 0.0, batch_first=True, norm_first=True)
        self.history_tf = nn.TransformerEncoder(hl, history_layers, enable_nested_tensor=False)
        self.global_mlp = nn.Sequential(nn.Linear(21,96), nn.SiLU(), nn.Linear(96,64))
        self.hand_mlp = nn.Sequential(nn.Linear(5*card_dim,128), nn.SiLU(), nn.Linear(128,96))
        self.fuse = nn.Sequential(nn.Linear(64+96+token_dim*2, latent_dim), nn.SiLU(), nn.LayerNorm(latent_dim),
                                  nn.Linear(latent_dim,latent_dim), nn.SiLU())

    @staticmethod
    def _masked_mean(x, mask):
        w=mask.unsqueeze(-1).to(x.dtype); return (x*w).sum(1)/w.sum(1).clamp_min(1.0)

    @staticmethod
    def _safe(tokens, mask):
        mask=mask.clone(); empty=~mask.any(1)
        if empty.any():
            tokens=tokens.clone(); tokens[empty,0]=0.; mask[empty,0]=True
        return tokens,mask

    def forward(self,x:TensorBatch):
        hand=self.hand_mlp(self.card_emb(x.hand_ids).flatten(1)); glob=self.global_mlp(x.global_features)
        ent=torch.cat([self.entity_emb(x.entity_card_ids),self.team_emb(x.entity_team_ids),self.kind_emb(x.entity_kind_ids),x.entity_features],-1)
        ent=self.entity_in(ent); ent,em=self._safe(ent,x.entity_mask); ent=self.entity_tf(ent,src_key_padding_mask=~em); ent=self._masked_mean(ent,em)
        hist=torch.cat([self.card_emb(x.event_card_ids),self.team_emb(x.event_team_ids),x.event_features],-1)
        hist=self.event_in(hist); hist,hm=self._safe(hist,x.event_mask); hist=self.history_tf(hist,src_key_padding_mask=~hm); hist=self._masked_mean(hist,hm)
        # source_ids are intentionally NOT encoded: simulator/vision parity should not be shortcut by domain label.
        return self.fuse(torch.cat([glob,hand,ent,hist],-1))
