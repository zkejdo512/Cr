from torch import nn
from .encoder import StructuredStateEncoder
from .policy import PolicyValueHead
class CRGodNet(nn.Module):
    def __init__(self,card_vocab_size:int,opponent_context_dim=192,**kwargs):
        super().__init__(); self.encoder=StructuredStateEncoder(card_vocab_size=card_vocab_size,**kwargs); self.head=PolicyValueHead(self.encoder.latent_dim,context_dim=opponent_context_dim)
    def forward(self,batch,legal_mask=None,opponent_context=None):
        z=self.encoder(batch); logits,value=self.head(z,opponent_context,legal_mask); return z,logits,value
