from __future__ import annotations
import torch
from torch import nn
from crgod.action_codec import NUM_ACTIONS, NUM_TILES
from crgod.opponent_codec import OpponentActionBatch, PASS_TILE, NUM_OPP_ACTION_KINDS

class LatentWorldModel(nn.Module):
    def __init__(self,card_vocab_size:int,latent_dim=256,own_action_dim=64,opp_card_dim=40,opp_tile_dim=40,hidden_dim=384):
        super().__init__()
        self.own=nn.Embedding(NUM_ACTIONS,own_action_dim)
        self.ocard=nn.Embedding(card_vocab_size,opp_card_dim,padding_idx=0)
        self.otile=nn.Embedding(NUM_TILES+1,opp_tile_dim)
        self.okind=nn.Embedding(NUM_OPP_ACTION_KINDS,8)
        self.dt=nn.Sequential(nn.Linear(1,16),nn.SiLU(),nn.Linear(16,16))
        self.core=nn.Sequential(nn.Linear(latent_dim+own_action_dim+opp_card_dim+opp_tile_dim+8+16,hidden_dim),nn.SiLU(),nn.Linear(hidden_dim,hidden_dim),nn.SiLU())
        self.delta=nn.Linear(hidden_dim,latent_dim); self.reward=nn.Linear(hidden_dim,1); self.cont=nn.Linear(hidden_dim,1); self.legal=nn.Linear(hidden_dim,NUM_ACTIONS)
    def forward(self,z,own_action,opp:OpponentActionBatch,dt_s):
        dt=self.dt(torch.clamp(dt_s,0,5).unsqueeze(-1)/5.)
        h=self.core(torch.cat([z,self.own(own_action),self.ocard(opp.card_token),self.otile(opp.tile.clamp(0,PASS_TILE)),self.okind(opp.kind.clamp(0,NUM_OPP_ACTION_KINDS-1)),dt],-1))
        zn=z+.25*torch.tanh(self.delta(h))
        return zn,self.reward(h).squeeze(-1),self.cont(h).squeeze(-1),self.legal(h)

ResidualWorldModel=LatentWorldModel
