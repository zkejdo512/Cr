from __future__ import annotations
from dataclasses import dataclass
import torch
from torch import nn
from crgod.action_codec import NUM_ACTIONS, NUM_TILES
from crgod.opponent_codec import OpponentActionBatch, PASS_TILE, NUM_OPP_ACTION_KINDS


@dataclass
class BeliefPrediction:
    hidden: torch.Tensor
    opponent_elixir: torch.Tensor      # normalized to [0, 1]
    hand_presence_logits: torch.Tensor # multi-label over card vocabulary
    next_card_logits: torch.Tensor     # categorical over card vocabulary
    style: torch.Tensor                # normalized opponent-style embedding


class RecurrentBeliefModel(nn.Module):
    """Recurrent POMDP belief state.

    The policy never receives privileged opponent hand/elixir directly. During
    supervised auxiliary training, privileged simulator/replay labels may be
    used only as targets for these prediction heads.
    """
    def __init__(self, card_vocab_size: int, latent_dim: int = 256,
                 hidden_dim: int = 192, own_action_dim: int = 48,
                 opp_card_dim: int = 40, opp_tile_dim: int = 32,
                 style_dim: int = 64):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.style_dim = style_dim
        self.own_action_emb = nn.Embedding(NUM_ACTIONS, own_action_dim)
        self.opp_card_emb = nn.Embedding(card_vocab_size, opp_card_dim, padding_idx=0)
        self.opp_tile_emb = nn.Embedding(NUM_TILES + 1, opp_tile_dim)
        self.opp_kind_emb = nn.Embedding(NUM_OPP_ACTION_KINDS, 8)
        self.dt_mlp = nn.Sequential(nn.Linear(1, 16), nn.SiLU(), nn.Linear(16, 16))
        inp = latent_dim + own_action_dim + opp_card_dim + opp_tile_dim + 8 + 1 + 16
        self.gru = nn.GRUCell(inp, hidden_dim)
        self.elixir_head = nn.Sequential(nn.Linear(hidden_dim, 96), nn.SiLU(), nn.Linear(96, 1))
        self.hand_head = nn.Linear(hidden_dim, card_vocab_size)
        self.next_head = nn.Linear(hidden_dim, card_vocab_size)
        self.style_head = nn.Sequential(nn.Linear(hidden_dim, style_dim), nn.Tanh())

    def initial(self, batch: int, device=None, dtype=None) -> torch.Tensor:
        return torch.zeros(batch, self.hidden_dim, device=device, dtype=dtype)

    def step(self, z: torch.Tensor, prev_own_action: torch.Tensor,
             observed_opp_action: OpponentActionBatch,
             opponent_action_known: torch.Tensor, dt_s: torch.Tensor,
             hidden: torch.Tensor) -> BeliefPrediction:
        known = opponent_action_known.to(z.dtype).unsqueeze(-1)
        dt = self.dt_mlp(torch.clamp(dt_s, 0, 5).unsqueeze(-1) / 5.0)
        # Unknown opponent actions must not be silently interpreted as pass or
        # leak a placeholder card/tile. The explicit known bit tells the GRU
        # whether these action features are trustworthy.
        opp_card = self.opp_card_emb(observed_opp_action.card_token) * known
        opp_tile = self.opp_tile_emb(observed_opp_action.tile.clamp(0, PASS_TILE)) * known
        opp_kind = self.opp_kind_emb(observed_opp_action.kind.clamp(0, NUM_OPP_ACTION_KINDS - 1)) * known
        x = torch.cat([
            z,
            self.own_action_emb(prev_own_action),
            opp_card,
            opp_tile,
            opp_kind,
            known,
            dt,
        ], dim=-1)
        h = self.gru(x, hidden)
        elixir = torch.sigmoid(self.elixir_head(h).squeeze(-1))
        style = self.style_head(h)
        style = style / style.norm(dim=-1, keepdim=True).clamp_min(1e-6)
        return BeliefPrediction(h, elixir, self.hand_head(h), self.next_head(h), style)
