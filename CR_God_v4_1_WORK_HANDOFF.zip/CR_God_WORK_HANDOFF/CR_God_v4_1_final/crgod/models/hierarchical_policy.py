from __future__ import annotations
from dataclasses import dataclass
import math
import torch
from torch import nn
from crgod.action_codec import GRID_W, GRID_H, NUM_TILES, NUM_ACTIONS, ABILITY_BASE
from crgod.models.policy import mask_logits


@dataclass
class HierarchicalLogits:
    pass_logit: torch.Tensor
    slot_logits: torch.Tensor
    tile_logits: torch.Tensor
    ability_logits: torch.Tensor
    flat_logits: torch.Tensor


def _fourier_grid() -> torch.Tensor:
    xs = (torch.arange(GRID_W, dtype=torch.float32) + 0.5) / GRID_W
    ys = (torch.arange(GRID_H, dtype=torch.float32) + 0.5) / GRID_H
    yy, xx = torch.meshgrid(ys, xs, indexing='ij')
    feats = [xx, yy, xx * yy, xx.square(), yy.square()]
    for f in (1.0, 2.0, 4.0):
        for v in (xx, yy):
            feats += [torch.sin(2 * math.pi * f * v), torch.cos(2 * math.pi * f * v)]
    return torch.stack(feats, dim=-1).reshape(NUM_TILES, -1)


class HierarchicalPolicyValueHead(nn.Module):
    """Factorized action head with spatial coordinate structure.

    Flat logits remain available for Hasty/PPO compatibility, but placement
    logits are composed from card-slot preference plus a spatial score map.
    """
    def __init__(self, latent_dim: int = 256, belief_dim: int = 192,
                 hidden_dim: int = 256, spatial_dim: int = 64):
        super().__init__()
        self.belief_dim = belief_dim
        self.state_proj = nn.Linear(latent_dim, hidden_dim)
        self.belief_proj = nn.Linear(belief_dim, hidden_dim, bias=False)
        # Tiny non-zero init preserves the BC policy approximately while still
        # allowing RL gradients to reach the recurrent belief model on step 1.
        nn.init.normal_(self.belief_proj.weight, mean=0.0, std=1e-3)
        self.trunk = nn.Sequential(nn.SiLU(), nn.LayerNorm(hidden_dim), nn.Linear(hidden_dim, hidden_dim), nn.SiLU())
        self.pass_head = nn.Linear(hidden_dim, 1)
        self.slot_head = nn.Linear(hidden_dim, 4)
        self.ability_head = nn.Linear(hidden_dim, 16)
        self.slot_query = nn.Linear(hidden_dim, 4 * spatial_dim)
        grid = _fourier_grid()
        self.register_buffer('grid_features', grid, persistent=False)
        self.grid_encoder = nn.Sequential(nn.Linear(grid.shape[-1], spatial_dim), nn.SiLU(), nn.Linear(spatial_dim, spatial_dim))
        self.slot_spatial_bias = nn.Parameter(torch.zeros(4, NUM_TILES))
        self.value = nn.Sequential(nn.Linear(hidden_dim, hidden_dim // 2), nn.SiLU(), nn.Linear(hidden_dim // 2, 1))

    def components(self, z: torch.Tensor, belief: torch.Tensor | None = None,
                   legal_mask: torch.Tensor | None = None) -> tuple[HierarchicalLogits, torch.Tensor]:
        if belief is None:
            belief = torch.zeros(z.shape[0], self.belief_dim, device=z.device, dtype=z.dtype)
        h = self.trunk(self.state_proj(z) + self.belief_proj(belief))
        pass_l = self.pass_head(h)
        slot_l = self.slot_head(h)
        ability_l = self.ability_head(h)
        q = self.slot_query(h).view(z.shape[0], 4, -1)
        keys = self.grid_encoder(self.grid_features.to(dtype=z.dtype))
        tile_l = torch.einsum('bsd,td->bst', q, keys) / math.sqrt(q.shape[-1])
        tile_l = tile_l + self.slot_spatial_bias.unsqueeze(0)
        placement = (slot_l.unsqueeze(-1) + tile_l).reshape(z.shape[0], 4 * NUM_TILES)
        flat = torch.cat([pass_l, placement, ability_l], dim=-1)
        if flat.shape[-1] != NUM_ACTIONS or ABILITY_BASE != 1 + 4 * NUM_TILES:
            raise RuntimeError('hierarchical action layout drifted from canonical codec')
        flat = mask_logits(flat, legal_mask)
        return HierarchicalLogits(pass_l, slot_l, tile_l, ability_l, flat), self.value(h).squeeze(-1)

    def forward(self, z: torch.Tensor, belief: torch.Tensor | None = None,
                legal_mask: torch.Tensor | None = None):
        c, v = self.components(z, belief, legal_mask)
        return c.flat_logits, v
