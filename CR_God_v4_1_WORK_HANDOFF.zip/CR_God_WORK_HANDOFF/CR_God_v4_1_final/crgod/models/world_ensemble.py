import torch
from torch import nn
from .world_model import LatentWorldModel
class WorldModelEnsemble(nn.Module):
    def __init__(self,members=3,**kwargs):
        super().__init__(); self.models=nn.ModuleList([LatentWorldModel(**kwargs) for _ in range(members)])
    def forward_all(self,z,a,oa,dt):
        p=[m(z,a,oa,dt) for m in self.models]; return *(torch.stack([x[i] for x in p],0) for i in range(4)),
    @torch.no_grad()
    def conservative_prediction(self,z,a,oa,dt,uncertainty_penalty=.5):
        zs,rs,cs,ls=self.forward_all(z,a,oa,dt); std=zs.std(0,unbiased=False); scale=zs.abs().mean(0).clamp_min(.1); u=rs.std(0,unbiased=False)+.1*(std/scale).mean(-1); return zs.mean(0),rs.mean(0)-uncertainty_penalty*u,cs.mean(0),ls.mean(0),u
