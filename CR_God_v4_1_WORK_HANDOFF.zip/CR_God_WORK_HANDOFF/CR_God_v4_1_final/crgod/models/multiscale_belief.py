from __future__ import annotations
from dataclasses import dataclass
import torch
from torch import nn

from crgod.action_codec import NUM_ACTIONS, NUM_TILES
from crgod.opponent_codec import OpponentActionBatch, PASS_TILE, NUM_OPP_ACTION_KINDS


@dataclass
class MultiScaleBeliefPrediction:
    hidden: torch.Tensor
    opponent_elixir: torch.Tensor
    hand_presence_logits: torch.Tensor
    next_card_logits: torch.Tensor
    style: torch.Tensor
    slow_gate: torch.Tensor


class MultiScaleRecurrentBeliefModel(nn.Module):
    """Two-timescale recurrent belief state for partial observability.

    The fast state tracks tactical context (seconds). The slow state tracks
    opponent style/cycle context (tens of seconds to a whole match). Both are
    packed into one tensor so existing PPO/V-trace infrastructure can remain
    unchanged and auditable.
    """
    def __init__(self, card_vocab_size:int, latent_dim:int=256,
                 fast_dim:int=128, slow_dim:int=96,
                 own_action_dim:int=48, opp_card_dim:int=40,
                 opp_tile_dim:int=32, style_dim:int=64):
        super().__init__()
        self.fast_dim=int(fast_dim); self.slow_dim=int(slow_dim)
        self.hidden_dim=self.fast_dim+self.slow_dim
        self.style_dim=int(style_dim)
        self.own_action_emb=nn.Embedding(NUM_ACTIONS,own_action_dim)
        self.opp_card_emb=nn.Embedding(card_vocab_size,opp_card_dim,padding_idx=0)
        self.opp_tile_emb=nn.Embedding(NUM_TILES+1,opp_tile_dim)
        self.opp_kind_emb=nn.Embedding(NUM_OPP_ACTION_KINDS,8)
        self.dt_mlp=nn.Sequential(nn.Linear(1,16),nn.SiLU(),nn.Linear(16,16))
        base_dim=latent_dim+own_action_dim+opp_card_dim+opp_tile_dim+8+1+16
        self.fast_gru=nn.GRUCell(base_dim+self.slow_dim,self.fast_dim)
        self.slow_gru=nn.GRUCell(latent_dim+self.fast_dim+1+16,self.slow_dim)
        # Learned update gate lets slow memory update aggressively after salient
        # opponent actions while remaining stable during quiet tactical frames.
        self.slow_gate=nn.Sequential(
            nn.Linear(latent_dim+self.fast_dim+self.slow_dim+1+16,96),
            nn.SiLU(), nn.Linear(96,1), nn.Sigmoid())
        # Start genuinely slow (~7.6% update/step) while keeping the gate learnable.
        nn.init.zeros_(self.slow_gate[2].weight)
        nn.init.constant_(self.slow_gate[2].bias,-2.5)
        out_dim=self.hidden_dim
        self.elixir_head=nn.Sequential(nn.Linear(out_dim,96),nn.SiLU(),nn.Linear(96,1))
        self.hand_head=nn.Linear(out_dim,card_vocab_size)
        self.next_head=nn.Linear(out_dim,card_vocab_size)
        self.style_head=nn.Sequential(nn.Linear(self.slow_dim,style_dim),nn.Tanh())

    def initial(self,batch:int,device=None,dtype=None)->torch.Tensor:
        return torch.zeros(batch,self.hidden_dim,device=device,dtype=dtype)

    def split(self,h:torch.Tensor)->tuple[torch.Tensor,torch.Tensor]:
        if h.shape[-1]!=self.hidden_dim:
            raise ValueError(f'multiscale hidden dim mismatch {h.shape[-1]} != {self.hidden_dim}')
        return h[...,:self.fast_dim],h[...,self.fast_dim:]

    def step(self,z:torch.Tensor,prev_own_action:torch.Tensor,
             observed_opp_action:OpponentActionBatch,
             opponent_action_known:torch.Tensor,dt_s:torch.Tensor,
             hidden:torch.Tensor)->MultiScaleBeliefPrediction:
        fast,slow=self.split(hidden)
        known=opponent_action_known.to(z.dtype).unsqueeze(-1)
        dt_norm=torch.clamp(dt_s,0,10).unsqueeze(-1)/10.0
        dt=self.dt_mlp(dt_norm)
        opp_card=self.opp_card_emb(observed_opp_action.card_token)*known
        opp_tile=self.opp_tile_emb(observed_opp_action.tile.clamp(0,PASS_TILE))*known
        opp_kind=self.opp_kind_emb(observed_opp_action.kind.clamp(0,NUM_OPP_ACTION_KINDS-1))*known
        base=torch.cat([z,self.own_action_emb(prev_own_action),opp_card,opp_tile,opp_kind,known,dt],dim=-1)
        fast_new=self.fast_gru(torch.cat([base,slow],dim=-1),fast)
        slow_candidate=self.slow_gru(torch.cat([z,fast_new,known,dt],dim=-1),slow)
        gate=self.slow_gate(torch.cat([z,fast_new,slow,known,dt],dim=-1))
        # Time-aware floor: even quiet states slowly refresh over long intervals.
        time_floor=torch.clamp(dt_s.unsqueeze(-1)/30.0,0.0,0.25)
        gate=torch.maximum(gate,time_floor)
        slow_new=(1.0-gate)*slow+gate*slow_candidate
        h=torch.cat([fast_new,slow_new],dim=-1)
        elixir=torch.sigmoid(self.elixir_head(h).squeeze(-1))
        style=self.style_head(slow_new)
        style=style/style.norm(dim=-1,keepdim=True).clamp_min(1e-6)
        return MultiScaleBeliefPrediction(h,elixir,self.hand_head(h),self.next_head(h),style,gate.squeeze(-1))
