from __future__ import annotations
import torch
from torch import nn
from crgod.action_codec import NUM_ACTIONS


def mask_logits(logits, legal_mask):
    if legal_mask is None: return logits
    if legal_mask.dtype != torch.bool or legal_mask.shape != logits.shape: raise ValueError("bad legal mask")
    if not bool(legal_mask[:,0].all()): raise ValueError("pass must be legal")
    return logits.masked_fill(~legal_mask,-1e9)


class PolicyValueHead(nn.Module):
    def __init__(self, latent_dim=256, num_actions=NUM_ACTIONS, context_dim=192):
        super().__init__(); self.context_dim=context_dim; self.act=nn.SiLU()
        self.state_proj=nn.Linear(latent_dim,latent_dim); self.context_proj=nn.Linear(context_dim,latent_dim,bias=False); nn.init.zeros_(self.context_proj.weight)
        self.policy_out=nn.Linear(latent_dim,num_actions)
        self.value_state=nn.Linear(latent_dim,latent_dim//2); self.value_context=nn.Linear(context_dim,latent_dim//2,bias=False); nn.init.zeros_(self.value_context.weight)
        self.value_out=nn.Linear(latent_dim//2,1)
    def forward(self,z,context=None,legal_mask=None):
        if context is None: context=torch.zeros(z.shape[0],self.context_dim,device=z.device,dtype=z.dtype)
        h=self.act(self.state_proj(z)+self.context_proj(context)); logits=mask_logits(self.policy_out(h),legal_mask)
        v=self.value_out(self.act(self.value_state(z)+self.value_context(context))).squeeze(-1)
        return logits,v
