from __future__ import annotations
import torch
from torch import nn
from crgod.models.encoder import StructuredStateEncoder
from crgod.models.multiscale_belief import MultiScaleRecurrentBeliefModel, MultiScaleBeliefPrediction
from crgod.models.hierarchical_policy import HierarchicalPolicyValueHead
from crgod.opponent_codec import OpponentActionBatch


class CRGodV4Net(nn.Module):
    """v4 policy: structured encoder + fast/slow recurrent belief + hierarchical actions."""
    def __init__(self,card_vocab_size:int,latent_dim:int=256,
                 fast_belief_dim:int=128,slow_belief_dim:int=96,
                 entity_vocab_size:int|None=None,**encoder_kwargs):
        super().__init__()
        self.encoder=StructuredStateEncoder(card_vocab_size=card_vocab_size,
                                             entity_vocab_size=entity_vocab_size,
                                             latent_dim=latent_dim,**encoder_kwargs)
        self.belief=MultiScaleRecurrentBeliefModel(card_vocab_size,latent_dim=latent_dim,
                                                   fast_dim=fast_belief_dim,slow_dim=slow_belief_dim)
        self.head=HierarchicalPolicyValueHead(latent_dim=latent_dim,belief_dim=self.belief.hidden_dim)

    def initial_belief(self,batch:int,device=None,dtype=None):
        return self.belief.initial(batch,device,dtype)
    def encode(self,batch): return self.encoder(batch)
    def update_belief(self,z:torch.Tensor,prev_own_action:torch.Tensor,
                      opp_action:OpponentActionBatch,opp_known:torch.Tensor,
                      dt_s:torch.Tensor,hidden:torch.Tensor)->MultiScaleBeliefPrediction:
        return self.belief.step(z,prev_own_action,opp_action,opp_known,dt_s,hidden)
    def policy_from_latent(self,z:torch.Tensor,belief_h:torch.Tensor,legal_mask=None):
        return self.head(z,belief_h,legal_mask)
    def forward(self,batch,legal_mask=None,belief_h=None):
        z=self.encoder(batch)
        if belief_h is None: belief_h=self.initial_belief(z.shape[0],z.device,z.dtype)
        logits,value=self.head(z,belief_h,legal_mask)
        return z,logits,value
