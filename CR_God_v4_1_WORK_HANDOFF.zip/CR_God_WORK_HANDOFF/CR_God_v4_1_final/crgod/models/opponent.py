from __future__ import annotations
from dataclasses import dataclass
import torch
from torch import nn
from crgod.action_codec import NUM_TILES
from crgod.opponent_codec import (OpponentActionBatch, PASS_TILE, OPP_PASS,
                                  OPP_PLAY_CARD, OPP_ABILITY,
                                  NUM_OPP_ACTION_KINDS)

@dataclass
class OpponentPrediction:
    kind_logits: torch.Tensor
    card_logits: torch.Tensor
    tile_logits: torch.Tensor

class OpponentModel(nn.Module):
    def __init__(self,card_vocab_size:int,latent_dim=256,hidden_dim=192,card_dim=48,tile_dim=48):
        super().__init__(); self.hidden_dim=hidden_dim
        self.card_emb=nn.Embedding(card_vocab_size,card_dim,padding_idx=0)
        self.tile_emb=nn.Embedding(NUM_TILES+1,tile_dim)
        self.kind_emb=nn.Embedding(NUM_OPP_ACTION_KINDS,8)
        self.gru=nn.GRUCell(latent_dim+card_dim+tile_dim+8,hidden_dim)
        self.trunk=nn.Sequential(nn.Linear(latent_dim+hidden_dim,256),nn.SiLU())
        self.kind_head=nn.Linear(256,NUM_OPP_ACTION_KINDS)
        self.card_head=nn.Linear(256,card_vocab_size)
        self.tile_head=nn.Linear(256,NUM_TILES)
    def initial(self,batch,device=None): return torch.zeros(batch,self.hidden_dim,device=device)
    def update(self,z,a:OpponentActionBatch,h):
        x=torch.cat([z,self.card_emb(a.card_token),self.tile_emb(a.tile.clamp(0,PASS_TILE)),self.kind_emb(a.kind)],-1)
        return self.gru(x,h)
    def predict(self,z,h):
        x=self.trunk(torch.cat([z,h],-1)); card=self.card_head(x)
        m=torch.zeros_like(card,dtype=torch.bool); m[:,0]=True; card=card.masked_fill(m,-1e9)
        return OpponentPrediction(self.kind_head(x),card,self.tile_head(x))
    @torch.no_grad()
    def sample(self,z,h):
        p=self.predict(z,h)
        kind=torch.distributions.Categorical(logits=p.kind_logits).sample()
        card=torch.distributions.Categorical(logits=p.card_logits).sample()
        tile=torch.distributions.Categorical(logits=p.tile_logits).sample()
        is_pass=kind==OPP_PASS; is_ability=kind==OPP_ABILITY
        card=torch.where(is_pass,torch.zeros_like(card),card)
        tile=torch.where(is_pass|is_ability,torch.full_like(tile,PASS_TILE),tile)
        return OpponentActionBatch(kind,card,tile)
