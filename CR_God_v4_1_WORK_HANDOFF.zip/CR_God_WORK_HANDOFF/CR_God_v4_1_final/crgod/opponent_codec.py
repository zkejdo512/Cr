from __future__ import annotations

from dataclasses import dataclass
import torch

from .action_codec import GRID_H, GRID_W, NUM_TILES
from .contracts import ObservedOpponentActionV1
from .vocab import CardVocabulary, PAD_TOKEN

PASS_TILE = NUM_TILES
OPP_PASS = 0
OPP_PLAY_CARD = 1
OPP_ABILITY = 2
NUM_OPP_ACTION_KINDS = 3


@dataclass
class OpponentActionBatch:
    kind: torch.Tensor              # 0 pass, 1 card placement, 2 ability press
    card_token: torch.Tensor        # deployed card or ability-source identity
    tile: torch.Tensor              # PASS_TILE for pass/ability

    @property
    def is_pass(self) -> torch.Tensor:
        return self.kind == OPP_PASS

    @property
    def is_ability(self) -> torch.Tensor:
        return self.kind == OPP_ABILITY

    def to(self, device):
        self.kind = self.kind.to(device)
        self.card_token = self.card_token.to(device)
        self.tile = self.tile.to(device)
        return self

    def __getitem__(self, item):
        return OpponentActionBatch(self.kind[item], self.card_token[item], self.tile[item])

    @classmethod
    def pass_batch(cls, n: int, device=None) -> 'OpponentActionBatch':
        return cls(torch.zeros(n, dtype=torch.long, device=device),
                   torch.zeros(n, dtype=torch.long, device=device),
                   torch.full((n,), PASS_TILE, dtype=torch.long, device=device))


def xy_to_tile(x: float, y: float) -> int:
    gx = min(GRID_W - 1, max(0, int(x * GRID_W)))
    gy = min(GRID_H - 1, max(0, int(y * GRID_H)))
    return gy * GRID_W + gx


def encode_observed_action(a: ObservedOpponentActionV1, vocab: CardVocabulary) -> tuple[int, int, int]:
    a.validate()
    if a.is_pass:
        return OPP_PASS, PAD_TOKEN, PASS_TILE
    if a.is_ability:
        return OPP_ABILITY, vocab.encode(int(a.card_id)), PASS_TILE
    return OPP_PLAY_CARD, vocab.encode(int(a.card_id)), xy_to_tile(float(a.x), float(a.y))
