from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, runtime_checkable

from crgod.action_codec import NUM_ACTIONS
from crgod.contracts import PlayerObservationV1, ObservedOpponentActionV1, TrueBattleStateV1


@dataclass(frozen=True)
class SeatFrame:
    """One player's canonical (self-at-bottom) decision view."""
    observation: PlayerObservationV1
    legal_action_indices: tuple[int, ...]

    def validate(self) -> None:
        if not isinstance(self.observation, PlayerObservationV1):
            raise TypeError('SeatFrame.observation must be PlayerObservationV1')
        if not self.legal_action_indices:
            raise ValueError('legal_action_indices may not be empty')
        if 0 not in self.legal_action_indices:
            raise ValueError('pass action 0 must always be legal')
        if len(set(self.legal_action_indices)) != len(self.legal_action_indices):
            raise ValueError('duplicate legal action index')
        if min(self.legal_action_indices) < 0 or max(self.legal_action_indices) >= NUM_ACTIONS:
            raise ValueError('legal action outside canonical action space')


@dataclass(frozen=True)
class JointFrame:
    """Simultaneous two-seat frame used by self-play actors.

    `privileged_state` is optional and is NEVER a policy input. It exists only
    for auxiliary belief targets, diagnostics and simulator calibration.
    """
    seat_a: SeatFrame
    seat_b: SeatFrame
    t_s: float
    privileged_state: TrueBattleStateV1 | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        self.seat_a.validate(); self.seat_b.validate()
        if abs(float(self.seat_a.observation.t_s) - float(self.t_s)) > 1e-6:
            raise ValueError('seat_a observation time does not match JointFrame')
        if abs(float(self.seat_b.observation.t_s) - float(self.t_s)) > 1e-6:
            raise ValueError('seat_b observation time does not match JointFrame')


@dataclass(frozen=True)
class RewardComponents:
    """Optional decomposed reward signal.

    The terminal result should be the only component that is never annealed
    away. Other components are training aids and must not silently redefine the
    game objective.
    """
    terminal: float = 0.0
    tower_damage: float = 0.0
    crown: float = 0.0
    elixir: float = 0.0
    tactical: float = 0.0


@dataclass(frozen=True)
class JointStepResult:
    next_frame: JointFrame
    reward_a: float
    reward_b: float
    done: bool
    action_a_observed_by_b: ObservedOpponentActionV1
    action_b_observed_by_a: ObservedOpponentActionV1
    action_a_known_to_b: bool = True
    action_b_known_to_a: bool = True
    elapsed_s: float = 0.5
    outcome_a: float | None = None  # terminal: 1 win, .5 draw, 0 loss
    reward_components_a: RewardComponents | None = None
    reward_components_b: RewardComponents | None = None
    metadata: Mapping[str, Any] = field(default_factory=dict)

    def validate(self) -> None:
        self.next_frame.validate()
        if float(self.elapsed_s) <= 0:
            raise ValueError('elapsed_s must be positive')
        self.action_a_observed_by_b.validate(); self.action_b_observed_by_a.validate()
        if self.done:
            if self.outcome_a is None:
                raise ValueError('terminal step must provide outcome_a')
            if not 0.0 <= float(self.outcome_a) <= 1.0:
                raise ValueError('outcome_a must be in [0,1]')
        elif self.outcome_a is not None:
            raise ValueError('nonterminal step must not expose future outcome_a')


@runtime_checkable
class TrainingSimulator(Protocol):
    """Thin simulator contract expected by CR-God training.

    Both seats act once per simulator decision interval. `pass` is the canonical
    no-op, so asynchronous game behaviour can still be represented on a fixed
    decision clock. Each seat's observation must already be canonicalized to
    that seat's perspective.
    """
    simulator_id: str
    decision_interval_s: float

    def reset(self, *, seed: int | None = None, matchup: Mapping[str, Any] | None = None) -> JointFrame: ...
    def step(self, action_a_index: int, action_b_index: int) -> JointStepResult: ...


@runtime_checkable
class SnapshotSimulator(TrainingSimulator, Protocol):
    """Optional planner extension. Training itself does not require this."""
    def snapshot(self) -> Any: ...
    def restore(self, snapshot: Any) -> None: ...


def audit_training_simulator(sim: TrainingSimulator, *, seed: int = 0) -> JointFrame:
    if not isinstance(getattr(sim, 'simulator_id', None), str) or not sim.simulator_id:
        raise TypeError('simulator_id must be a non-empty string')
    if float(getattr(sim, 'decision_interval_s', 0.0)) <= 0:
        raise ValueError('decision_interval_s must be positive')
    frame = sim.reset(seed=seed)
    frame.validate()
    if frame.privileged_state is not None and isinstance(frame.seat_a.observation, TrueBattleStateV1):
        raise TypeError('privileged TrueBattleState leaked into policy observation')
    return frame
