"""CR-God training stack."""
__version__ = "0.4.1"
