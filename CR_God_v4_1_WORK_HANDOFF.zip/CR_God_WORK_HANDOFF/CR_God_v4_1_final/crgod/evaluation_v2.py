from __future__ import annotations
from dataclasses import dataclass, field
import math


@dataclass
class MatchResult:
    win: float                 # 1 win, .5 draw, 0 loss
    crown_diff: float = 0.0
    tower_damage_diff: float = 0.0
    elixir_efficiency: float = 0.0
    prediction_spell_hit: float | None = None
    enemy_elixir_abs_error: float | None = None
    illegal_actions: int = 0
    actions: int = 0
    archetype: str = 'unknown'


@dataclass
class EvalSummary:
    games: int
    win_rate: float
    win_rate_ci95: tuple[float,float]
    crown_diff: float
    tower_damage_diff: float
    illegal_action_rate: float
    prediction_spell_hit_rate: float | None
    enemy_elixir_mae: float | None
    by_archetype: dict[str,float] = field(default_factory=dict)
    worst_archetype_win_rate: float | None = None


def _wilson(p: float, n: int, z: float = 1.96):
    if n <= 0: return (0.0,1.0)
    den=1+z*z/n; center=(p+z*z/(2*n))/den
    half=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
    return max(0.,center-half),min(1.,center+half)


def summarize_matches(results: list[MatchResult]) -> EvalSummary:
    if not results: raise ValueError('empty evaluation')
    n=len(results); wr=sum(x.win for x in results)/n
    total_a=sum(x.actions for x in results); illegal=sum(x.illegal_actions for x in results)
    ph=[x.prediction_spell_hit for x in results if x.prediction_spell_hit is not None]
    ee=[x.enemy_elixir_abs_error for x in results if x.enemy_elixir_abs_error is not None]
    groups={}
    for x in results: groups.setdefault(x.archetype,[]).append(x.win)
    by={k:sum(v)/len(v) for k,v in groups.items()}
    return EvalSummary(n,wr,_wilson(wr,n),sum(x.crown_diff for x in results)/n,
                       sum(x.tower_damage_diff for x in results)/n,
                       illegal/max(total_a,1), None if not ph else sum(ph)/len(ph),
                       None if not ee else sum(ee)/len(ee), by,
                       None if not by else min(by.values()))

@dataclass(frozen=True)
class PairedOutcome:
    baseline_score: float
    candidate_score: float
    seed: int
    archetype: str = 'unknown'

@dataclass(frozen=True)
class ABGateResult:
    pairs: int
    mean_delta: float
    candidate_better: int
    baseline_better: int
    ties: int
    sign_test_p: float
    worst_archetype_delta: float
    passed: bool
    reason: str


def _binom_two_sided(k:int,n:int)->float:
    if n<=0: return 1.0
    lo=min(k,n-k)
    tail=sum(math.comb(n,i) for i in range(lo+1))/(2**n)
    return min(1.0,2.0*tail)


def paired_ab_gate(rows:list[PairedOutcome],min_pairs:int=100,min_delta:float=.02,
                   alpha:float=.05,max_worst_archetype_regression:float=.03)->ABGateResult:
    if not rows: raise ValueError('empty paired A/B')
    deltas=[float(x.candidate_score-x.baseline_score) for x in rows]
    better=sum(d>1e-12 for d in deltas); worse=sum(d<-1e-12 for d in deltas); ties=len(rows)-better-worse
    p=_binom_two_sided(better,better+worse)
    groups={}
    for row,d in zip(rows,deltas): groups.setdefault(row.archetype,[]).append(d)
    worst=min(sum(v)/len(v) for v in groups.values())
    mean=sum(deltas)/len(deltas)
    reasons=[]
    if len(rows)<min_pairs: reasons.append(f'{len(rows)}<{min_pairs} paired games')
    if mean<min_delta: reasons.append(f'mean delta {mean:.3f}<{min_delta:.3f}')
    if p>alpha: reasons.append(f'sign-test p={p:.3g}>{alpha}')
    if worst < -max_worst_archetype_regression: reasons.append(f'worst archetype delta {worst:.3f} below {-max_worst_archetype_regression:.3f}')
    return ABGateResult(len(rows),mean,better,worse,ties,p,worst,not reasons,'passed' if not reasons else '; '.join(reasons))
