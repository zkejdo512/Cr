from __future__ import annotations
from dataclasses import dataclass, asdict
import json, math
from typing import Callable
import torch


@dataclass(frozen=True)
class AdaptivePlanContext:
    terminal_urgency: float = 0.0   # 0..1
    value_uncertainty: float = 0.0  # >=0
    archetype_risk: float = 0.0     # 0..1


@dataclass(frozen=True)
class PlannerBudget:
    top_k: int
    rollout_samples: int
    use_slow: bool
    score: float


@dataclass(frozen=True)
class RolloutEstimateV4:
    mean_value: float
    std_value: float=0.0
    samples: int=1


@dataclass
class CandidateTraceV4:
    action_index:int
    policy_logprob:float
    rollout_mean:float
    rollout_std:float
    samples:int
    score:float


@dataclass
class DecisionTraceV4:
    fast_action:int
    chosen_action:int
    budget:PlannerBudget
    normalized_entropy:float
    top_margin:float
    candidates:list[CandidateTraceV4]
    def to_json(self)->str:return json.dumps(asdict(self),ensure_ascii=False,indent=2)


class AdaptiveComputeController:
    """Allocates simulator search only when uncertainty/importance justify it."""
    def __init__(self,min_top_k:int=4,max_top_k:int=16,min_samples:int=1,max_samples:int=8,
                 trigger_score:float=.45):
        self.min_top_k=int(min_top_k);self.max_top_k=int(max_top_k)
        self.min_samples=int(min_samples);self.max_samples=int(max_samples)
        self.trigger_score=float(trigger_score)
    def budget(self,entropy:float,margin:float,ctx:AdaptivePlanContext)->PlannerBudget:
        if not all(math.isfinite(float(x)) for x in (entropy,margin,ctx.terminal_urgency,ctx.value_uncertainty,ctx.archetype_risk)):
            raise ValueError('non-finite adaptive planning signal')
        margin_unc=1.0/(1.0+max(0.0,margin))
        vu=min(max(ctx.value_uncertainty,0.0),2.0)/2.0
        score=(.35*min(max(entropy,0.),1.)+.20*margin_unc+.20*min(max(ctx.terminal_urgency,0.),1.)+
               .15*vu+.10*min(max(ctx.archetype_risk,0.),1.))
        use=score>=self.trigger_score
        frac=min(max((score-self.trigger_score)/max(1e-6,1-self.trigger_score),0.),1.) if use else 0.
        k=round(self.min_top_k+frac*(self.max_top_k-self.min_top_k))
        s=round(self.min_samples+frac*(self.max_samples-self.min_samples))
        return PlannerBudget(int(k),int(s),bool(use),float(score))


class AdaptiveFastSlowPlannerV4:
    def __init__(self,controller:AdaptiveComputeController|None=None,uncertainty_penalty:float=.5,prior_weight:float=.03):
        self.controller=controller or AdaptiveComputeController()
        self.uncertainty_penalty=float(uncertainty_penalty);self.prior_weight=float(prior_weight)

    @staticmethod
    def uncertainty(logits:torch.Tensor,legal_mask:torch.Tensor)->tuple[float,float]:
        legal=logits[legal_mask]
        if legal.numel()<=1:return 0.0,float('inf')
        lp=torch.log_softmax(legal,dim=-1);p=lp.exp()
        ent=float((-(p*lp).sum()/math.log(legal.numel())).detach())
        top2=torch.topk(legal,2).values; margin=float((top2[0]-top2[1]).detach())
        return ent,margin

    @torch.no_grad()
    def decide(self,logits:torch.Tensor,legal_mask:torch.Tensor,
               rollout:Callable[[int,int],RolloutEstimateV4]|None=None,
               context:AdaptivePlanContext=AdaptivePlanContext(),force_slow:bool=False)->DecisionTraceV4:
        if logits.ndim!=1 or legal_mask.ndim!=1 or logits.shape!=legal_mask.shape:raise ValueError('1-D logits/mask required')
        if not bool(legal_mask[0]):raise ValueError('pass must be legal')
        masked=logits.masked_fill(~legal_mask,-1e9);fast=int(masked.argmax())
        ent,margin=self.uncertainty(masked,legal_mask);budget=self.controller.budget(ent,margin,context)
        if force_slow:budget=PlannerBudget(max(budget.top_k,self.controller.min_top_k),max(budget.rollout_samples,self.controller.min_samples),True,1.0)
        if rollout is None or not budget.use_slow:return DecisionTraceV4(fast,fast,budget,ent,margin,[])
        k=min(budget.top_k,int(legal_mask.sum())); top=torch.topk(masked,k); lp=torch.log_softmax(masked,dim=-1); traces=[]
        for idx in top.indices.tolist():
            est=rollout(int(idx),budget.rollout_samples)
            if est.samples<=0:raise ValueError('rollout must report positive sample count')
            score=float(est.mean_value-self.uncertainty_penalty*est.std_value+self.prior_weight*float(lp[idx]))
            traces.append(CandidateTraceV4(int(idx),float(lp[idx]),float(est.mean_value),float(est.std_value),int(est.samples),score))
        best=max(traces,key=lambda x:x.score)
        return DecisionTraceV4(fast,best.action_index,budget,ent,margin,traces)
