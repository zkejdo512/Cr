from __future__ import annotations
from dataclasses import dataclass, asdict
from enum import Enum
import json, math, os
from pathlib import Path
import torch


class Decision(str,Enum):
    CONTINUE='continue'; KEEP_BEST='keep_best'; ROLLBACK='rollback'; STOP='stop'

@dataclass(frozen=True)
class TrainingSnapshot:
    step: int
    heldout_win_rate: float
    worst_archetype_win_rate: float
    illegal_action_rate: float
    approx_kl: float
    policy_entropy: float
    eval_games: int
    finite: bool = True

@dataclass(frozen=True)
class SupervisorEvent:
    decision: Decision
    reason: str
    best_step: int | None
    best_win_rate: float | None

class TrainingSupervisor:
    """Fail-closed guard for unattended RL runs.

    It intentionally keys off held-out behaviour and policy drift, not training
    loss.  A caller owns process restart/hyperparameter changes; this class makes
    the keep/rollback/stop decision deterministic and testable.
    """
    def __init__(self,min_eval_games=60,improvement=0.015,max_regression=0.04,
                 max_kl=0.05,max_illegal=0.0,patience=2,min_worst_archetype_drop=0.06):
        self.min_eval_games=int(min_eval_games); self.improvement=float(improvement)
        self.max_regression=float(max_regression); self.max_kl=float(max_kl)
        self.max_illegal=float(max_illegal); self.patience=int(patience)
        self.max_worst_drop=float(min_worst_archetype_drop)
        self.best: TrainingSnapshot|None=None; self.bad=0

    def observe(self,s:TrainingSnapshot)->SupervisorEvent:
        vals=(s.heldout_win_rate,s.worst_archetype_win_rate,s.illegal_action_rate,s.approx_kl,s.policy_entropy)
        if not s.finite or any(not math.isfinite(float(x)) for x in vals):
            return SupervisorEvent(Decision.STOP,'non-finite training/eval metric',None if self.best is None else self.best.step,None if self.best is None else self.best.heldout_win_rate)
        if s.illegal_action_rate>self.max_illegal:
            return SupervisorEvent(Decision.ROLLBACK,f'illegal action rate {s.illegal_action_rate:.4g} > {self.max_illegal:.4g}',None if self.best is None else self.best.step,None if self.best is None else self.best.heldout_win_rate)
        if s.approx_kl>self.max_kl:
            return SupervisorEvent(Decision.ROLLBACK,f'policy KL {s.approx_kl:.4g} > {self.max_kl:.4g}',None if self.best is None else self.best.step,None if self.best is None else self.best.heldout_win_rate)
        if s.eval_games<self.min_eval_games:
            return SupervisorEvent(Decision.CONTINUE,f'eval too small ({s.eval_games} < {self.min_eval_games})',None if self.best is None else self.best.step,None if self.best is None else self.best.heldout_win_rate)
        if self.best is None:
            self.best=s; self.bad=0; return SupervisorEvent(Decision.KEEP_BEST,'first verified checkpoint',s.step,s.heldout_win_rate)
        if s.heldout_win_rate>=self.best.heldout_win_rate+self.improvement and s.worst_archetype_win_rate>=self.best.worst_archetype_win_rate-self.max_worst_drop:
            self.best=s; self.bad=0; return SupervisorEvent(Decision.KEEP_BEST,'held-out improvement',s.step,s.heldout_win_rate)
        reg=self.best.heldout_win_rate-s.heldout_win_rate
        worst_reg=self.best.worst_archetype_win_rate-s.worst_archetype_win_rate
        if reg>self.max_regression or worst_reg>self.max_worst_drop:
            self.bad+=1
            if self.bad>=self.patience:
                return SupervisorEvent(Decision.ROLLBACK,f'held-out regression persisted {self.bad} evals (overall {reg:.3f}, worst {worst_reg:.3f})',self.best.step,self.best.heldout_win_rate)
            return SupervisorEvent(Decision.CONTINUE,f'possible regression {self.bad}/{self.patience}',self.best.step,self.best.heldout_win_rate)
        self.bad=0
        return SupervisorEvent(Decision.CONTINUE,'within verified envelope',self.best.step,self.best.heldout_win_rate)


class AtomicCheckpointStore:
    def __init__(self,root:str|Path): self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def save(self,name:str,model,optimizer=None,metadata:dict|None=None)->Path:
        final=self.root/f'{name}.pt'; tmp=self.root/f'.{name}.tmp.pt'
        payload={'model':model.state_dict(),'metadata':metadata or {}}
        if optimizer is not None: payload['optimizer']=optimizer.state_dict()
        torch.save(payload,tmp); os.replace(tmp,final)
        meta=self.root/f'{name}.json'; mtmp=self.root/f'.{name}.tmp.json'
        mtmp.write_text(json.dumps(metadata or {},indent=2,sort_keys=True)); os.replace(mtmp,meta)
        return final

    def load(self,name:str,model,optimizer=None,map_location='cpu')->dict:
        path=self.root/f'{name}.pt'
        if not path.exists(): raise FileNotFoundError(path)
        payload=torch.load(path,map_location=map_location,weights_only=False)
        if 'model' not in payload: raise RuntimeError(f'checkpoint {path} has no model state')
        model.load_state_dict(payload['model'])
        if optimizer is not None:
            if 'optimizer' not in payload:
                raise RuntimeError(f'checkpoint {path} has no optimizer state')
            optimizer.load_state_dict(payload['optimizer'])
        return dict(payload.get('metadata') or {})

    def exists(self,name:str)->bool:
        return (self.root/f'{name}.pt').exists()
