from __future__ import annotations

from dataclasses import dataclass, asdict
from crgod.action_codec import NUM_ACTIONS
from crgod.contracts import OBSERVATION_SCHEMA_VERSION
from crgod.vocab import CardVocabulary


@dataclass(frozen=True)
class RuntimeContract:
    observation_schema: str
    action_count: int
    vocab_fingerprint: str
    entity_vocab_fingerprint: str
    hasty_commit: str | None = None

    @classmethod
    def build(cls, vocab: CardVocabulary, hasty_commit: str | None = None,
              entity_vocab: CardVocabulary | None = None):
        entity_vocab = entity_vocab or vocab
        return cls(OBSERVATION_SCHEMA_VERSION, NUM_ACTIONS, vocab.fingerprint(),
                   entity_vocab.fingerprint(), hasty_commit)

    def metadata(self) -> dict:
        return {'runtime_contract':asdict(self)}


def assert_checkpoint_compatible(metadata: dict, vocab: CardVocabulary,
                                 hasty_commit: str | None = None,
                                 require_hasty_commit: bool = False,
                                 entity_vocab: CardVocabulary | None = None) -> RuntimeContract:
    raw=(metadata or {}).get('runtime_contract')
    if not isinstance(raw,dict):
        raise RuntimeError('checkpoint has no runtime_contract metadata; refusing ambiguous load')
    try:
        got=RuntimeContract(str(raw['observation_schema']),int(raw['action_count']),
                            str(raw['vocab_fingerprint']),
                            str(raw.get('entity_vocab_fingerprint',raw['vocab_fingerprint'])),
                            raw.get('hasty_commit'))
    except Exception as exc:
        raise RuntimeError(f'invalid checkpoint runtime_contract: {exc}') from exc
    want=RuntimeContract.build(vocab,hasty_commit,entity_vocab)
    errors=[]
    if got.observation_schema!=want.observation_schema:
        errors.append(f'observation schema {got.observation_schema} != {want.observation_schema}')
    if got.action_count!=want.action_count:
        errors.append(f'action count {got.action_count} != {want.action_count}')
    if got.vocab_fingerprint!=want.vocab_fingerprint:
        errors.append('card vocabulary fingerprint mismatch')
    if got.entity_vocab_fingerprint!=want.entity_vocab_fingerprint:
        errors.append('entity vocabulary fingerprint mismatch')
    if require_hasty_commit:
        if not got.hasty_commit or not hasty_commit:
            errors.append('Hasty commit missing from checkpoint or runtime')
        elif got.hasty_commit!=hasty_commit:
            errors.append(f'Hasty commit {got.hasty_commit} != {hasty_commit}')
    elif got.hasty_commit and hasty_commit and got.hasty_commit!=hasty_commit:
        errors.append(f'Hasty commit {got.hasty_commit} != {hasty_commit}')
    if errors:
        raise RuntimeError('checkpoint/runtime contract mismatch:\n- '+'\n- '.join(errors))
    return got
