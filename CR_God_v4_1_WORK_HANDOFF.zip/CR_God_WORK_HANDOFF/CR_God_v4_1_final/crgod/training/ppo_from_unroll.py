from __future__ import annotations
import torch

from crgod.data import _mask_from_indices
from crgod.opponent_codec import OpponentActionBatch, encode_observed_action
from crgod.training.ppo_v2 import RecurrentPPOBatch, compute_gae
from crgod.training.selfplay_v3 import ActorUnroll


def _opp(a,known,tensorizer,device='cpu'):
    if not known:return OpponentActionBatch.pass_batch(1,device)
    k,c,t=encode_observed_action(a,tensorizer.vocab)
    return OpponentActionBatch(torch.tensor([k],dtype=torch.long,device=device),torch.tensor([c],dtype=torch.long,device=device),torch.tensor([t],dtype=torch.long,device=device))


def actor_unroll_to_ppo_batch(unroll:ActorUnroll,model,tensorizer,*,device='cpu',gamma=.997,lam=.95,expected_policy_version:int|None=None,discount_schedule=None,learner_step:int=0)->RecurrentPPOBatch:
    """Convert a synchronous on-policy actor unroll into one recurrent PPO batch."""
    unroll.validate()
    if expected_policy_version is not None and unroll.behavior_version!=expected_policy_version:
        raise RuntimeError(f'PPO requires exact on-policy version {expected_policy_version}, got {unroll.behavior_version}')
    device=torch.device(device); model=model.to(device)
    if discount_schedule is not None:
        gamma=float(discount_schedule.gamma(learner_step))
    rewards=torch.tensor([s.reward for s in unroll.steps],dtype=torch.float32,device=device).unsqueeze(1)
    values=torch.tensor([s.behavior_value for s in unroll.steps],dtype=torch.float32,device=device).unsqueeze(1)
    dones=torch.tensor([s.done for s in unroll.steps],dtype=torch.bool,device=device).unsqueeze(1)
    dts=torch.tensor([s.transition_dt_s for s in unroll.steps],dtype=torch.float32,device=device).unsqueeze(1)
    bootstrap=torch.tensor([float(unroll.behavior_bootstrap_value)],dtype=torch.float32,device=device)
    adv,ret=compute_gae(rewards,values,dones,bootstrap,gamma=gamma,lam=lam,transition_dt_s=dts)
    states=[]; opps=[]; masks=[]
    for s in unroll.steps:
        states.append(tensorizer.one(s.state))
        opps.append(_opp(s.prev_opponent_action,s.prev_opponent_known,tensorizer,'cpu'))
        mask,_=_mask_from_indices(s.legal_action_indices); masks.append(mask.unsqueeze(0))
    T=len(unroll.steps)
    return RecurrentPPOBatch(
        states=states,
        prev_own_actions=torch.tensor([[s.prev_own_action] for s in unroll.steps],dtype=torch.long),
        prev_opp_actions=opps,
        prev_opp_known=torch.tensor([[s.prev_opponent_known] for s in unroll.steps],dtype=torch.bool),
        dt_s=torch.tensor([[s.dt_s] for s in unroll.steps],dtype=torch.float32),
        legal_masks=torch.stack(masks,dim=0),
        actions=torch.tensor([[s.action_index] for s in unroll.steps],dtype=torch.long),
        old_logprob=torch.tensor([[s.behavior_logprob] for s in unroll.steps],dtype=torch.float32),
        advantages=adv.cpu(),returns=ret.cpu(),reset_before=torch.zeros(T,1,dtype=torch.bool),loss_mask=torch.ones(T,1,dtype=torch.bool),
        initial_hidden=unroll.initial_hidden.unsqueeze(0).cpu(),old_values=values.cpu())
