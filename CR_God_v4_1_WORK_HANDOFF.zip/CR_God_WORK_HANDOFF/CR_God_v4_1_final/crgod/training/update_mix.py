from __future__ import annotations
from dataclasses import dataclass
import random
from crgod.training.curriculum_v3 import TrainingStage


@dataclass(frozen=True)
class UpdateMix:
    rl: float
    expert_anchor: float
    planner_distill: float
    belief_aux: float

    def validate(self):
        vals=(self.rl,self.expert_anchor,self.planner_distill,self.belief_aux)
        if any(x<0 for x in vals):raise ValueError('negative update probability')
        if sum(vals)<=0:raise ValueError('empty update mix')

    def sample(self,rng:random.Random|None=None)->str:
        self.validate(); rng=rng or random
        names=['rl','expert_anchor','planner_distill','belief_aux']; vals=[self.rl,self.expert_anchor,self.planner_distill,self.belief_aux]
        return rng.choices(names,weights=vals,k=1)[0]


def default_update_mix(stage:TrainingStage)->UpdateMix:
    if stage==TrainingStage.BC:return UpdateMix(0.,.80,0.,.20)
    if stage==TrainingStage.PPO_BOOTSTRAP:return UpdateMix(.75,.20,0.,.05)
    if stage==TrainingStage.LEAGUE:return UpdateMix(.82,.12,.03,.03)
    if stage==TrainingStage.PLANNER_DISTILL:return UpdateMix(.72,.10,.15,.03)
    return UpdateMix(.70,.10,.10,.10)
