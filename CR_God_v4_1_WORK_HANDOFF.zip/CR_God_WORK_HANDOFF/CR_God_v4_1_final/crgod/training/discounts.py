from __future__ import annotations
from dataclasses import dataclass
import math


def gamma_from_half_life(half_life_s:float,base_dt_s:float=.5)->float:
    if half_life_s<=0 or base_dt_s<=0:raise ValueError('half-life/base dt must be positive')
    return float(math.exp(math.log(.5)*base_dt_s/half_life_s))


def half_life_from_gamma(gamma:float,base_dt_s:float=.5)->float:
    if not 0<gamma<1 or base_dt_s<=0:raise ValueError('gamma must be in (0,1)')
    return float(math.log(.5)*base_dt_s/math.log(gamma))


@dataclass(frozen=True)
class HalfLifeSchedule:
    """Long-horizon curriculum expressed in human-readable seconds."""
    start_half_life_s: float = 45.0
    end_half_life_s: float = 180.0
    start_step: int = 0
    end_step: int = 10_000_000
    base_dt_s: float = .5

    def half_life(self,step:int)->float:
        if self.end_step<=self.start_step:return float(self.end_half_life_s)
        x=min(max((int(step)-self.start_step)/(self.end_step-self.start_step),0.),1.)
        # log interpolation changes the effective horizon smoothly.
        a=math.log(self.start_half_life_s); b=math.log(self.end_half_life_s)
        return float(math.exp(a+x*(b-a)))
    def gamma(self,step:int)->float:
        return gamma_from_half_life(self.half_life(step),self.base_dt_s)
