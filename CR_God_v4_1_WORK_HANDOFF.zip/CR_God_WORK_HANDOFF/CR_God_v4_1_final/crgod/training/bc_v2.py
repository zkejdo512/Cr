from __future__ import annotations
from dataclasses import dataclass
import torch
import torch.nn.functional as F
from crgod.tensorizer import concat_tensor_batches
from crgod.opponent_codec import OpponentActionBatch
from crgod.training.belief import BeliefTargets, belief_auxiliary_loss


@dataclass
class RecurrentBCBatch:
    states: list
    prev_own_actions: torch.Tensor       # [T,B]
    prev_opp_actions: list[OpponentActionBatch]
    prev_opp_known: torch.Tensor         # [T,B]
    dt_s: torch.Tensor                   # [T,B]
    legal_masks: torch.Tensor            # [T,B,A]
    expert_actions: torch.Tensor         # [T,B]
    return_targets: torch.Tensor | None = None # [T,B]
    belief_targets: list[BeliefTargets] | None = None
    reset_before: torch.Tensor | None = None
    loss_mask: torch.Tensor | None = None      # [T,B], False = burn-in only

    def to(self, device):
        self.states=[x.to(device) for x in self.states]
        self.prev_opp_actions=[x.to(device) for x in self.prev_opp_actions]
        for name in ('prev_own_actions','prev_opp_known','dt_s','legal_masks','expert_actions'):
            setattr(self,name,getattr(self,name).to(device))
        if self.return_targets is not None: self.return_targets=self.return_targets.to(device)
        if self.belief_targets is not None:
            for y in self.belief_targets:
                y.opponent_elixir=y.opponent_elixir.to(device); y.hand_presence=y.hand_presence.to(device); y.next_card=y.next_card.to(device); y.next_card_known=y.next_card_known.to(device)
        if self.reset_before is not None: self.reset_before=self.reset_before.to(device)
        if self.loss_mask is not None: self.loss_mask=self.loss_mask.to(device)
        return self


@dataclass
class RecurrentBCMetrics:
    loss: float
    policy_loss: float
    value_loss: float
    belief_loss: float
    accuracy: float


def recurrent_bc_step(model, batch: RecurrentBCBatch, optimizer,
                      value_weight: float = .5, belief_weight: float = .25,
                      max_grad_norm: float = 1.0):
    T,B=batch.expert_actions.shape
    h=model.initial_belief(B,batch.expert_actions.device)
    flat_states=concat_tensor_batches(batch.states)
    z_all=model.encoder(flat_states).reshape(T,B,-1)
    pls=[]; vls=[]; bls=[]; accs=[]
    for t in range(T):
        if batch.reset_before is not None:
            h=h*(~batch.reset_before[t]).to(h.dtype).unsqueeze(-1)
        z=z_all[t]
        bp=model.update_belief(z,batch.prev_own_actions[t],batch.prev_opp_actions[t],
                               batch.prev_opp_known[t],batch.dt_s[t],h)
        h=bp.hidden
        logits,value=model.head(z,h,batch.legal_masks[t])
        rows=torch.arange(B,device=batch.expert_actions.device)
        if not bool(batch.legal_masks[t,rows,batch.expert_actions[t]].all()):
            raise ValueError('recurrent BC target is illegal')
        active = (torch.ones(B,dtype=torch.bool,device=logits.device) if batch.loss_mask is None
                  else batch.loss_mask[t].bool())
        if bool(active.any()):
            pl=F.cross_entropy(logits[active],batch.expert_actions[t][active]); pls.append(pl)
            accs.append((logits[active].argmax(-1)==batch.expert_actions[t][active]).float().mean())
            if batch.return_targets is not None:
                vls.append(F.smooth_l1_loss(value[active],batch.return_targets[t][active]))
            if batch.belief_targets is not None:
                # Belief targets are per-batch; construct a masked view so burn-in
                # teaches memory dynamics but does not dominate the objective.
                y=batch.belief_targets[t]
                from crgod.training.belief import BeliefTargets
                ym=BeliefTargets(y.opponent_elixir[active],y.hand_presence[active],y.next_card[active],y.next_card_known[active])
                from crgod.models.belief import BeliefPrediction
                bpm=BeliefPrediction(bp.hidden[active],bp.opponent_elixir[active],bp.hand_presence_logits[active],bp.next_card_logits[active],bp.style[active])
                bl,_=belief_auxiliary_loss(bpm,ym); bls.append(bl)
    if not pls: raise ValueError('recurrent BC loss_mask contains no training steps')
    policy=torch.stack(pls).mean()
    value=torch.stack(vls).mean() if vls else policy*0.0
    belief=torch.stack(bls).mean() if bls else policy*0.0
    loss=policy+value_weight*value+belief_weight*belief
    optimizer.zero_grad(set_to_none=True); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),max_grad_norm); optimizer.step()
    return RecurrentBCMetrics(float(loss.detach()),float(policy.detach()),float(value.detach()),
                              float(belief.detach()),float(torch.stack(accs).mean().detach()))
