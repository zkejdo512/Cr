from dataclasses import dataclass
@dataclass
class GateDecision: passed:bool; reason:str
def gate_bc(x,min_accuracy=.55): return GateDecision(x>=min_accuracy,f"BC holdout accuracy {x:.3f}")
def gate_mask_coverage(x,min_fraction=.99): return GateDecision(x>=min_fraction,f"legal-mask coverage {x:.1%}")
def gate_world(model_loss,baseline_loss,min_relative_gain=.10):
    if baseline_loss<=0:return GateDecision(False,"invalid world baseline")
    g=1-model_loss/baseline_loss; return GateDecision(g>=min_relative_gain,f"world gain {g:.1%}")
def gate_world_rollout(one,multi,max_ratio=4.):
    if one<=0:return GateDecision(False,"invalid one-step loss")
    r=multi/one; return GateDecision(r<=max_ratio,f"rollout drift ratio {r:.2f}")
def gate_short_rl(base,cand,tolerance=.02): return GateDecision(cand+tolerance>=base,f"candidate {cand:.3f} vs {base:.3f}")
