from __future__ import annotations
from dataclasses import dataclass
import math
from crgod.sim_protocol import RewardComponents


@dataclass(frozen=True)
class RewardGuardConfig:
    max_dense_per_step: float = .10
    max_abs_component: float = 5.0


class GuardedRewardMixer:
    """Fail-closed dense shaping guard against simulator/reward spikes."""
    def __init__(self,base_mixer,config:RewardGuardConfig=RewardGuardConfig()):
        self.base=base_mixer;self.cfg=config
    def __call__(self,c:RewardComponents,learner_step:int)->float:
        vals=(c.terminal,c.tower_damage,c.crown,c.elixir,c.tactical)
        if not all(math.isfinite(float(x)) for x in vals):raise ValueError('non-finite reward component')
        if any(abs(float(x))>self.cfg.max_abs_component for x in vals[1:]):raise ValueError('reward component spike beyond guard')
        total=float(self.base(c,learner_step)); dense=total-float(c.terminal)
        dense=max(-self.cfg.max_dense_per_step,min(self.cfg.max_dense_per_step,dense))
        return float(c.terminal)+dense
