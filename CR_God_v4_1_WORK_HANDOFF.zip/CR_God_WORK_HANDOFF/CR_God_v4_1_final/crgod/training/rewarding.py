from __future__ import annotations

from dataclasses import dataclass
from crgod.sim_protocol import RewardComponents


@dataclass(frozen=True)
class DenseRewardWeights:
    tower_damage: float = 0.10
    crown: float = 0.20
    elixir: float = 0.02
    tactical: float = 0.02


@dataclass(frozen=True)
class RewardAnneal:
    """Linearly anneal dense shaping while preserving the terminal objective."""
    start_step: int = 0
    end_step: int = 5_000_000
    start_scale: float = 1.0
    end_scale: float = 0.0

    def scale(self, learner_step: int) -> float:
        if self.end_step <= self.start_step:
            return float(self.end_scale)
        x=(int(learner_step)-self.start_step)/(self.end_step-self.start_step)
        x=min(max(x,0.0),1.0)
        return float(self.start_scale + x*(self.end_scale-self.start_scale))


class RewardMixer:
    def __init__(self, weights: DenseRewardWeights = DenseRewardWeights(), anneal: RewardAnneal = RewardAnneal()):
        self.weights=weights; self.anneal=anneal

    def __call__(self, components: RewardComponents, learner_step: int) -> float:
        s=self.anneal.scale(learner_step); w=self.weights
        dense=(w.tower_damage*components.tower_damage + w.crown*components.crown +
               w.elixir*components.elixir + w.tactical*components.tactical)
        return float(components.terminal + s*dense)
