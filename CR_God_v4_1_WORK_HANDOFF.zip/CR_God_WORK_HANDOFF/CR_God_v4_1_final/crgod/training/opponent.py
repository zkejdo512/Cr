import torch
import torch.nn.functional as F
from crgod.opponent_codec import OPP_PLAY_CARD

def opponent_sequence_loss(model,latents,targets,optimizer):
    T,B,_=latents.shape; hidden=model.initial(B,latents.device); losses=[]; acc=[]
    for i in range(T):
        tgt=targets[i]; p=model.predict(latents[i],hidden)
        loss=F.cross_entropy(p.kind_logits,tgt.kind)
        non=tgt.kind.ne(0)
        if bool(non.any()): loss=loss+F.cross_entropy(p.card_logits[non],tgt.card_token[non])
        placed=tgt.kind.eq(OPP_PLAY_CARD)
        if bool(placed.any()): loss=loss+F.cross_entropy(p.tile_logits[placed],tgt.tile[placed])
        losses.append(loss)
        pk=p.kind_logits.argmax(-1); ok=pk==tgt.kind
        if bool(non.any()): ok=ok & (~non | (p.card_logits.argmax(-1)==tgt.card_token))
        if bool(placed.any()): ok=ok & (~placed | (p.tile_logits.argmax(-1)==tgt.tile))
        acc.append(ok.float().mean()); hidden=model.update(latents[i],tgt,hidden)
    total=torch.stack(losses).mean(); optimizer.zero_grad(set_to_none=True); total.backward(); optimizer.step()
    return float(total.detach()),float(torch.stack(acc).mean().detach())

# Backward-compatible name used by the v1/v1.2 smoke path.
def opponent_step(model,latents,targets,optimizer,hidden=None):
    T,B,_=latents.shape
    hidden=model.initial(B,latents.device) if hidden is None else hidden
    losses=[]; acc=[]
    for i in range(T):
        tgt=targets[i]; p=model.predict(latents[i],hidden)
        loss=F.cross_entropy(p.kind_logits,tgt.kind)
        non=tgt.kind.ne(0)
        if bool(non.any()): loss=loss+F.cross_entropy(p.card_logits[non],tgt.card_token[non])
        placed=tgt.kind.eq(1)
        if bool(placed.any()): loss=loss+F.cross_entropy(p.tile_logits[placed],tgt.tile[placed])
        losses.append(loss)
        pk=p.kind_logits.argmax(-1); ok=pk==tgt.kind
        if bool(non.any()): ok=ok & (~non | (p.card_logits.argmax(-1)==tgt.card_token))
        if bool(placed.any()): ok=ok & (~placed | (p.tile_logits.argmax(-1)==tgt.tile))
        acc.append(ok.float().mean())
        hidden=model.update(latents[i].detach(),tgt,hidden)
    loss=torch.stack(losses).mean(); optimizer.zero_grad(set_to_none=True); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.); optimizer.step()
    return float(loss.detach()),float(torch.stack(acc).mean().detach())
