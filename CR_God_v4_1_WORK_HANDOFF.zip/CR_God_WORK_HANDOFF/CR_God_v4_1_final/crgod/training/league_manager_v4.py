from __future__ import annotations
from dataclasses import dataclass, field
from crgod.training.league_manager_v3 import LeagueManagerV3, SnapshotRule
from crgod.training.exploiters_v4 import AutoExploiterFactory, FailureSlice, ExploiterSpec
from crgod.league_v2 import LeagueMember


@dataclass
class AutoExploiterRegistry:
    specs:dict[str,ExploiterSpec]=field(default_factory=dict)


class LeagueManagerV4(LeagueManagerV3):
    """v3 PFSP league plus failure-driven exploiter proposal/registration."""
    def __init__(self,main:LeagueMember,*,snapshot_rule:SnapshotRule=SnapshotRule(),history_mix:float=.20,
                 exploiter_factory:AutoExploiterFactory|None=None):
        super().__init__(main,snapshot_rule=snapshot_rule,history_mix=history_mix)
        self.exploiter_factory=exploiter_factory or AutoExploiterFactory()
        self.auto_exploiters=AutoExploiterRegistry()

    def propose_exploiters(self,slices:list[FailureSlice],generation:int)->list[ExploiterSpec]:
        return [x for x in self.exploiter_factory.propose(slices,generation) if x.exploiter_id not in self.league.members]

    def register_exploiter_checkpoint(self,spec:ExploiterSpec,path:str)->LeagueMember:
        if spec.exploiter_id in self.league.members:raise ValueError('duplicate auto exploiter')
        m=LeagueMember(spec.exploiter_id,path,'exploiter',generation=spec.generation,frozen=False)
        self.add_exploiter(m);self.auto_exploiters.specs[spec.exploiter_id]=spec;return m
