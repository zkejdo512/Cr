from __future__ import annotations
from dataclasses import dataclass
import random
from typing import Any, Callable
from crgod.training.hardcase import HardCaseBuffer, HardCase


@dataclass(frozen=True)
class HardCaseMixSchedule:
    start_fraction: float=.10
    peak_fraction: float=.45
    peak_step: int=3_000_000
    end_fraction: float=.25
    end_step: int=15_000_000

    def fraction(self,step:int)->float:
        s=max(0,int(step))
        if s<=self.peak_step:
            x=s/max(1,self.peak_step)
            return self.start_fraction+x*(self.peak_fraction-self.start_fraction)
        x=min((s-self.peak_step)/max(1,self.end_step-self.peak_step),1.)
        return self.peak_fraction+x*(self.end_fraction-self.peak_fraction)


class HardCaseCurriculum:
    """Mixes broad self-play with mined difficult cases.

    Hard cases never become the whole distribution: broad play is retained to
    avoid overfitting and catastrophic forgetting.
    """
    def __init__(self,buffer:HardCaseBuffer,schedule:HardCaseMixSchedule=HardCaseMixSchedule()):
        self.buffer=buffer;self.schedule=schedule
    def choose(self,learner_step:int,normal_factory:Callable[[],Any],rng:random.Random|None=None)->tuple[Any,bool]:
        rng=rng or random.Random(); p=self.schedule.fraction(learner_step)
        if len(self.buffer) and rng.random()<p:
            xs=self.buffer.sample(1,rng)
            if xs:return xs[0].payload,True
        return normal_factory(),False
