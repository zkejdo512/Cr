from __future__ import annotations
from dataclasses import dataclass,asdict
import json
from pathlib import Path


@dataclass(frozen=True)
class TrainingReadinessV3:
    regression_tests_pass: bool=False
    simulator_contract_pass: bool=False
    no_privileged_leakage_pass: bool=False
    replay_causality_pass: bool=False
    full_card_vocab_pass: bool=False
    full_entity_vocab_pass: bool=False
    recurrent_bc_pass: bool=False
    synchronous_ppo_pass: bool=False
    vtrace_actor_learner_pass: bool=False
    checkpoint_resume_pass: bool=False
    league_pfsp_pass: bool=False
    paired_ab_eval_pass: bool=False
    rollback_supervisor_pass: bool=False

    def blockers(self):
        mapping=[
            ('regression tests',self.regression_tests_pass),('simulator contract',self.simulator_contract_pass),
            ('privileged-state leakage',self.no_privileged_leakage_pass),('replay causality',self.replay_causality_pass),
            ('full card vocabulary',self.full_card_vocab_pass),('full entity vocabulary',self.full_entity_vocab_pass),
            ('recurrent BC',self.recurrent_bc_pass),('synchronous PPO',self.synchronous_ppo_pass),
            ('V-trace actor-learner',self.vtrace_actor_learner_pass),('checkpoint resume',self.checkpoint_resume_pass),
            ('PFSP league',self.league_pfsp_pass),('paired A/B evaluation',self.paired_ab_eval_pass),('rollback supervisor',self.rollback_supervisor_pass)]
        return [name for name,ok in mapping if not ok]
    @property
    def ready(self):return not self.blockers()
    def assert_ready(self):
        b=self.blockers()
        if b:raise RuntimeError('CR-God v3 training blocked:\n- '+'\n- '.join(b))
    def save(self,path):Path(path).write_text(json.dumps({**asdict(self),'ready':self.ready,'blockers':self.blockers()},indent=2),encoding='utf8')
