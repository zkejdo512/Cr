from __future__ import annotations

from dataclasses import dataclass
import torch
import torch.nn.functional as F

from crgod.data import _mask_from_indices
from crgod.opponent_codec import OpponentActionBatch, encode_observed_action
from crgod.training.selfplay_v3 import ActorUnroll
from crgod.tensorizer import concat_tensor_batches


@dataclass(frozen=True)
class VTraceTargets:
    vs: torch.Tensor
    policy_advantages: torch.Tensor
    rhos: torch.Tensor


def vtrace_targets(behavior_logprob:torch.Tensor,target_logprob:torch.Tensor,rewards:torch.Tensor,
                   values:torch.Tensor,bootstrap_value:torch.Tensor,dones:torch.Tensor,dt_s:torch.Tensor,
                   *,gamma:float=.997,base_dt_s:float=.5,clip_rho:float=1.0,clip_pg_rho:float=1.0,
                   clip_c:float=1.0)->VTraceTargets:
    """IMPALA V-trace with continuous-time discounting."""
    for x in (behavior_logprob,target_logprob,rewards,values,dones,dt_s):
        if x.ndim!=1: raise ValueError('V-trace expects 1-D time tensors')
    n=len(rewards)
    if not all(len(x)==n for x in (behavior_logprob,target_logprob,values,dones,dt_s)):
        raise ValueError('V-trace length mismatch')
    if n==0 or bool((dt_s<=0).any()): raise ValueError('empty/invalid V-trace sequence')
    if base_dt_s<=0 or not 0<gamma<=1: raise ValueError('invalid V-trace discount config')
    log_rhos=(target_logprob-behavior_logprob).clamp(-20,20); rhos=log_rhos.exp()
    rho=rhos.clamp(max=clip_rho); c=rhos.clamp(max=clip_c); pg_rho=rhos.clamp(max=clip_pg_rho)
    discounts=torch.pow(torch.full_like(dt_s,float(gamma)),dt_s/float(base_dt_s))*(~dones.bool()).to(dt_s.dtype)
    next_values=torch.cat([values[1:],bootstrap_value.reshape(1)])
    deltas=rho*(rewards+discounts*next_values-values)
    acc=torch.zeros_like(bootstrap_value)
    out=[]
    for t in reversed(range(n)):
        acc=deltas[t]+discounts[t]*c[t]*acc
        out.append(values[t]+acc)
    vs=torch.stack(list(reversed(out)))
    vs_next=torch.cat([vs[1:],bootstrap_value.reshape(1)])
    pg_adv=pg_rho*(rewards+discounts*vs_next-values)
    return VTraceTargets(vs,pg_adv,rhos)


@dataclass(frozen=True)
class VTraceMetrics:
    loss: float
    policy_loss: float
    value_loss: float
    entropy: float
    mean_rho: float
    max_rho: float
    grad_norm: float


def _opp_batch(a,known,tensorizer,device):
    if not known: return OpponentActionBatch.pass_batch(1,device)
    kind,card,tile=encode_observed_action(a,tensorizer.vocab)
    return OpponentActionBatch(torch.tensor([kind],dtype=torch.long,device=device),
                               torch.tensor([card],dtype=torch.long,device=device),
                               torch.tensor([tile],dtype=torch.long,device=device))


def recurrent_vtrace_step(model,unroll:ActorUnroll,tensorizer,optimizer,*,device='cpu',gamma=.997,base_dt_s=.5,discount_schedule=None,learner_step:int=0,
                          clip_rho=1.0,clip_pg_rho=1.0,clip_c=1.0,value_coef=.5,entropy_coef=.01,
                          max_grad_norm=1.0)->VTraceMetrics:
    """Off-policy recurrent actor-learner update for policy-lagged self-play actors."""
    unroll.validate(); device=torch.device(device); model=model.to(device).train()
    if discount_schedule is not None: gamma=float(discount_schedule.gamma(learner_step))
    h=(unroll.burnin_initial_hidden if unroll.burnin_steps else unroll.initial_hidden).to(device).unsqueeze(0)
    seq_states=[s.state for s in unroll.burnin_steps]+[s.state for s in unroll.steps]
    if not unroll.terminal: seq_states.append(unroll.final_state)
    flat=concat_tensor_batches([tensorizer.one(x) for x in seq_states]).to(device)
    z_all=model.encoder(flat); zi=0
    # Rebuild recurrent state using current learner weights before applying loss.
    for s in unroll.burnin_steps:
        z=z_all[zi:zi+1]; zi+=1
        bp=model.update_belief(z,torch.tensor([s.prev_own_action],dtype=torch.long,device=device),
                               _opp_batch(s.prev_opponent_action,s.prev_opponent_known,tensorizer,device),
                               torch.tensor([s.prev_opponent_known],dtype=torch.bool,device=device),
                               torch.tensor([s.dt_s],dtype=z.dtype,device=device),h)
        h=bp.hidden
    logps=[]; values=[]; entropies=[]
    for s in unroll.steps:
        z=z_all[zi:zi+1]; zi+=1
        bp=model.update_belief(z,torch.tensor([s.prev_own_action],dtype=torch.long,device=device),
                               _opp_batch(s.prev_opponent_action,s.prev_opponent_known,tensorizer,device),
                               torch.tensor([s.prev_opponent_known],dtype=torch.bool,device=device),
                               torch.tensor([s.dt_s],dtype=z.dtype,device=device),h)
        h=bp.hidden
        mask,_=_mask_from_indices(s.legal_action_indices); mask=mask.to(device).unsqueeze(0)
        logits,v=model.head(z,h,mask); dist=torch.distributions.Categorical(logits=logits[0])
        a=torch.tensor(s.action_index,dtype=torch.long,device=device)
        logps.append(dist.log_prob(a)); values.append(v[0]); entropies.append(dist.entropy())
    target_logp=torch.stack(logps); value=torch.stack(values); entropy=torch.stack(entropies)
    if unroll.terminal:
        bootstrap=torch.zeros((),dtype=value.dtype,device=device)
    else:
        z=z_all[zi:zi+1]
        bp=model.update_belief(z,torch.tensor([unroll.final_prev_own_action],dtype=torch.long,device=device),
                               _opp_batch(unroll.final_prev_opponent_action,unroll.final_prev_opponent_known,tensorizer,device),
                               torch.tensor([unroll.final_prev_opponent_known],dtype=torch.bool,device=device),
                               torch.tensor([unroll.final_dt_s],dtype=z.dtype,device=device),h)
        mask,_=_mask_from_indices(unroll.final_legal_action_indices); mask=mask.to(device).unsqueeze(0)
        _,bv=model.head(z,bp.hidden,mask); bootstrap=bv[0]
    behavior=torch.tensor([s.behavior_logprob for s in unroll.steps],dtype=value.dtype,device=device)
    rewards=torch.tensor([s.reward for s in unroll.steps],dtype=value.dtype,device=device)
    dones=torch.tensor([s.done for s in unroll.steps],dtype=torch.bool,device=device)
    dts=torch.tensor([s.transition_dt_s for s in unroll.steps],dtype=value.dtype,device=device)
    with torch.no_grad():
        targets=vtrace_targets(behavior,target_logp.detach(),rewards,value.detach(),bootstrap.detach(),dones,dts,
                               gamma=gamma,base_dt_s=base_dt_s,clip_rho=clip_rho,clip_pg_rho=clip_pg_rho,clip_c=clip_c)
    policy_loss=-(target_logp*targets.policy_advantages.detach()).mean()
    value_loss=F.smooth_l1_loss(value,targets.vs.detach())
    ent=entropy.mean(); loss=policy_loss+value_coef*value_loss-entropy_coef*ent
    optimizer.zero_grad(set_to_none=True); loss.backward()
    gn=torch.nn.utils.clip_grad_norm_(model.parameters(),max_grad_norm); optimizer.step()
    return VTraceMetrics(float(loss.detach()),float(policy_loss.detach()),float(value_loss.detach()),float(ent.detach()),
                         float(targets.rhos.mean().detach()),float(targets.rhos.max().detach()),float(gn))
