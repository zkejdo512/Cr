from __future__ import annotations
from dataclasses import dataclass
from typing import Sequence
from crgod.sequence import Episode


@dataclass(frozen=True)
class EpisodeSplits:
    train: tuple[Episode,...]
    val: tuple[Episode,...]
    test: tuple[Episode,...]


def chronological_episode_split(episodes: Sequence[Episode], train_fraction=.8, val_fraction=.1) -> EpisodeSplits:
    """Contiguous split by episode order; never leaks steps from one match across splits."""
    eps=tuple(episodes)
    if len(eps)<3: raise ValueError('need at least 3 episodes for train/val/test')
    if not (0 < train_fraction < 1 and 0 <= val_fraction < 1 and train_fraction+val_fraction < 1):
        raise ValueError('invalid split fractions')
    n=len(eps); n_train=max(1,int(n*train_fraction)); n_val=max(1,int(n*val_fraction))
    if n_train+n_val>=n: n_train=max(1,n-2); n_val=1
    train=eps[:n_train]; val=eps[n_train:n_train+n_val]; test=eps[n_train+n_val:]
    if not train or not val or not test: raise RuntimeError('episode split produced empty partition')
    ids=[{e.episode_id for e in part} for part in (train,val,test)]
    if ids[0]&ids[1] or ids[0]&ids[2] or ids[1]&ids[2]: raise RuntimeError('episode id leakage across splits')
    return EpisodeSplits(train,val,test)
