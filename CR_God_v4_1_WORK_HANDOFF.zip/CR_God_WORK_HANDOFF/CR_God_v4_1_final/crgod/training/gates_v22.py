from __future__ import annotations

from dataclasses import dataclass, asdict
import json
from pathlib import Path


@dataclass(frozen=True)
class V22ReadinessReport:
    regression_tests_pass: bool = False
    observation_schema_parity_pass: bool = False
    sequence_no_future_leakage_pass: bool = False
    replay_roundtrip_pass: bool = False
    full_card_vocab_pass: bool = False
    full_entity_vocab_pass: bool = False
    recurrent_bc_smoke_pass: bool = False
    recurrent_ppo_smoke_pass: bool = False
    hasty_commit_pinned: bool = False
    hasty_runtime_parity_pass: bool = False
    hasty_source_audit_pass: bool = False
    onpolicy_hasty_rollout_smoke_pass: bool = False
    supervisor_rollback_pass: bool = False
    checkpoint_resume_pass: bool = False
    real_mechanics_calibration_pass: bool = False
    paired_ab_gate_pass: bool = False

    def blockers(self) -> list[str]:
        checks = [
            ('regression test suite not passed', self.regression_tests_pass),
            ('observation schema parity not passed', self.observation_schema_parity_pass),
            ('recurrent sequence future-leakage gate not passed', self.sequence_no_future_leakage_pass),
            ('replay JSONL round-trip not passed', self.replay_roundtrip_pass),
            ('full supported-card vocabulary not verified', self.full_card_vocab_pass),
            ('full battlefield-entity vocabulary not verified', self.full_entity_vocab_pass),
            ('recurrent BC smoke not passed', self.recurrent_bc_smoke_pass),
            ('recurrent PPO smoke not passed', self.recurrent_ppo_smoke_pass),
            ('exact Hasty commit is not pinned', self.hasty_commit_pinned),
            ('Hasty runtime action/codec/mask parity not passed', self.hasty_runtime_parity_pass),
            ('Hasty source audit/required patches not passed', self.hasty_source_audit_pass),
            ('Hasty→CR-God on-policy rollout smoke not passed', self.onpolicy_hasty_rollout_smoke_pass),
            ('training supervisor rollback gate not passed', self.supervisor_rollback_pass),
            ('checkpoint + optimizer resume not passed', self.checkpoint_resume_pass),
            ('real mechanics calibration gate not passed', self.real_mechanics_calibration_pass),
            ('paired held-out A/B gate not passed', self.paired_ab_gate_pass),
        ]
        return [msg for msg, ok in checks if not ok]

    @property
    def ready_for_paid_training(self) -> bool:
        return not self.blockers()

    def assert_paid_training_ready(self) -> None:
        blockers = self.blockers()
        if blockers:
            raise RuntimeError('CR-God v2.2 paid training blocked:\n- ' + '\n- '.join(blockers))

    def to_dict(self) -> dict:
        d=asdict(self); d['ready_for_paid_training']=self.ready_for_paid_training; d['blockers']=self.blockers(); return d

    def save(self,path:str|Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(),indent=2,sort_keys=True),encoding='utf8')
