from __future__ import annotations
from dataclasses import dataclass
import torch
import torch.nn.functional as F


@dataclass
class PPOMetrics:
    loss: float
    policy_loss: float
    value_loss: float
    entropy: float
    approx_kl: float
    clip_fraction: float


def sample_masked_action(head, z, context, legal_mask):
    """Sample only from legal actions and return action/logprob/value."""
    logits, value = head(z, context, legal_mask)
    dist = torch.distributions.Categorical(logits=logits)
    action = dist.sample()
    rows = torch.arange(action.shape[0], device=action.device)
    if not bool(legal_mask[rows, action].all()):
        raise RuntimeError('masked policy sampled an illegal action')
    return action, dist.log_prob(action), value


def ppo_step(head, z, context, legal_mask, actions, old_logprob,
             advantages, returns, optimizer, clip_eps=.2, value_coef=.5,
             entropy_coef=.01, max_grad_norm=1.0):
    """One masked discrete PPO update over a pre-collected rollout minibatch."""
    head.train()
    logits, value = head(z, context, legal_mask)
    rows = torch.arange(actions.shape[0], device=actions.device)
    if not bool(legal_mask[rows, actions].all()):
        raise ValueError('PPO rollout contains illegal target action')
    dist = torch.distributions.Categorical(logits=logits)
    logprob = dist.log_prob(actions)
    log_ratio = logprob - old_logprob
    ratio = log_ratio.exp()
    adv = (advantages - advantages.mean()) / advantages.std(unbiased=False).clamp_min(1e-6)
    obj1 = ratio * adv
    obj2 = ratio.clamp(1.0 - clip_eps, 1.0 + clip_eps) * adv
    policy_loss = -torch.minimum(obj1, obj2).mean()
    value_loss = F.smooth_l1_loss(value, returns)
    entropy = dist.entropy().mean()
    loss = policy_loss + value_coef * value_loss - entropy_coef * entropy
    optimizer.zero_grad(set_to_none=True)
    loss.backward()
    torch.nn.utils.clip_grad_norm_(head.parameters(), max_grad_norm)
    optimizer.step()
    approx_kl = ((ratio - 1) - log_ratio).mean().detach()
    clip_fraction = ((ratio - 1.0).abs() > clip_eps).float().mean().detach()
    return PPOMetrics(float(loss.detach()), float(policy_loss.detach()),
                      float(value_loss.detach()), float(entropy.detach()),
                      float(approx_kl), float(clip_fraction))
