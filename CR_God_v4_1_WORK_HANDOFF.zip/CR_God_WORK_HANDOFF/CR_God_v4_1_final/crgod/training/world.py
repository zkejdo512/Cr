from dataclasses import dataclass
import torch
from .losses import world_model_loss
@dataclass
class WorldMetrics: loss:float; latent:float; reward:float; continuation:float; legal:float; samples_used:int; skipped:bool=False
def world_ensemble_step(encoder,ens,s,ns,a,oa,r,done,dt,known,nlm,nknown,opt,bootstrap_keep=.8):
    encoder.eval(); ens.train(); valid=known.bool(); n=int(valid.sum())
    if n==0: return WorldMetrics(0,0,0,0,0,0,True)
    with torch.no_grad(): z=encoder(s); tz=encoder(ns)
    total=torch.zeros((),device=a.device); sums={k:0. for k in ("latent","reward","continue","legal")}; used=0
    for m in ens.models:
        boot=valid & (torch.rand_like(valid.float())<bootstrap_keep)
        if not bool(boot.any()): boot=torch.zeros_like(valid); boot[torch.nonzero(valid)[0,0]]=True
        pz,pr,pc,pl=m(z[boot],a[boot],oa[boot],dt[boot]); loss,p=world_model_loss(pz,tz[boot],pr,r[boot],pc,done[boot],pl,nlm[boot],nknown[boot]); total+=loss; used+=int(boot.sum());
        for k in sums: sums[k]+=float(p[k])
    total/=len(ens.models); opt.zero_grad(set_to_none=True); total.backward(); torch.nn.utils.clip_grad_norm_(ens.parameters(),5.); opt.step(); d=len(ens.models); return WorldMetrics(float(total.detach()),sums['latent']/d,sums['reward']/d,sums['continue']/d,sums['legal']/d,used,False)
