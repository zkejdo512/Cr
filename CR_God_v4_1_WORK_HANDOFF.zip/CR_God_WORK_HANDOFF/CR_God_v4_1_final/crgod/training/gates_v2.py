from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class V2ReadinessReport:
    v12_regression_tests_pass: bool = False
    recurrent_belief_smoke_pass: bool = False
    hierarchical_action_parity_pass: bool = False
    recurrent_ppo_smoke_pass: bool = False
    pfsp_league_smoke_pass: bool = False
    planner_parity_pass: bool = False
    hasty_dynamic_parity_pass: bool = False
    real_mechanics_calibration_pass: bool = False
    bc_vs_ppo_ab_pass: bool = False

    def blockers(self) -> list[str]:
        checks = [
            ('v1.2 regression suite not passed', self.v12_regression_tests_pass),
            ('recurrent belief smoke not passed', self.recurrent_belief_smoke_pass),
            ('hierarchical action parity not passed', self.hierarchical_action_parity_pass),
            ('recurrent PPO smoke not passed', self.recurrent_ppo_smoke_pass),
            ('PFSP league smoke not passed', self.pfsp_league_smoke_pass),
            ('fast/slow planner parity not passed', self.planner_parity_pass),
            ('Hasty dynamic parity fixtures not passed', self.hasty_dynamic_parity_pass),
            ('real mechanics calibration not passed', self.real_mechanics_calibration_pass),
            ('BC→PPO controlled A/B not passed', self.bc_vs_ppo_ab_pass),
        ]
        return [msg for msg, ok in checks if not ok]

    def assert_paid_training_ready(self):
        b = self.blockers()
        if b:
            raise RuntimeError('CR-God v2 paid training blocked:\n- ' + '\n- '.join(b))
