import torch
import torch.nn.functional as F
def behavior_clone_loss(logits,target): return F.cross_entropy(logits,target)
def world_model_loss(pz,tz,pr,r,pc,done,pl=None,lm=None,lknown=None):
    latent=F.smooth_l1_loss(pz,tz.detach()); rew=F.smooth_l1_loss(pr,r); cont=F.binary_cross_entropy_with_logits(pc,(~done.bool()).float()); legal=torch.zeros((),device=pz.device)
    if pl is not None and lm is not None:
        if lknown is None: lknown=torch.ones(pz.shape[0],dtype=torch.bool,device=pz.device)
        if bool(lknown.any()):
            tgt=lm[lknown].float(); pos=tgt.sum().clamp_min(1.); neg=(1-tgt).sum(); pw=(neg/pos).clamp(1.,100.); legal=F.binary_cross_entropy_with_logits(pl[lknown],tgt,pos_weight=pw)
    total=latent+rew+.2*cont+.05*legal; return total,{"latent":latent.detach(),"reward":rew.detach(),"continue":cont.detach(),"legal":legal.detach()}
