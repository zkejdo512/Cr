from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable
import torch

from crgod.action_codec import decode_action, NUM_ACTIONS
from crgod.contracts import PlayerObservationV1, ObservedOpponentActionV1
from crgod.data import _mask_from_indices
from crgod.opponent_codec import OpponentActionBatch, encode_observed_action
from crgod.training.ppo_v2 import RecurrentPPOBatch, compute_gae


@dataclass
class CollectedStep:
    state: PlayerObservationV1
    legal_action_indices: tuple[int, ...]
    action_index: int
    old_logprob: float
    value: float
    reward: float
    done: bool
    prev_own_action: int
    prev_opponent_action: ObservedOpponentActionV1
    prev_opponent_known: bool
    dt_s: float
    transition_dt_s: float
    hidden_in: torch.Tensor  # [H], hidden BEFORE consuming current observation


@dataclass
class CollectedEpisode:
    steps: tuple[CollectedStep, ...]

    def validate(self) -> None:
        if not self.steps:
            raise ValueError('collected episode is empty')
        if not self.steps[-1].done:
            raise ValueError('on-policy collector requires a complete terminal/truncated episode')
        for i, s in enumerate(self.steps):
            if s.action_index not in s.legal_action_indices:
                raise ValueError(f'collected illegal action at step {i}: {s.action_index}')
            if s.hidden_in.ndim != 1:
                raise ValueError(f'hidden_in must be [H], got {tuple(s.hidden_in.shape)}')
            if i < len(self.steps)-1 and s.done:
                raise ValueError(f'done before final collected step at {i}')


def _opp_batch(action: ObservedOpponentActionV1, known: bool, tensorizer, device) -> OpponentActionBatch:
    if not known:
        return OpponentActionBatch.pass_batch(1, device)
    kind, card, tile = encode_observed_action(action, tensorizer.vocab)
    return OpponentActionBatch(
        torch.tensor([kind], dtype=torch.long, device=device),
        torch.tensor([card], dtype=torch.long, device=device),
        torch.tensor([tile], dtype=torch.long, device=device),
    )


@torch.no_grad()
def collect_complete_episode(adapter, model, tensorizer, device='cpu', seed: int | None = None,
                             deterministic: bool = False, temperature: float = 1.0,
                             max_steps: int = 1000) -> CollectedEpisode:
    """Collect one exact recurrent on-policy episode from an adapter.

    The recurrent input for decision t contains only the action interval that
    finished before t.  The opponent action produced by adapter.step(t) becomes
    input to decision t+1; it is never leaked into the current decision.
    """
    if deterministic:
        raise ValueError('deterministic/argmax collection is evaluation-only and invalid for PPO old_logprob ratios')
    if abs(float(temperature)-1.0) > 1e-8:
        raise ValueError('PPO collection requires temperature=1.0 so stored old_logprob matches the update policy')
    device = torch.device(device)
    model = model.to(device).eval()
    obs, mask_np, _true = adapter.reset(seed=seed)
    if not isinstance(obs, PlayerObservationV1):
        raise TypeError('adapter.reset must return PlayerObservationV1')
    legal = torch.as_tensor(mask_np, dtype=torch.bool, device=device)
    if legal.shape != (NUM_ACTIONS,) or not bool(legal[0]):
        raise ValueError(f'invalid initial legal mask {tuple(legal.shape)}')

    hidden = model.initial_belief(1, device)
    prev_own = 0
    prev_opp = ObservedOpponentActionV1.pass_action()
    prev_known = False
    dt_s = 0.0
    out: list[CollectedStep] = []

    for _ in range(max_steps):
        hidden_in = hidden.detach().clone()[0].cpu()
        tb = tensorizer.one(obs).to(device)
        z = model.encoder(tb)
        opp = _opp_batch(prev_opp, prev_known, tensorizer, device)
        bp = model.update_belief(
            z,
            torch.tensor([prev_own], dtype=torch.long, device=device),
            opp,
            torch.tensor([prev_known], dtype=torch.bool, device=device),
            torch.tensor([dt_s], dtype=z.dtype, device=device),
            hidden,
        )
        hidden = bp.hidden
        logits, value = model.head(z, hidden, legal.unsqueeze(0))
        scaled = logits[0]
        dist = torch.distributions.Categorical(logits=scaled)
        action = scaled.argmax() if deterministic else dist.sample()
        logprob = dist.log_prob(action)
        action_index = int(action)
        if not bool(legal[action_index]):
            raise RuntimeError('masked policy sampled an illegal action')

        tr = adapter.step(action_index)
        if tr.state != obs:
            raise RuntimeError('adapter transition state differs from the observation used for the action')
        transition_dt=float(tr.next_state.t_s-tr.state.t_s)
        if transition_dt <= 0:
            raise RuntimeError(f'non-positive transition duration {transition_dt}')
        out.append(CollectedStep(
            state=obs,
            legal_action_indices=tuple(int(i) for i in torch.nonzero(legal, as_tuple=False).flatten().cpu().tolist()),
            action_index=action_index,
            old_logprob=float(logprob.cpu()),
            value=float(value[0].cpu()),
            reward=float(tr.reward),
            done=bool(tr.done),
            prev_own_action=prev_own,
            prev_opponent_action=prev_opp,
            prev_opponent_known=prev_known,
            dt_s=float(dt_s),
            transition_dt_s=transition_dt,
            hidden_in=hidden_in,
        ))
        if tr.done:
            ep = CollectedEpisode(tuple(out)); ep.validate(); return ep

        obs = tr.next_state
        next_indices = tr.next_legal_action_indices
        if next_indices is None:
            raise RuntimeError('adapter must expose next legal actions for PPO collection')
        legal, _ = _mask_from_indices(next_indices)
        legal = legal.to(device)
        prev_own = action_index
        prev_opp = tr.opponent_action
        prev_known = bool(tr.opponent_action_known)
        dt_s = float(tr.next_state.t_s - tr.state.t_s)
        if dt_s <= 0:
            raise RuntimeError(f'non-positive simulator decision interval {dt_s}')

    raise RuntimeError(f'episode did not terminate within max_steps={max_steps}; refusing partial recurrent rollout')


def _advantages(ep: CollectedEpisode, gamma: float, lam: float):
    ep.validate()
    rewards = torch.tensor([s.reward for s in ep.steps], dtype=torch.float32).unsqueeze(1)
    values = torch.tensor([s.value for s in ep.steps], dtype=torch.float32).unsqueeze(1)
    dones = torch.tensor([s.done for s in ep.steps], dtype=torch.bool).unsqueeze(1)
    transition_dt=torch.tensor([s.transition_dt_s for s in ep.steps],dtype=torch.float32).unsqueeze(1)
    adv, ret = compute_gae(rewards, values, dones, torch.zeros(1), gamma=gamma, lam=lam, transition_dt_s=transition_dt)
    return adv[:, 0], ret[:, 0]


def build_ppo_chunks(episodes: Iterable[CollectedEpisode], tensorizer, seq_len: int = 64,
                     gamma: float = .997, lam: float = .95) -> list[RecurrentPPOBatch]:
    """Build exact-state recurrent PPO chunks.

    Each chunk carries the rollout hidden state that existed immediately before
    its first observation. This avoids pretending a mid-episode chunk began with
    zero memory, while still truncating BPTT to a bounded sequence length.
    """
    if seq_len <= 0:
        raise ValueError('seq_len must be positive')
    batches: list[RecurrentPPOBatch] = []
    for ep in episodes:
        ep.validate()
        adv, ret = _advantages(ep, gamma, lam)
        n = len(ep.steps)
        for start in range(0, n, seq_len):
            stop = min(n, start + seq_len)
            steps = ep.steps[start:stop]
            T = len(steps)
            states = [tensorizer.batch([s.state]) for s in steps]
            prev_own = torch.tensor([[s.prev_own_action] for s in steps], dtype=torch.long)
            opps=[]
            known=[]; dts=[]; masks=[]; actions=[]; old=[]
            for s in steps:
                opps.append(_opp_batch(s.prev_opponent_action, s.prev_opponent_known, tensorizer, 'cpu'))
                known.append([s.prev_opponent_known]); dts.append([s.dt_s])
                mask,_ = _mask_from_indices(s.legal_action_indices); masks.append(mask.unsqueeze(0))
                actions.append([s.action_index]); old.append([s.old_logprob])
            initial_hidden = steps[0].hidden_in.unsqueeze(0).clone()
            batch = RecurrentPPOBatch(
                states=states,
                prev_own_actions=prev_own,
                prev_opp_actions=opps,
                prev_opp_known=torch.tensor(known, dtype=torch.bool),
                dt_s=torch.tensor(dts, dtype=torch.float32),
                legal_masks=torch.stack(masks, dim=0),
                actions=torch.tensor(actions, dtype=torch.long),
                old_logprob=torch.tensor(old, dtype=torch.float32),
                advantages=adv[start:stop].unsqueeze(1),
                returns=ret[start:stop].unsqueeze(1),
                reset_before=torch.zeros(T,1,dtype=torch.bool),
                loss_mask=torch.ones(T,1,dtype=torch.bool),
                initial_hidden=initial_hidden,
            )
            batches.append(batch)
    if not batches:
        raise ValueError('no PPO chunks built')
    return batches
