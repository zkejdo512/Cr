from __future__ import annotations

from dataclasses import dataclass
import copy
from typing import Mapping
import torch

from crgod.action_codec import NUM_ACTIONS
from crgod.contracts import ObservedOpponentActionV1, PlayerObservationV1
from crgod.data import _mask_from_indices
from crgod.opponent_codec import OpponentActionBatch, encode_observed_action
from crgod.sim_protocol import JointFrame, TrainingSimulator
from crgod.training.rewarding import RewardMixer


@dataclass
class ActorStep:
    state: PlayerObservationV1
    legal_action_indices: tuple[int, ...]
    action_index: int
    behavior_logprob: float
    behavior_value: float
    reward: float
    done: bool
    prev_own_action: int
    prev_opponent_action: ObservedOpponentActionV1
    prev_opponent_known: bool
    dt_s: float
    transition_dt_s: float
    hidden_in: torch.Tensor            # [H], behavior hidden before this state


@dataclass
class ActorUnroll:
    steps: tuple[ActorStep, ...]
    initial_hidden: torch.Tensor       # [H], before first learning state is consumed
    burnin_steps: tuple[ActorStep, ...]
    burnin_initial_hidden: torch.Tensor | None
    final_state: PlayerObservationV1 | None
    final_legal_action_indices: tuple[int, ...] | None
    final_prev_own_action: int
    final_prev_opponent_action: ObservedOpponentActionV1
    final_prev_opponent_known: bool
    final_dt_s: float
    terminal: bool
    behavior_version: int
    actor_id: str
    opponent_id: str
    behavior_bootstrap_value: float

    def validate(self) -> None:
        if not self.steps: raise ValueError('empty actor unroll')
        if self.initial_hidden.ndim != 1: raise ValueError('initial_hidden must be [H]')
        if self.burnin_steps and (self.burnin_initial_hidden is None or self.burnin_initial_hidden.ndim!=1):
            raise ValueError('burn-in requires burnin_initial_hidden [H]')
        if any(s.done for s in self.burnin_steps): raise ValueError('burn-in may not cross an episode boundary')
        for i,s in enumerate(self.steps):
            if s.action_index not in s.legal_action_indices:
                raise ValueError(f'illegal behavior action at {i}')
            if s.transition_dt_s <= 0: raise ValueError('transition_dt_s must be positive')
            if i < len(self.steps)-1 and s.done:
                raise ValueError('done before end of unroll')
        if not torch.isfinite(torch.tensor(float(self.behavior_bootstrap_value))):
            raise ValueError('behavior_bootstrap_value must be finite')
        if self.terminal:
            if not self.steps[-1].done: raise ValueError('terminal unroll must end done')
            if self.final_state is not None: raise ValueError('terminal unroll must not bootstrap')
            if abs(float(self.behavior_bootstrap_value)) > 1e-8: raise ValueError('terminal behavior bootstrap must be zero')
        else:
            if self.steps[-1].done: raise ValueError('nonterminal unroll ended done')
            if self.final_state is None or self.final_legal_action_indices is None:
                raise ValueError('nonterminal unroll requires bootstrap state/legal mask')


@dataclass
class JointActorUnroll:
    seat_a: ActorUnroll
    seat_b: ActorUnroll
    outcome_a: float | None
    simulator_id: str


class RecurrentPolicyActor:
    """Inference-only recurrent actor used by self-play rollout workers."""
    def __init__(self, model, tensorizer, *, device='cpu', actor_id='actor', policy_version=0, clone_model:bool=True):
        # Rollout actors own an immutable policy snapshot by default.  Holding a
        # direct reference to the learner would let optimizer.step() silently
        # change actor weights without changing policy_version, invalidating
        # PPO/V-trace policy-lag accounting.
        self.model=(copy.deepcopy(model) if clone_model else model).to(device).eval()
        self.tensorizer=tensorizer; self.device=torch.device(device)
        self.actor_id=str(actor_id); self.policy_version=int(policy_version)
        self.hidden=None

    def reset(self): self.hidden=None

    def sync_from(self, learner_model, *, policy_version:int, force_reset_memory:bool=False):
        """Explicitly refresh the actor snapshot.

        By default synchronization is only legal at a recurrent-state boundary.
        Mid-match weight swaps would combine hidden state produced by one policy
        with another policy's recurrent dynamics.  Call reset()/sync between
        matches, or explicitly accept a memory reset.
        """
        if self.hidden is not None and not force_reset_memory:
            raise RuntimeError('refusing mid-memory actor sync; finish/reset the match first')
        self.model.load_state_dict(learner_model.state_dict(), strict=True)
        self.model.to(self.device).eval()
        self.policy_version=int(policy_version)
        if force_reset_memory:
            self.hidden=None
        return self

    def _opp(self,a:ObservedOpponentActionV1,known:bool)->OpponentActionBatch:
        if not known: return OpponentActionBatch.pass_batch(1,self.device)
        kind,card,tile=encode_observed_action(a,self.tensorizer.vocab)
        return OpponentActionBatch(torch.tensor([kind],device=self.device),torch.tensor([card],device=self.device),torch.tensor([tile],device=self.device))

    @torch.no_grad()
    def act(self, obs:PlayerObservationV1, legal_indices:tuple[int,...], *,
            prev_own_action:int, prev_opp_action:ObservedOpponentActionV1,
            prev_opp_known:bool, dt_s:float, deterministic:bool=False):
        tb=self.tensorizer.one(obs).to(self.device)
        z=self.model.encoder(tb)
        if self.hidden is None: self.hidden=self.model.initial_belief(1,self.device,z.dtype)
        hidden_in=self.hidden.detach().clone()[0].cpu()
        bp=self.model.update_belief(z,torch.tensor([prev_own_action],dtype=torch.long,device=self.device),
                                    self._opp(prev_opp_action,prev_opp_known),
                                    torch.tensor([prev_opp_known],dtype=torch.bool,device=self.device),
                                    torch.tensor([dt_s],dtype=z.dtype,device=self.device),self.hidden)
        self.hidden=bp.hidden
        mask,_=_mask_from_indices(legal_indices); mask=mask.to(self.device).unsqueeze(0)
        logits,value=self.model.head(z,self.hidden,mask)
        dist=torch.distributions.Categorical(logits=logits[0]); action=logits[0].argmax() if deterministic else dist.sample()
        idx=int(action)
        if not bool(mask[0,idx]): raise RuntimeError('policy sampled illegal action')
        return idx,float(dist.log_prob(action).cpu()),float(value[0].cpu()),hidden_in

    @torch.no_grad()
    def bootstrap_value(self, obs:PlayerObservationV1, legal_indices:tuple[int,...], *,
                        prev_own_action:int, prev_opp_action:ObservedOpponentActionV1,
                        prev_opp_known:bool, dt_s:float)->float:
        """Value the next decision state under this frozen behavior snapshot.

        This deliberately does not mutate recurrent memory. PPO should bootstrap
        from rollout-time behavior values, never from a learner that may have
        changed after collection.
        """
        if self.hidden is None:
            raise RuntimeError('cannot bootstrap before recurrent state exists')
        tb=self.tensorizer.one(obs).to(self.device)
        z=self.model.encoder(tb)
        bp=self.model.update_belief(z,torch.tensor([prev_own_action],dtype=torch.long,device=self.device),
                                    self._opp(prev_opp_action,prev_opp_known),
                                    torch.tensor([prev_opp_known],dtype=torch.bool,device=self.device),
                                    torch.tensor([dt_s],dtype=z.dtype,device=self.device),self.hidden)
        mask,_=_mask_from_indices(legal_indices); mask=mask.to(self.device).unsqueeze(0)
        _,value=self.model.head(z,bp.hidden,mask)
        return float(value[0].cpu())


def _reward(scalar:float, components, mixer:RewardMixer|None, learner_step:int)->float:
    if mixer is None or components is None: return float(scalar)
    return mixer(components,learner_step)


class SelfPlaySession:
    """Persistent simulator/actor session that emits fixed-length unrolls.

    A long match may span many unrolls. Recurrent memory and causal action
    context are preserved across chunk boundaries; only a terminal/reset starts
    from zero memory.
    """
    def __init__(self,sim:TrainingSimulator,actor_a:RecurrentPolicyActor,actor_b:RecurrentPolicyActor,*,reward_mixer:RewardMixer|None=None):
        self.sim=sim; self.actors=[actor_a,actor_b]; self.reward_mixer=reward_mixer; self.active=False

    def reset(self,*,seed:int|None=None,matchup:Mapping|None=None):
        self.frame=self.sim.reset(seed=seed,matchup=matchup); self.frame.validate()
        for a in self.actors:a.reset()
        self.prev_own=[0,0]; self.prev_opp=[ObservedOpponentActionV1.pass_action(),ObservedOpponentActionV1.pass_action()]
        self.prev_known=[False,False]; self.dt=[0.0,0.0]; self.active=True; self.outcome=None; self.history=[[],[]]
        return self.frame

    def collect(self,*,unroll_length:int=64,learner_step:int=0,burn_in_length:int=0)->JointActorUnroll:
        if not self.active: raise RuntimeError('SelfPlaySession must be reset before collect')
        if unroll_length<=0 or burn_in_length<0: raise ValueError('invalid unroll/burn-in length')
        prefixes=[tuple(self.history[i][-burn_in_length:]) if burn_in_length else tuple() for i in range(2)]
        burn_h=[p[0].hidden_in.clone() if p else None for p in prefixes]
        steps=[[],[]]; init_hidden=[None,None]
        for _ in range(unroll_length):
            ia,lpa,va,hia=self.actors[0].act(self.frame.seat_a.observation,self.frame.seat_a.legal_action_indices,
                                             prev_own_action=self.prev_own[0],prev_opp_action=self.prev_opp[0],prev_opp_known=self.prev_known[0],dt_s=self.dt[0])
            ib,lpb,vb,hib=self.actors[1].act(self.frame.seat_b.observation,self.frame.seat_b.legal_action_indices,
                                             prev_own_action=self.prev_own[1],prev_opp_action=self.prev_opp[1],prev_opp_known=self.prev_known[1],dt_s=self.dt[1])
            if init_hidden[0] is None:init_hidden=[hia,hib]
            tr=self.sim.step(ia,ib); tr.validate(); elapsed=float(tr.elapsed_s)
            ra=_reward(tr.reward_a,tr.reward_components_a,self.reward_mixer,learner_step); rb=_reward(tr.reward_b,tr.reward_components_b,self.reward_mixer,learner_step)
            steps[0].append(ActorStep(self.frame.seat_a.observation,self.frame.seat_a.legal_action_indices,ia,lpa,va,ra,bool(tr.done),
                                      self.prev_own[0],self.prev_opp[0],self.prev_known[0],self.dt[0],elapsed,hia))
            steps[1].append(ActorStep(self.frame.seat_b.observation,self.frame.seat_b.legal_action_indices,ib,lpb,vb,rb,bool(tr.done),
                                      self.prev_own[1],self.prev_opp[1],self.prev_known[1],self.dt[1],elapsed,hib))
            self.history[0].append(steps[0][-1]); self.history[1].append(steps[1][-1])
            if burn_in_length>0:
                self.history[0]=self.history[0][-burn_in_length:]; self.history[1]=self.history[1][-burn_in_length:]
            else:
                self.history=[[],[]]
            self.prev_own=[ia,ib]; self.prev_opp=[tr.action_b_observed_by_a,tr.action_a_observed_by_b]
            self.prev_known=[bool(tr.action_b_known_to_a),bool(tr.action_a_known_to_b)]; self.dt=[elapsed,elapsed]
            self.frame=tr.next_frame
            if tr.done:
                self.outcome=tr.outcome_a; self.active=False; break
        terminal=bool(steps[0][-1].done)
        def make(seat:int):
            actor=self.actors[seat]; opp=self.actors[1-seat]
            frame_seat=self.frame.seat_a if seat==0 else self.frame.seat_b
            bootstrap=0.0 if terminal else actor.bootstrap_value(
                frame_seat.observation,frame_seat.legal_action_indices,
                prev_own_action=self.prev_own[seat],prev_opp_action=self.prev_opp[seat],
                prev_opp_known=self.prev_known[seat],dt_s=self.dt[seat])
            u=ActorUnroll(tuple(steps[seat]),init_hidden[seat],prefixes[seat],burn_h[seat],None if terminal else frame_seat.observation,
                          None if terminal else frame_seat.legal_action_indices,self.prev_own[seat],self.prev_opp[seat],self.prev_known[seat],self.dt[seat],
                          terminal,actor.policy_version,actor.actor_id,opp.actor_id,bootstrap)
            u.validate(); return u
        return JointActorUnroll(make(0),make(1),self.outcome,self.sim.simulator_id)


def collect_joint_unroll(sim:TrainingSimulator, actor_a:RecurrentPolicyActor, actor_b:RecurrentPolicyActor,
                         *, unroll_length:int=64, seed:int|None=None, matchup:Mapping|None=None,
                         learner_step:int=0, reward_mixer:RewardMixer|None=None, burn_in_length:int=0) -> JointActorUnroll:
    """Convenience one-chunk collection; use SelfPlaySession for long matches."""
    sess=SelfPlaySession(sim,actor_a,actor_b,reward_mixer=reward_mixer); sess.reset(seed=seed,matchup=matchup)
    return sess.collect(unroll_length=unroll_length,learner_step=learner_step,burn_in_length=burn_in_length)
