from dataclasses import dataclass
import torch
import torch.nn.functional as F
@dataclass
class ImagineMetrics: actor_loss:float; value_loss:float; entropy:float; mean_imagined_return:float; mean_uncertainty:float; mean_kl_to_reference:float
def lambda_returns(r,v,c,b,gamma=.997,lam=.95):
    nv=torch.cat([v[1:],b.unsqueeze(0)],0); target=r+gamma*c*nv*(1-lam); out=[]; acc=b
    for t in reversed(range(r.shape[0])): acc=target[t]+gamma*c[t]*lam*acc; out.append(acc)
    return torch.stack(out[::-1],0)
def imagination_actor_critic_step(head,world,opp,start_z,opp_h,opt,start_mask,reference_policy_head=None,horizon=12,gamma=.997,lam=.95,entropy_coef=.003,kl_coef=.02,dt_s=.2,uncertainty_penalty=.5):
    head.train(); world.eval(); opp.eval(); z=start_z.detach(); h=opp_h.detach(); mask=start_mask.detach().clone(); mask[:,0]=True; lp=[]; ent=[]; rs=[]; cs=[]; vs=[]; kls=[]; us=[]; dt=torch.full((z.shape[0],),float(dt_s),device=z.device,dtype=z.dtype)
    for _ in range(horizon):
        logits,val=head(z,h,mask); dist=torch.distributions.Categorical(logits=logits); a=dist.sample(); lp.append(dist.log_prob(a)); ent.append(dist.entropy()); vs.append(val)
        if reference_policy_head is not None:
            with torch.no_grad(): rl,_=reference_policy_head(z,h,mask)
            kls.append(torch.distributions.kl_divergence(dist,torch.distributions.Categorical(logits=rl)))
        else: kls.append(torch.zeros_like(val))
        with torch.no_grad():
            oa=opp.sample(z,h); nz,r,c,nleg,u=world.conservative_prediction(z,a,oa,dt,uncertainty_penalty); h=opp.update(z,oa,h); mask=(torch.sigmoid(nleg)>=.5); mask[:,0]=True; c=torch.sigmoid(c).clamp(0,1)
        rs.append(r); cs.append(c); us.append(u); z=nz.detach()
    _,boot=head(z,h,mask); rs=torch.stack(rs); cs=torch.stack(cs); vs=torch.stack(vs); ret=lambda_returns(rs,vs.detach(),cs,boot.detach(),gamma,lam); lp=torch.stack(lp); ent=torch.stack(ent); kls=torch.stack(kls); us=torch.stack(us); adv=ret-vs.detach(); al=-(lp*adv).mean()-entropy_coef*ent.mean()+kl_coef*kls.mean(); vl=F.smooth_l1_loss(vs,ret.detach()); loss=al+.5*vl; opt.zero_grad(set_to_none=True); loss.backward(); torch.nn.utils.clip_grad_norm_(head.parameters(),1.); opt.step(); return ImagineMetrics(float(al.detach()),float(vl.detach()),float(ent.mean().detach()),float(ret.mean().detach()),float(us.mean().detach()),float(kls.mean().detach()))
