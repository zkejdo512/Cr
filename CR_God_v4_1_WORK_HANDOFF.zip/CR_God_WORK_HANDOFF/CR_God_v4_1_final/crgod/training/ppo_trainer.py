from __future__ import annotations

from dataclasses import dataclass
import random
from crgod.training.ppo_v2 import recurrent_ppo_step, RecurrentPPOBatch


@dataclass(frozen=True)
class PPOTrainerConfig:
    epochs: int = 4
    target_kl: float = .02
    hard_stop_kl: float = .05
    clip_eps: float = .2
    value_coef: float = .5
    entropy_coef: float = .01
    max_grad_norm: float = 1.0
    value_clip_eps: float = .2


@dataclass(frozen=True)
class PPOTrainerMetrics:
    updates: int
    epochs_completed: int
    mean_loss: float
    mean_kl: float
    max_kl: float
    mean_clip_fraction: float
    mean_entropy: float
    mean_value_loss: float
    max_grad_norm: float
    early_stopped: bool


class RecurrentPPOTrainer:
    """Multi-epoch PPO with a hard KL circuit breaker."""
    def __init__(self,model,optimizer,cfg:PPOTrainerConfig=PPOTrainerConfig()):
        self.model=model; self.optimizer=optimizer; self.cfg=cfg

    def update(self,batches:list[RecurrentPPOBatch],*,rng:random.Random|None=None,device=None)->PPOTrainerMetrics:
        if not batches: raise ValueError('empty PPO batch list')
        if device is None:
            device=next(self.model.parameters()).device
        batches=[b.to(device) for b in batches]
        rng=rng or random.Random(); losses=[]; kls=[]; clips=[]; entropies=[]; value_losses=[]; grad_norms=[]; updates=0; epochs=0; stopped=False
        for ep in range(self.cfg.epochs):
            order=list(range(len(batches))); rng.shuffle(order)
            for i in order:
                m=recurrent_ppo_step(self.model,batches[i],self.optimizer,clip_eps=self.cfg.clip_eps,
                                     value_coef=self.cfg.value_coef,entropy_coef=self.cfg.entropy_coef,
                                     max_grad_norm=self.cfg.max_grad_norm,value_clip_eps=self.cfg.value_clip_eps)
                losses.append(m.loss); kls.append(m.approx_kl); clips.append(m.clip_fraction); entropies.append(m.entropy); value_losses.append(m.value_loss); grad_norms.append(m.grad_norm); updates+=1
                if m.approx_kl>self.cfg.hard_stop_kl:
                    stopped=True; break
            epochs=ep+1
            if stopped or (kls and sum(kls[-len(order):])/max(1,min(len(order),len(kls)))>self.cfg.target_kl*1.5):
                stopped=True; break
        return PPOTrainerMetrics(updates,epochs,sum(losses)/len(losses),sum(kls)/len(kls),max(kls),
                                 sum(clips)/len(clips),sum(entropies)/len(entropies),sum(value_losses)/len(value_losses),max(grad_norms),stopped)
