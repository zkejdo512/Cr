from __future__ import annotations
from dataclasses import dataclass
import torch
import torch.nn.functional as F
from crgod.models.belief import BeliefPrediction


@dataclass
class BeliefTargets:
    opponent_elixir: torch.Tensor       # normalized [0,1]
    hand_presence: torch.Tensor         # [B,V] multi-hot
    next_card: torch.Tensor             # [B]
    next_card_known: torch.Tensor       # [B] bool


@dataclass
class BeliefMetrics:
    loss: float
    elixir_mae: float
    hand_bce: float
    next_ce: float
    next_accuracy: float


def belief_auxiliary_loss(pred: BeliefPrediction, target: BeliefTargets,
                          elixir_weight: float = 1.0, hand_weight: float = .5,
                          next_weight: float = .5):
    elixir = F.smooth_l1_loss(pred.opponent_elixir, target.opponent_elixir)
    # Reserved PAD/UNK tokens are not real card identities and must not become
    # easy auxiliary targets. A production belief vocabulary must cover the
    # complete supported card registry.
    hand = F.binary_cross_entropy_with_logits(pred.hand_presence_logits[:, 2:], target.hand_presence[:, 2:])
    known = target.next_card_known.bool()
    if bool(known.any()):
        next_logits = pred.next_card_logits[known].clone()
        next_logits[:, :2] = -1e9
        nxt = F.cross_entropy(next_logits, target.next_card[known])
        acc = (next_logits.argmax(-1) == target.next_card[known]).float().mean()
    else:
        nxt = pred.next_card_logits.sum() * 0.0
        acc = torch.zeros((), device=pred.next_card_logits.device)
    loss = elixir_weight * elixir + hand_weight * hand + next_weight * nxt
    mae = (pred.opponent_elixir - target.opponent_elixir).abs().mean()
    return loss, BeliefMetrics(float(loss.detach()), float(mae.detach()),
                               float(hand.detach()), float(nxt.detach()), float(acc.detach()))


def targets_from_true_states(states, vocab, side: str = 'self', device=None) -> BeliefTargets:
    """Build privileged auxiliary labels without exposing them to policy input.

    `side` is the player whose observation/policy is being trained. Targets are
    always the *other* side's private state in that player's canonical view.
    """
    if side not in ('self', 'opponent'):
        raise ValueError(side)
    required=[]
    for s in states:
        cards = s.opponent_hand if side == 'self' else s.self_hand
        next_card = s.opponent_next_card if side == 'self' else s.self_next_card
        required.extend(c.card_id for c in cards)
        if next_card is not None: required.append(next_card.card_id)
    vocab.assert_covers(required, context='belief training vocabulary')
    B=len(states); V=vocab.size
    hand=torch.zeros(B,V,dtype=torch.float32,device=device)
    nxt=torch.zeros(B,dtype=torch.long,device=device)
    known=torch.zeros(B,dtype=torch.bool,device=device)
    elixir=torch.zeros(B,dtype=torch.float32,device=device)
    for i,s in enumerate(states):
        if side=='self':
            cards=s.opponent_hand; next_card=s.opponent_next_card; e=s.opponent_elixir
        else:
            cards=s.self_hand; next_card=s.self_next_card; e=s.self_elixir
        elixir[i]=min(max(float(e)/10.0,0.0),1.0)
        for c in cards:
            tok=vocab.encode(c.card_id)
            if tok>0: hand[i,tok]=1.0
        if next_card is not None:
            nxt[i]=vocab.encode(next_card.card_id); known[i]=nxt[i].item()>0
    return BeliefTargets(elixir,hand,nxt,known)
