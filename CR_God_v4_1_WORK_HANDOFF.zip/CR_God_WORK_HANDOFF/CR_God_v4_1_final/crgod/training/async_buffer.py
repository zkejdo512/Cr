from __future__ import annotations
from collections import deque
from dataclasses import dataclass
import random
from typing import Generic, TypeVar

T=TypeVar('T')


@dataclass
class VersionedItem(Generic[T]):
    payload: T
    behavior_version: int
    actor_id: str = 'actor'


class FreshUnrollBuffer(Generic[T]):
    """Bounded actor→learner buffer with hard policy-lag rejection."""
    def __init__(self, capacity: int = 2048, max_policy_lag: int = 8):
        if capacity <= 0 or max_policy_lag < 0: raise ValueError('invalid buffer config')
        self.capacity=int(capacity); self.max_policy_lag=int(max_policy_lag)
        self._items: deque[VersionedItem[T]]=deque(maxlen=self.capacity)
        self.dropped_stale=0

    def push(self,item:VersionedItem[T], learner_version:int)->bool:
        lag=int(learner_version)-int(item.behavior_version)
        if lag < 0:
            raise ValueError('actor behavior_version is newer than learner_version')
        if lag>self.max_policy_lag:
            self.dropped_stale+=1; return False
        self._items.append(item); return True

    def purge_stale(self,learner_version:int)->int:
        keep=deque(maxlen=self.capacity); dropped=0
        for x in self._items:
            lag=int(learner_version)-int(x.behavior_version)
            if lag < 0:
                raise ValueError('buffer contains actor version newer than learner')
            if lag>self.max_policy_lag: dropped+=1
            else: keep.append(x)
        self._items=keep; self.dropped_stale+=dropped; return dropped

    def sample(self,n:int,rng:random.Random|None=None)->list[VersionedItem[T]]:
        if n<=0: raise ValueError('n must be positive')
        if len(self._items)<n: raise RuntimeError(f'buffer has {len(self._items)} items, need {n}')
        rng=rng or random
        return rng.sample(list(self._items),n)

    def __len__(self): return len(self._items)
