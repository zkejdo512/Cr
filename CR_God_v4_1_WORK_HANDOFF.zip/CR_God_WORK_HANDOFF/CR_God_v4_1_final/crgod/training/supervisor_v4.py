from __future__ import annotations
from dataclasses import dataclass
import math


@dataclass(frozen=True)
class HealthSnapshot:
    learner_step:int
    approx_kl:float
    clip_fraction:float
    grad_norm:float
    value_loss:float
    entropy:float
    eval_win_rate:float|None=None
    worst_slice_win_rate:float|None=None
    catastrophic_rate:float|None=None


@dataclass(frozen=True)
class SupervisorDecision:
    action:str   # keep, rollback, stop
    reasons:tuple[str,...]


class TrainingSupervisorV4:
    """Fail-closed long-run health monitor based on training + held-out signals."""
    def __init__(self,max_kl=.06,max_clip_fraction=.65,max_grad_norm=1000.,max_catastrophic_rate=.02,
                 regression_tolerance=.04,patience=2):
        self.max_kl=float(max_kl);self.max_clip_fraction=float(max_clip_fraction);self.max_grad_norm=float(max_grad_norm)
        self.max_catastrophic_rate=float(max_catastrophic_rate);self.regression_tolerance=float(regression_tolerance);self.patience=int(patience)
        self.best_eval=None;self.bad=0
    def inspect(self,x:HealthSnapshot)->SupervisorDecision:
        vals=(x.approx_kl,x.clip_fraction,x.grad_norm,x.value_loss,x.entropy)
        if not all(math.isfinite(float(v)) for v in vals):return SupervisorDecision('stop',('non-finite training metric',))
        hard=[]
        if x.approx_kl>self.max_kl:hard.append('KL circuit breaker')
        if x.clip_fraction>self.max_clip_fraction:hard.append('excessive PPO clipping')
        if x.grad_norm>self.max_grad_norm:hard.append('gradient explosion')
        if x.catastrophic_rate is not None and x.catastrophic_rate>self.max_catastrophic_rate:hard.append('catastrophic action rate')
        if hard:return SupervisorDecision('rollback',tuple(hard))
        if x.eval_win_rate is not None:
            if self.best_eval is None or x.eval_win_rate>self.best_eval:self.best_eval=x.eval_win_rate;self.bad=0
            elif x.eval_win_rate<self.best_eval-self.regression_tolerance:self.bad+=1
            else:self.bad=0
            if self.bad>=self.patience:return SupervisorDecision('rollback',('held-out regression persisted',))
        return SupervisorDecision('keep',())
