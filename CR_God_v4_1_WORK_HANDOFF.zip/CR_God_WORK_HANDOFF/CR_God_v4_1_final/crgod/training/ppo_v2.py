from __future__ import annotations
from dataclasses import dataclass
import torch
import torch.nn.functional as F
from crgod.tensorizer import concat_tensor_batches
from crgod.opponent_codec import OpponentActionBatch


@dataclass
class RecurrentPPOBatch:
    states: list
    prev_own_actions: torch.Tensor       # [T,B]
    prev_opp_actions: list[OpponentActionBatch]
    prev_opp_known: torch.Tensor         # [T,B]
    dt_s: torch.Tensor                   # [T,B]
    legal_masks: torch.Tensor            # [T,B,A]
    actions: torch.Tensor                # [T,B]
    old_logprob: torch.Tensor            # [T,B]
    advantages: torch.Tensor             # [T,B]
    returns: torch.Tensor                # [T,B]
    reset_before: torch.Tensor | None = None # [T,B] bool
    loss_mask: torch.Tensor | None = None      # [T,B] bool; False = burn-in only
    initial_hidden: torch.Tensor | None = None  # [B,H], exact rollout memory at sequence start
    old_values: torch.Tensor | None = None         # [T,B], behavior critic values for clipped value loss

    def to(self, device):
        self.states=[x.to(device) for x in self.states]
        self.prev_opp_actions=[x.to(device) for x in self.prev_opp_actions]
        for name in ('prev_own_actions','prev_opp_known','dt_s','legal_masks','actions','old_logprob','advantages','returns'):
            setattr(self,name,getattr(self,name).to(device))
        if self.reset_before is not None: self.reset_before=self.reset_before.to(device)
        if self.loss_mask is not None: self.loss_mask=self.loss_mask.to(device)
        if self.initial_hidden is not None: self.initial_hidden=self.initial_hidden.to(device)
        if self.old_values is not None: self.old_values=self.old_values.to(device)
        return self


@dataclass
class RecurrentPPOMetrics:
    loss: float
    policy_loss: float
    value_loss: float
    entropy: float
    approx_kl: float
    clip_fraction: float
    grad_norm: float


def compute_gae(rewards: torch.Tensor, values: torch.Tensor, dones: torch.Tensor,
                bootstrap_value: torch.Tensor, gamma: float = .997, lam: float = .95,
                transition_dt_s: torch.Tensor | None = None, base_dt_s: float = .5):
    """Generalized advantage estimation for [T,B] tensors.

    `gamma` and `lam` are specified per `base_dt_s`; variable-duration replay
    transitions are exponentiated rather than silently treated as equal steps.
    """
    if rewards.shape != values.shape or rewards.shape != dones.shape:
        raise ValueError('GAE rewards/values/dones shape mismatch')
    if not (0.0 < gamma <= 1.0 and 0.0 < lam <= 1.0) or base_dt_s <= 0:
        raise ValueError('invalid GAE gamma/lam/base_dt_s')
    if transition_dt_s is None:
        transition_dt_s=torch.full_like(rewards,float(base_dt_s))
    if transition_dt_s.shape != rewards.shape or bool((transition_dt_s<=0).any()):
        raise ValueError('GAE transition_dt_s must match [T,B] and be positive')
    T=rewards.shape[0]; adv=torch.zeros_like(rewards); last=torch.zeros_like(bootstrap_value)
    for t in reversed(range(T)):
        nonterminal=(~dones[t].bool()).to(rewards.dtype)
        next_v=bootstrap_value if t==T-1 else values[t+1]
        scale=transition_dt_s[t]/float(base_dt_s)
        gamma_t=torch.pow(torch.full_like(scale,float(gamma)),scale)
        lam_t=torch.pow(torch.full_like(scale,float(lam)),scale)
        delta=rewards[t]+gamma_t*nonterminal*next_v-values[t]
        last=delta+gamma_t*lam_t*nonterminal*last
        adv[t]=last
    return adv,adv+values


def recurrent_ppo_step(model, batch: RecurrentPPOBatch, optimizer,
                       clip_eps=.2, value_coef=.5, entropy_coef=.01,
                       max_grad_norm=1.0, value_clip_eps=.2):
    T, B = batch.actions.shape
    h = (model.initial_belief(B, batch.actions.device) if batch.initial_hidden is None
         else batch.initial_hidden)
    if h.shape[0] != B:
        raise ValueError(f'initial_hidden batch mismatch: {h.shape[0]} != {B}')
    # The observation encoder is feed-forward, so encode T*B states in one
    # vectorized call instead of launching a Transformer pass per time step.
    flat_states=concat_tensor_batches(batch.states)
    z_all=model.encoder(flat_states).reshape(T,B,-1)
    logps=[]; values=[]; ents=[]
    for t in range(T):
        if batch.reset_before is not None:
            keep=(~batch.reset_before[t]).to(h.dtype).unsqueeze(-1)
            h=h*keep
        z=z_all[t]
        bp=model.update_belief(z,batch.prev_own_actions[t],batch.prev_opp_actions[t],
                               batch.prev_opp_known[t],batch.dt_s[t],h)
        h=bp.hidden
        logits,v=model.head(z,h,batch.legal_masks[t])
        rows=torch.arange(B,device=batch.actions.device)
        if not bool(batch.legal_masks[t,rows,batch.actions[t]].all()):
            raise ValueError('recurrent PPO contains illegal action')
        dist=torch.distributions.Categorical(logits=logits)
        logps.append(dist.log_prob(batch.actions[t])); values.append(v); ents.append(dist.entropy())
    logp=torch.stack(logps); value=torch.stack(values); ent=torch.stack(ents)
    active=(torch.ones_like(batch.actions,dtype=torch.bool) if batch.loss_mask is None else batch.loss_mask.bool())
    if not bool(active.any()): raise ValueError('recurrent PPO loss_mask contains no training steps')
    log_ratio=logp-batch.old_logprob; ratio=log_ratio.exp()
    raw_adv=batch.advantages[active]
    norm_adv=(raw_adv-raw_adv.mean())/raw_adv.std(unbiased=False).clamp_min(1e-6)
    ratio_a=ratio[active]; log_ratio_a=log_ratio[active]
    p1=ratio_a*norm_adv; p2=ratio_a.clamp(1-clip_eps,1+clip_eps)*norm_adv
    policy=-torch.minimum(p1,p2).mean()
    if batch.old_values is not None and value_clip_eps is not None:
        oldv=batch.old_values[active]
        vnew=value[active]
        vclip=oldv+(vnew-oldv).clamp(-float(value_clip_eps),float(value_clip_eps))
        l1=F.smooth_l1_loss(vnew,batch.returns[active],reduction='none')
        l2=F.smooth_l1_loss(vclip,batch.returns[active],reduction='none')
        vl=torch.maximum(l1,l2).mean()
    else:
        vl=F.smooth_l1_loss(value[active],batch.returns[active])
    entropy=ent[active].mean()
    loss=policy+value_coef*vl-entropy_coef*entropy
    optimizer.zero_grad(set_to_none=True); loss.backward(); gn=torch.nn.utils.clip_grad_norm_(model.parameters(),max_grad_norm); optimizer.step()
    kl=((ratio_a-1)-log_ratio_a).mean().detach(); cf=((ratio_a-1).abs()>clip_eps).float().mean().detach()
    return RecurrentPPOMetrics(float(loss.detach()),float(policy.detach()),float(vl.detach()),
                               float(entropy.detach()),float(kl),float(cf),float(gn))
