from __future__ import annotations
from dataclasses import dataclass
import random
from typing import Any


@dataclass
class PlannerCorrection:
    payload: Any
    fast_action: int
    planner_action: int
    estimated_regret: float
    uncertainty: float
    archetype: str='unknown'
    uses: int=0


class PlannerCorrectionBuffer:
    """Stores only meaningful slow-brain corrections for later distillation."""
    def __init__(self,capacity:int=20_000,min_regret:float=.02):
        self.capacity=int(capacity); self.min_regret=float(min_regret); self.items:list[PlannerCorrection]=[]
    def add(self,x:PlannerCorrection)->bool:
        if x.fast_action==x.planner_action or x.estimated_regret<self.min_regret:return False
        self.items.append(x)
        if len(self.items)>self.capacity:
            self.items.sort(key=lambda y:y.estimated_regret/(1+.1*y.uses),reverse=True)
            self.items=self.items[:self.capacity]
        return True
    def sample(self,n:int,rng:random.Random|None=None)->list[PlannerCorrection]:
        if n<=0 or not self.items:return []
        rng=rng or random.Random(); pool=list(self.items); out=[]
        for _ in range(min(n,len(pool))):
            ws=[max(1e-4,x.estimated_regret)*(1+.25*x.uncertainty)/(1+.15*x.uses) for x in pool]
            i=rng.choices(range(len(pool)),weights=ws,k=1)[0]; x=pool.pop(i); x.uses+=1; out.append(x)
        return out
