from __future__ import annotations

from dataclasses import dataclass, field
import random
from crgod.league_v2 import LeagueMember, PFSPLeague


@dataclass(frozen=True)
class SnapshotRule:
    min_games: int = 100
    min_win_rate_vs_history: float = .60
    max_steps_between_snapshots: int = 1_000_000


@dataclass
class MainProgress:
    learner_steps: int = 0
    games_since_snapshot: int = 0
    last_snapshot_step: int = 0


class LeagueManagerV3:
    """Auditable main/historical/exploiter league coordinator."""
    def __init__(self,main:LeagueMember,*,snapshot_rule:SnapshotRule=SnapshotRule(),history_mix:float=.20):
        if main.role!='main': raise ValueError('initial member must be main')
        if not 0<=history_mix<=1: raise ValueError('history_mix outside [0,1]')
        self.league=PFSPLeague(); self.league.add(main); self.main_id=main.member_id
        self.rule=snapshot_rule; self.history_mix=float(history_mix); self.progress=MainProgress(); self.snapshot_count=0

    def add_exploiter(self,member:LeagueMember):
        if member.role!='exploiter':
            raise ValueError('expected exploiter')
        self.league.add(member)

    def record(self,a:str,b:str,score_a:float): self.league.record(a,b,score_a)

    def choose_opponent(self,rng:random.Random|None=None)->LeagueMember:
        rng=rng or random.Random(); members=[m for k,m in self.league.members.items() if k!=self.main_id]
        if not members: raise RuntimeError('league has no opponent')
        historical=[m for m in members if m.role=='historical']
        if historical and rng.random()<self.history_mix:
            # PFSP restricted to historicals: emphasize forgotten/hard policies.
            weights=[max(1e-3,(1-self.league.payoff.win_rate(self.main_id,m.member_id))**2) for m in historical]
            return rng.choices(historical,weights=weights,k=1)[0]
        return self.league.sample_opponent(self.main_id,rng)

    def should_snapshot(self)->bool:
        hist=[m for m in self.league.members.values() if m.role=='historical']
        if not hist:return self.progress.learner_steps-self.progress.last_snapshot_step>=self.rule.max_steps_between_snapshots
        if self.progress.games_since_snapshot<self.rule.min_games:return False
        wr=sum(self.league.payoff.win_rate(self.main_id,m.member_id) for m in hist)/len(hist)
        return wr>=self.rule.min_win_rate_vs_history or self.progress.learner_steps-self.progress.last_snapshot_step>=self.rule.max_steps_between_snapshots

    def register_snapshot(self,path:str)->LeagueMember:
        self.snapshot_count+=1; main=self.league.members[self.main_id]
        m=LeagueMember(f'{self.main_id}-hist-{self.snapshot_count:04d}',path,'historical',generation=main.generation,elo=main.elo,frozen=True)
        self.league.add(m); self.progress.games_since_snapshot=0; self.progress.last_snapshot_step=self.progress.learner_steps; return m
