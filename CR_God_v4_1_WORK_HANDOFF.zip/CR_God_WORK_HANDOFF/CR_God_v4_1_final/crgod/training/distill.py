from __future__ import annotations
from dataclasses import dataclass
import torch

from crgod.training.bc_v2 import RecurrentBCBatch
from crgod.training.regularizers import masked_policy_kl


@dataclass(frozen=True)
class DistillMetrics:
    loss: float
    kl: float


def recurrent_policy_distill_step(student,teacher,batch:RecurrentBCBatch,optimizer,*,coef:float=1.0,max_grad_norm:float=1.0):
    """Sequence distillation used for expert anchoring or planner→policy transfer."""
    if coef<0: raise ValueError('coef must be non-negative')
    T,B=batch.expert_actions.shape; device=batch.expert_actions.device
    hs=student.initial_belief(B,device); ht=teacher.initial_belief(B,device)
    losses=[]
    teacher.eval(); student.train()
    for t in range(T):
        if batch.reset_before is not None:
            keep=(~batch.reset_before[t]).to(hs.dtype).unsqueeze(-1); hs=hs*keep; ht=ht*keep
        zs=student.encoder(batch.states[t]); bp_s=student.update_belief(zs,batch.prev_own_actions[t],batch.prev_opp_actions[t],batch.prev_opp_known[t],batch.dt_s[t],hs); hs=bp_s.hidden
        ls,_=student.head(zs,hs,batch.legal_masks[t])
        with torch.no_grad():
            zt=teacher.encoder(batch.states[t]); bp_t=teacher.update_belief(zt,batch.prev_own_actions[t],batch.prev_opp_actions[t],batch.prev_opp_known[t],batch.dt_s[t],ht); ht=bp_t.hidden
            lt,_=teacher.head(zt,ht,batch.legal_masks[t])
        active=torch.ones(B,dtype=torch.bool,device=device) if batch.loss_mask is None else batch.loss_mask[t].bool()
        if bool(active.any()): losses.append(masked_policy_kl(ls[active],lt[active],batch.legal_masks[t][active]))
    if not losses: raise ValueError('distillation batch has no active steps')
    kl=torch.stack(losses).mean(); loss=coef*kl
    optimizer.zero_grad(set_to_none=True); loss.backward(); torch.nn.utils.clip_grad_norm_(student.parameters(),max_grad_norm); optimizer.step()
    return DistillMetrics(float(loss.detach()),float(kl.detach()))
