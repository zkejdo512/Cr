from __future__ import annotations
from dataclasses import dataclass
import math, random
from typing import Any


@dataclass(frozen=True)
class HardCaseSignal:
    outcome_failure: float = 0.0
    value_error: float = 0.0
    policy_entropy: float = 0.0
    planner_regret: float = 0.0
    belief_error: float = 0.0
    rarity: float = 0.0


@dataclass(frozen=True)
class HardCaseWeights:
    outcome_failure: float = 1.0
    value_error: float = 0.6
    policy_entropy: float = 0.25
    planner_regret: float = 1.2
    belief_error: float = 0.5
    rarity: float = 0.35


@dataclass
class HardCase:
    key: str
    payload: Any
    archetype: str
    signal: HardCaseSignal
    priority: float
    visits: int = 0


def hardcase_priority(signal:HardCaseSignal,w:HardCaseWeights=HardCaseWeights())->float:
    vals=(signal.outcome_failure,signal.value_error,signal.policy_entropy,signal.planner_regret,signal.belief_error,signal.rarity)
    if not all(math.isfinite(float(x)) and float(x)>=0 for x in vals):
        raise ValueError('hard-case signals must be finite and non-negative')
    return float(w.outcome_failure*signal.outcome_failure+w.value_error*signal.value_error+
                 w.policy_entropy*signal.policy_entropy+w.planner_regret*signal.planner_regret+
                 w.belief_error*signal.belief_error+w.rarity*signal.rarity)


class HardCaseBuffer:
    """Bounded priority buffer with diversity-aware sampling/eviction.

    Early in training the buffer may contain only one archetype; it is allowed
    to fill instead of discarding almost everything. Diversity is enforced in
    sampling and, once full, by preferentially evicting redundant archetypes.
    """
    def __init__(self,capacity:int=10_000,max_archetype_fraction:float=.35,priority_floor:float=1e-4):
        if capacity<=0 or not 0<max_archetype_fraction<=1:raise ValueError('invalid hard-case buffer config')
        self.capacity=int(capacity);self.max_archetype_fraction=float(max_archetype_fraction);self.priority_floor=float(priority_floor);self._items={}
    def __len__(self):return len(self._items)
    def archetype_counts(self)->dict[str,int]:
        d={}
        for x in self._items.values():d[x.archetype]=d.get(x.archetype,0)+1
        return d
    def add(self,key:str,payload:Any,archetype:str,signal:HardCaseSignal,*,weights:HardCaseWeights=HardCaseWeights())->bool:
        p=max(self.priority_floor,hardcase_priority(signal,weights))
        if key in self._items:
            old=self._items[key];self._items[key]=HardCase(key,payload,archetype,signal,max(old.priority,p),old.visits);return True
        self._items[key]=HardCase(key,payload,archetype,signal,p,0)
        if len(self._items)>self.capacity:
            counts=self.archetype_counts(); total=len(self._items)
            # Penalize low-priority items from overrepresented archetypes.
            def keep_score(x):
                frac=counts[x.archetype]/total
                redundancy=max(1.0,frac/max(self.max_archetype_fraction,1e-6))
                return x.priority/(redundancy*(1+.05*x.visits))
            weakest=min(self._items.values(),key=keep_score);del self._items[weakest.key]
            return key in self._items
        return True
    def sample(self,n:int,rng:random.Random|None=None,alpha:float=.7,diversity_beta:float=.5)->list[HardCase]:
        if n<=0 or not self._items:return []
        rng=rng or random.Random();items=list(self._items.values());counts=self.archetype_counts();out=[]
        for _ in range(min(n,len(items))):
            ws=[max(self.priority_floor,x.priority)**alpha/(1+.15*x.visits)/(counts[x.archetype]**diversity_beta) for x in items]
            i=rng.choices(range(len(items)),weights=ws,k=1)[0];x=items.pop(i);x.visits+=1;out.append(x)
        return out
