from __future__ import annotations
from dataclasses import dataclass
import torch
import torch.nn.functional as F


@dataclass(frozen=True)
class PlannerTarget:
    probabilities: torch.Tensor
    legal_mask: torch.Tensor


def planner_target_from_q(q_values:dict[int,float],legal_mask:torch.Tensor,*,temperature:float=.25,prior_logits:torch.Tensor|None=None,prior_weight:float=.15)->PlannerTarget:
    if temperature<=0:raise ValueError('temperature must be positive')
    legal=legal_mask.bool()
    if legal.ndim!=1:raise ValueError('legal_mask must be 1-D')
    if not q_values:raise ValueError('planner target requires candidates')
    ids=sorted(q_values)
    if any(i<0 or i>=len(legal) or not bool(legal[i]) for i in ids):raise ValueError('planner candidate is illegal')
    q=torch.tensor([q_values[i] for i in ids],dtype=torch.float32,device=legal.device)/temperature
    if prior_logits is not None:
        if prior_logits.shape!=legal.shape:raise ValueError('prior shape mismatch')
        q=q+float(prior_weight)*F.log_softmax(prior_logits[ids],dim=-1)
    p=F.softmax(q,dim=-1); out=torch.zeros_like(legal,dtype=torch.float32); out[torch.tensor(ids,device=legal.device)]=p
    return PlannerTarget(out,legal)


def planner_distillation_loss(policy_logits:torch.Tensor,target:PlannerTarget)->torch.Tensor:
    if policy_logits.ndim!=1 or policy_logits.shape!=target.probabilities.shape:raise ValueError('planner distill shape mismatch')
    neg=torch.finfo(policy_logits.dtype).min
    logp=F.log_softmax(policy_logits.masked_fill(~target.legal_mask,neg),dim=-1)
    return -(target.probabilities*logp).sum()
