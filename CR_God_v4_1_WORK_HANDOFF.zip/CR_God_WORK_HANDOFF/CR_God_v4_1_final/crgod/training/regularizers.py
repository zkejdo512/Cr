from __future__ import annotations
import torch
import torch.nn.functional as F


def masked_policy_kl(student_logits: torch.Tensor, teacher_logits: torch.Tensor,
                     legal_mask: torch.Tensor) -> torch.Tensor:
    """KL(teacher || student) only over legal actions."""
    if student_logits.shape != teacher_logits.shape or student_logits.shape != legal_mask.shape:
        raise ValueError('KL tensor shape mismatch')
    legal=legal_mask.bool()
    if not bool(legal.any(dim=-1).all()):
        raise ValueError('each KL row needs at least one legal action')
    neg=torch.finfo(student_logits.dtype).min
    s=student_logits.masked_fill(~legal,neg)
    t=teacher_logits.masked_fill(~legal,neg)
    t_prob=F.softmax(t,dim=-1)
    return (t_prob*(F.log_softmax(t,dim=-1)-F.log_softmax(s,dim=-1))).sum(-1).mean()


class AnchorSchedule:
    """Human/expert-policy anchor that fades rather than disappearing abruptly."""
    def __init__(self,start=0.20,end=0.02,decay_steps=10_000_000):
        self.start=float(start); self.end=float(end); self.decay_steps=max(int(decay_steps),1)
    def coefficient(self,step:int)->float:
        x=min(max(int(step),0)/self.decay_steps,1.0)
        return self.start*(1-x)+self.end*x
