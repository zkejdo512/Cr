from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class TrainingStage(str,Enum):
    BC='bc'
    PPO_BOOTSTRAP='ppo_bootstrap'
    LEAGUE='league'
    PLANNER_DISTILL='planner_distill'
    WORLD_MODEL_EXPERIMENT='world_model_experiment'


@dataclass(frozen=True)
class StageEvidence:
    paired_games: int
    mean_delta: float
    worst_archetype_delta: float
    illegal_action_rate: float
    finite: bool = True


@dataclass(frozen=True)
class PromotionRule:
    min_paired_games: int = 100
    min_mean_delta: float = .01
    max_worst_archetype_regression: float = .03
    max_illegal_action_rate: float = 0.0


class TrainingCurriculumV3:
    order=(TrainingStage.BC,TrainingStage.PPO_BOOTSTRAP,TrainingStage.LEAGUE,TrainingStage.PLANNER_DISTILL,TrainingStage.WORLD_MODEL_EXPERIMENT)
    def __init__(self,stage:TrainingStage=TrainingStage.BC,rule:PromotionRule=PromotionRule()): self.stage=stage; self.rule=rule
    def can_promote(self,e:StageEvidence)->tuple[bool,list[str]]:
        r=self.rule; b=[]
        if not e.finite:b.append('non-finite metrics')
        if e.paired_games<r.min_paired_games:b.append(f'paired_games {e.paired_games}<{r.min_paired_games}')
        if e.mean_delta<r.min_mean_delta:b.append(f'mean_delta {e.mean_delta:.3f}<{r.min_mean_delta:.3f}')
        if e.worst_archetype_delta < -r.max_worst_archetype_regression:b.append('worst archetype regression too large')
        if e.illegal_action_rate>r.max_illegal_action_rate:b.append('illegal action rate above gate')
        return not b,b
    def promote(self,e:StageEvidence)->TrainingStage:
        ok,b=self.can_promote(e)
        if not ok: raise RuntimeError('stage promotion blocked: '+'; '.join(b))
        i=self.order.index(self.stage)
        if i==len(self.order)-1:return self.stage
        self.stage=self.order[i+1]; return self.stage
