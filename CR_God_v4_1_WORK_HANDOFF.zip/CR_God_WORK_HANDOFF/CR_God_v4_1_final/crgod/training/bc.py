from dataclasses import dataclass
import torch
import torch.nn.functional as F
from .losses import behavior_clone_loss
@dataclass
class BCMetrics: loss:float; policy_loss:float; value_loss:float; accuracy:float
def bc_step(model,batch,actions,optimizer,legal_mask=None,return_target=None,value_weight=.5):
    model.train(); _,logits,value=model(batch,legal_mask=legal_mask)
    if legal_mask is not None:
        rows=torch.arange(actions.shape[0],device=actions.device)
        if not bool(legal_mask[rows,actions].all()): raise ValueError("BC target illegal")
    pl=behavior_clone_loss(logits,actions); vl=torch.zeros((),device=pl.device) if return_target is None else F.smooth_l1_loss(value,return_target); loss=pl+value_weight*vl
    optimizer.zero_grad(set_to_none=True); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.); optimizer.step(); acc=(logits.argmax(-1)==actions).float().mean(); return BCMetrics(float(loss.detach()),float(pl.detach()),float(vl.detach()),float(acc.detach()))
