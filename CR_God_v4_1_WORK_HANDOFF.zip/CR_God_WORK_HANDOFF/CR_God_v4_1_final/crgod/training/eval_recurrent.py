from __future__ import annotations
from dataclasses import dataclass
import torch
from crgod.action_codec import encode_action
from crgod.data import _mask_from_indices
from crgod.opponent_codec import OpponentActionBatch, encode_observed_action


@dataclass(frozen=True)
class RecurrentEval:
    decisions: int
    accuracy: float
    illegal_argmax_rate: float
    mean_value: float


@torch.no_grad()
def evaluate_recurrent_policy(model, episodes, tensorizer, device='cpu') -> RecurrentEval:
    device=torch.device(device); model=model.to(device).eval()
    correct=illegal=total=0; value_sum=0.0
    for ep in episodes:
        ep.validate(); h=model.initial_belief(1,device)
        prev_own=0; prev_opp=None; prev_known=False; dt=0.0
        for i,tr in enumerate(ep.transitions):
            z=model.encoder(tensorizer.one(tr.state).to(device))
            if prev_opp is None or not prev_known:
                opp=OpponentActionBatch.pass_batch(1,device)
            else:
                kind,card,tile=encode_observed_action(prev_opp,tensorizer.vocab)
                opp=OpponentActionBatch(torch.tensor([kind],device=device),torch.tensor([card],device=device),torch.tensor([tile],device=device))
            bp=model.update_belief(z,torch.tensor([prev_own],device=device),opp,
                                   torch.tensor([prev_known],dtype=torch.bool,device=device),
                                   torch.tensor([dt],dtype=z.dtype,device=device),h)
            h=bp.hidden
            mask,_=_mask_from_indices(tr.legal_action_indices); mask=mask.to(device)
            logits,value=model.head(z,h,mask.unsqueeze(0)); a=int(logits[0].argmax())
            target=encode_action(tr.action); total+=1; correct+=int(a==target); illegal+=int(not bool(mask[a])); value_sum+=float(value[0])
            prev_own=target; prev_opp=tr.opponent_action; prev_known=tr.opponent_action_known; dt=float(tr.next_state.t_s-tr.state.t_s)
    if total==0: raise ValueError('no recurrent evaluation decisions')
    return RecurrentEval(total,correct/total,illegal/total,value_sum/total)
