from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TrainingReadinessV4:
    regression_tests_pass: bool=False
    simulator_contract_pass: bool=False
    complete_card_vocab: bool=False
    complete_entity_vocab: bool=False
    runtime_contract_pinned: bool=False
    recurrent_bc_smoke_pass: bool=False
    onpolicy_ppo_smoke_pass: bool=False
    paired_ab_baseline_ready: bool=False
    hidden_test_league_ready: bool=False
    reward_guard_enabled: bool=False
    checkpoint_restore_tested: bool=False
    long_unroll_stress_pass: bool=False

    def blockers(self)->list[str]:
        names={
            'regression_tests_pass':'regression test suite not green',
            'simulator_contract_pass':'simulator contract/parity not proven',
            'complete_card_vocab':'card vocabulary incomplete',
            'complete_entity_vocab':'entity vocabulary incomplete',
            'runtime_contract_pinned':'runtime/checkpoint contract not pinned',
            'recurrent_bc_smoke_pass':'recurrent BC smoke missing',
            'onpolicy_ppo_smoke_pass':'on-policy PPO smoke missing',
            'paired_ab_baseline_ready':'paired A/B baseline not ready',
            'hidden_test_league_ready':'hidden test league not ready',
            'reward_guard_enabled':'dense reward guard disabled',
            'checkpoint_restore_tested':'checkpoint+optimizer restore untested',
            'long_unroll_stress_pass':'long recurrent unroll stress missing',
        }
        return [msg for field,msg in names.items() if not getattr(self,field)]
    @property
    def ready(self)->bool:return not self.blockers()
    def assert_ready(self):
        b=self.blockers()
        if b:raise RuntimeError('v4 paid training blocked: '+'; '.join(b))
