from __future__ import annotations

from .contracts import ActionV2

GRID_W = 18
GRID_H = 32
NUM_TILES = GRID_W * GRID_H
NUM_CARD_ACTIONS = 1 + 4 * NUM_TILES       # pass + 2304 placements = 2305
NUM_ABILITY_ACTIONS = 16
ABILITY_BASE = NUM_CARD_ACTIONS
NUM_ACTIONS = NUM_CARD_ACTIONS + NUM_ABILITY_ACTIONS  # 2321


def encode_action(a: ActionV2) -> int:
    a.validate()
    if a.is_pass:
        return 0
    if a.is_ability:
        return ABILITY_BASE + int(a.ability_slot)
    gx = min(GRID_W - 1, int(a.x * GRID_W))
    gy = min(GRID_H - 1, int(a.y * GRID_H))
    tile = gy * GRID_W + gx
    return 1 + int(a.slot) * NUM_TILES + tile


def decode_action(index: int) -> ActionV2:
    if index == 0:
        return ActionV2.pass_action()
    if not 0 <= index < NUM_ACTIONS:
        raise ValueError(index)
    if index >= ABILITY_BASE:
        return ActionV2.activate_ability(index - ABILITY_BASE)
    z = index - 1
    slot, tile = divmod(z, NUM_TILES)
    gy, gx = divmod(tile, GRID_W)
    return ActionV2.play_card(slot, (gx + 0.5) / GRID_W, (gy + 0.5) / GRID_H)


def tile_xy(index: int) -> tuple[int, int]:
    a = decode_action(index)
    if not a.is_play_card:
        raise ValueError('only play_card actions have a tile')
    gx = min(GRID_W - 1, int(a.x * GRID_W))
    gy = min(GRID_H - 1, int(a.y * GRID_H))
    return gx, gy
