from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Iterable


@dataclass(frozen=True)
class SliceMetric:
    name:str
    games:int
    wins:float
    catastrophic_blunders:int=0
    belief_abs_error_sum:float=0.0
    planner_gain_sum:float=0.0

    @property
    def win_rate(self)->float:return self.wins/self.games if self.games else float('nan')
    @property
    def catastrophic_rate(self)->float:return self.catastrophic_blunders/self.games if self.games else float('nan')
    @property
    def belief_mae(self)->float:return self.belief_abs_error_sum/self.games if self.games else float('nan')
    @property
    def planner_gain(self)->float:return self.planner_gain_sum/self.games if self.games else float('nan')


def wilson_interval(wins:float,games:int,z:float=1.96)->tuple[float,float]:
    if games<=0:return (float('nan'),float('nan'))
    p=float(wins)/games; d=1+z*z/games
    c=(p+z*z/(2*games))/d
    h=z*math.sqrt((p*(1-p)+z*z/(4*games))/games)/d
    return max(0.,c-h),min(1.,c+h)


@dataclass(frozen=True)
class RobustEvalSummary:
    overall_games:int
    overall_win_rate:float
    overall_ci_low:float
    overall_ci_high:float
    worst_slice:str
    worst_slice_win_rate:float
    catastrophic_rate:float
    slices:tuple[SliceMetric,...]


def summarize_slices(rows:Iterable[SliceMetric])->RobustEvalSummary:
    xs=tuple(rows)
    if not xs or any(x.games<=0 for x in xs):raise ValueError('every eval slice needs games')
    games=sum(x.games for x in xs); wins=sum(x.wins for x in xs)
    lo,hi=wilson_interval(wins,games); worst=min(xs,key=lambda x:x.win_rate)
    catastrophes=sum(x.catastrophic_blunders for x in xs)
    return RobustEvalSummary(games,wins/games,lo,hi,worst.name,worst.win_rate,catastrophes/games,xs)


def robust_promotion_gate(candidate:RobustEvalSummary,baseline:RobustEvalSummary,*,
                          min_overall_delta:float=.01,max_worst_slice_regression:float=.03,
                          max_catastrophic_regression:float=.005,require_ci_noninferior:bool=True)->tuple[bool,list[str]]:
    blockers=[]
    if candidate.overall_win_rate-baseline.overall_win_rate<min_overall_delta:blockers.append('overall improvement below threshold')
    base_by={x.name:x for x in baseline.slices}
    for x in candidate.slices:
        if x.name in base_by and x.win_rate<base_by[x.name].win_rate-max_worst_slice_regression:
            blockers.append(f'slice regression: {x.name}')
    if candidate.catastrophic_rate>baseline.catastrophic_rate+max_catastrophic_regression:blockers.append('catastrophic blunder regression')
    if require_ci_noninferior and candidate.overall_ci_low<baseline.overall_ci_low-.02:blockers.append('confidence interval degraded')
    return not blockers,blockers
