from __future__ import annotations

from dataclasses import dataclass
import importlib
import math
import random
from typing import Callable

from crgod.contracts import PlayerObservationV1
from crgod.sim_protocol import TrainingSimulator, audit_training_simulator


@dataclass(frozen=True)
class SimulatorAuditReportV4:
    simulator_id: str
    episodes: int
    steps: int
    terminals: int
    min_elapsed_s: float
    max_elapsed_s: float
    max_clock_error_s: float


def load_simulator_factory(spec: str) -> Callable[[], TrainingSimulator]:
    """Load ``package.module:factory`` without coupling the trainer to a simulator."""
    if ':' not in spec:
        raise ValueError('simulator factory must be module.path:callable')
    module_name, attr = spec.split(':', 1)
    if not module_name or not attr:
        raise ValueError('simulator factory must be module.path:callable')
    mod = importlib.import_module(module_name)
    fn = getattr(mod, attr, None)
    if not callable(fn):
        raise TypeError(f'{spec} is not callable')
    return fn


def _finite_observation(obs: PlayerObservationV1) -> None:
    scalars=[obs.t_s, obs.own_elixir]
    for t in (*obs.own_towers,*obs.opponent_towers):
        scalars += [t.hp,t.x,t.y]
        if t.max_hp is not None: scalars.append(t.max_hp)
    for e in obs.entities:
        scalars += [e.x,e.y,e.vx,e.vy,e.age_s,e.confidence]
        if e.hp is not None: scalars.append(e.hp)
        if e.max_hp is not None: scalars.append(e.max_hp)
    if not all(math.isfinite(float(x)) for x in scalars):
        raise ValueError('non-finite number in policy observation')


def stress_audit_simulator(sim: TrainingSimulator, *, episodes: int = 4,
                           max_steps_per_episode: int = 2000,
                           seed: int = 0) -> SimulatorAuditReportV4:
    """Fail-closed black-box audit of a simulator's training boundary.

    This cannot prove game-mechanic correctness.  It *does* catch contract bugs
    that otherwise poison training silently: illegal/empty masks, non-monotonic
    clocks, mismatched elapsed time, NaNs, non-terminating episodes, and outcome
    range errors.
    """
    if episodes <= 0 or max_steps_per_episode <= 0:
        raise ValueError('episodes/max_steps_per_episode must be positive')
    rng=random.Random(seed); total=terminals=0; min_dt=float('inf'); max_dt=0.0; max_err=0.0
    simulator_id=None
    for ep in range(episodes):
        frame=audit_training_simulator(sim,seed=seed+ep)
        simulator_id=str(sim.simulator_id) if simulator_id is None else simulator_id
        if str(sim.simulator_id)!=simulator_id:
            raise RuntimeError('simulator_id changed across resets')
        _finite_observation(frame.seat_a.observation); _finite_observation(frame.seat_b.observation)
        prev_t=float(frame.t_s)
        ended=False
        for _ in range(max_steps_per_episode):
            ia=rng.choice(frame.seat_a.legal_action_indices)
            ib=rng.choice(frame.seat_b.legal_action_indices)
            tr=sim.step(int(ia),int(ib)); tr.validate(); total+=1
            if not (math.isfinite(float(tr.reward_a)) and math.isfinite(float(tr.reward_b))):
                raise ValueError('non-finite simulator reward')
            _finite_observation(tr.next_frame.seat_a.observation); _finite_observation(tr.next_frame.seat_b.observation)
            dt=float(tr.elapsed_s); min_dt=min(min_dt,dt); max_dt=max(max_dt,dt)
            clock_delta=float(tr.next_frame.t_s)-prev_t
            if clock_delta <= 0:
                raise ValueError('simulator clock must advance every decision')
            err=abs(clock_delta-dt); max_err=max(max_err,err)
            # elapsed_s is the sole discount-time source; the simulator clock
            # must therefore agree tightly enough not to teach inconsistent horizons.
            if err > max(1e-6,1e-4*max(abs(clock_delta),abs(dt),1.0)):
                raise ValueError(f'elapsed_s/clock mismatch: delta={clock_delta} elapsed={dt}')
            if tr.done:
                terminals+=1; ended=True
                if tr.outcome_a is None:
                    raise ValueError('terminal step must provide outcome_a for objective evaluation')
                break
            frame=tr.next_frame; prev_t=float(frame.t_s)
        if not ended:
            raise RuntimeError(f'episode {ep} did not terminate within {max_steps_per_episode} steps')
    return SimulatorAuditReportV4(simulator_id or '',episodes,total,terminals,min_dt,max_dt,max_err)
