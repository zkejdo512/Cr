from __future__ import annotations
from dataclasses import dataclass, field
from typing import Literal
import random

Role = Literal['main', 'historical', 'exploiter']


@dataclass
class LeagueMember:
    member_id: str
    path: str
    role: Role
    generation: int = 0
    elo: float = 1000.0
    frozen: bool = True


@dataclass
class _Record:
    wins: float = 0.0
    games: float = 0.0


@dataclass
class PayoffTable:
    records: dict[tuple[str, str], _Record] = field(default_factory=dict)
    prior_games: float = 2.0

    def record(self, a: str, b: str, score_a: float):
        if a == b:
            return
        ra = self.records.setdefault((a, b), _Record())
        rb = self.records.setdefault((b, a), _Record())
        ra.wins += float(score_a); ra.games += 1.0
        rb.wins += float(1.0 - score_a); rb.games += 1.0

    def win_rate(self, a: str, b: str) -> float:
        r = self.records.get((a, b), _Record())
        return (r.wins + .5 * self.prior_games) / (r.games + self.prior_games)


@dataclass
class PFSPLeague:
    """Payoff-aware league with historical policies and exploiters.

    This is inspired by PFSP-style sampling; it is intentionally small and
    auditable rather than claiming to reproduce AlphaStar's full league stack.
    """
    members: dict[str, LeagueMember] = field(default_factory=dict)
    payoff: PayoffTable = field(default_factory=PayoffTable)
    exploiter_multiplier: float = 1.5

    def add(self, m: LeagueMember):
        if m.member_id in self.members:
            raise ValueError(f'duplicate league member {m.member_id}')
        self.members[m.member_id] = m

    def record(self, a: str, b: str, score_a: float):
        self.payoff.record(a, b, score_a)

    def sample_opponent(self, current_id: str, rng: random.Random | None = None) -> LeagueMember:
        rng = rng or random
        if current_id not in self.members:
            raise KeyError(current_id)
        candidates = [m for k, m in self.members.items() if k != current_id]
        if not candidates:
            raise RuntimeError('league needs at least two members')
        weights = []
        for m in candidates:
            p_win = self.payoff.win_rate(current_id, m.member_id)
            # Prioritize policies that currently beat or challenge the main.
            w = max(1e-3, (1.0 - p_win) ** 2)
            if m.role == 'exploiter':
                w *= self.exploiter_multiplier
            weights.append(w)
        return rng.choices(candidates, weights=weights, k=1)[0]

    def worst_matchup(self, current_id: str) -> tuple[str, float]:
        candidates = [m for k, m in self.members.items() if k != current_id]
        if not candidates:
            raise RuntimeError('no opponents')
        pairs = [(m.member_id, self.payoff.win_rate(current_id, m.member_id)) for m in candidates]
        return min(pairs, key=lambda x: x[1])
