from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence
import random
import torch

from .action_codec import encode_action, NUM_ACTIONS
from .contracts import TransitionV1, ObservedOpponentActionV1, TrueBattleStateV1
from .data import _mask_from_indices, discounted_return_targets
from .opponent_codec import OpponentActionBatch, encode_observed_action
from .training.bc_v2 import RecurrentBCBatch


@dataclass(frozen=True)
class Episode:
    transitions: tuple[TransitionV1, ...]
    episode_id: str = ''
    # Optional training-only state aligned to each decision transition.  This is
    # never tensorized as a policy observation; it only supplies belief labels.
    privileged_states: tuple[TrueBattleStateV1, ...] | None = None

    def validate(self) -> None:
        if not self.transitions:
            raise ValueError('episode is empty')
        if self.privileged_states is not None:
            if len(self.privileged_states) != len(self.transitions):
                raise ValueError('privileged state count must match transitions')
            for i,(ps,tr) in enumerate(zip(self.privileged_states,self.transitions)):
                if abs(float(ps.t_s)-float(tr.state.t_s))>1e-5:
                    raise ValueError(f'privileged/state time mismatch at step {i}')
        last_t = None
        for i, tr in enumerate(self.transitions):
            if last_t is not None and tr.state.t_s <= last_t:
                raise ValueError(f'non-monotonic state time at step {i}')
            if tr.next_state.t_s <= tr.state.t_s:
                raise ValueError(f'non-positive transition dt at step {i}')
            if i < len(self.transitions)-1 and tr.done:
                raise ValueError(f'done=True before final transition at step {i}')
            if i and abs(tr.state.t_s - self.transitions[i-1].next_state.t_s) > 1e-5:
                raise ValueError(f'state/next_state discontinuity at step {i}')
            last_t = tr.state.t_s
        if not self.transitions[-1].done:
            raise ValueError('episode must terminate explicitly')


def split_episodes(transitions: Sequence[TransitionV1]) -> list[Episode]:
    """Split a chronological stream without ever crossing terminal boundaries."""
    out=[]; cur=[]; eid=0
    for tr in transitions:
        cur.append(tr)
        if tr.done:
            ep=Episode(tuple(cur),str(eid)); ep.validate(); out.append(ep); cur=[]; eid+=1
    if cur:
        raise ValueError('transition stream ends without done=True; refusing ambiguous sequence')
    return out


def _prev_features(ep: Episode, idx: int, tensorizer):
    """Information available *before* deciding action idx.

    This is deliberately shifted by one transition. Feeding tr[idx].opponent_action
    here would leak a simultaneous/future action into the current decision.
    """
    if idx == 0:
        return 0, OpponentActionBatch.pass_batch(1), False, 0.0, True
    prev=ep.transitions[idx-1]
    cur=ep.transitions[idx]
    kind,card,tile=encode_observed_action(prev.opponent_action,tensorizer.vocab)
    opp=OpponentActionBatch(torch.tensor([kind],dtype=torch.long),
                            torch.tensor([card],dtype=torch.long),
                            torch.tensor([tile],dtype=torch.long))
    dt=float(cur.state.t_s-prev.state.t_s)
    if dt <= 0:
        raise ValueError(f'non-positive decision dt at step {idx}: {dt}')
    return encode_action(prev.action),opp,bool(prev.opponent_action_known),dt,False


def build_recurrent_bc_batch(episodes: Sequence[Episode], tensorizer,
                             batch_size: int, train_steps: int,
                             burn_in: int = 8,
                             rng: random.Random | None = None) -> RecurrentBCBatch:
    """Sample fixed-length recurrent expert windows with burn-in and no future leakage.

    The first `burn_in` decisions reconstruct memory but do not contribute to the
    loss. Current-step opponent actions are *targets/history for the next step*,
    never inputs to the action being predicted now.
    """
    if train_steps <= 0 or burn_in < 0 or batch_size <= 0:
        raise ValueError('batch_size/train_steps must be positive and burn_in non-negative')
    rng=rng or random.Random()
    total=burn_in+train_steps
    valid=[]
    for ep in episodes:
        ep.validate()
        if len(ep.transitions) >= total:
            valid.append(ep)
    if not valid:
        raise ValueError(f'no episode has at least burn_in+train_steps={total} transitions')

    windows=[]
    for _ in range(batch_size):
        ep=rng.choice(valid)
        start=rng.randint(0,len(ep.transitions)-total)
        windows.append((ep,start))

    states=[]; prev_own=[]; prev_opp=[]; prev_known=[]; dts=[]; masks=[]; targets=[]; returns=[]; resets=[]
    loss_mask=torch.zeros(total,batch_size,dtype=torch.bool)
    loss_mask[burn_in:]=True
    ret_cache={id(ep):discounted_return_targets(ep.transitions) for ep,_ in windows}
    for t in range(total):
        step_states=[]; own_row=[]; opp_kind=[]; opp_card=[]; opp_tile=[]; known_row=[]; dt_row=[]; mask_row=[]; tgt_row=[]; ret_row=[]; reset_row=[]
        for b,(ep,start) in enumerate(windows):
            idx=start+t; tr=ep.transitions[idx]
            po,oa,ok,dt,reset=_prev_features(ep,idx,tensorizer)
            step_states.append(tr.state); own_row.append(po); opp_kind.append(int(oa.kind[0])); opp_card.append(int(oa.card_token[0])); opp_tile.append(int(oa.tile[0])); known_row.append(ok); dt_row.append(dt)
            mask,_=_mask_from_indices(tr.legal_action_indices); mask_row.append(mask)
            target=encode_action(tr.action)
            if not bool(mask[target]): raise ValueError(f'expert action {target} illegal at episode step {idx}')
            tgt_row.append(target); ret_row.append(ret_cache[id(ep)][idx]); reset_row.append(reset)
        states.append(tensorizer.batch(step_states))
        prev_own.append(torch.tensor(own_row,dtype=torch.long))
        prev_opp.append(OpponentActionBatch(torch.tensor(opp_kind,dtype=torch.long),torch.tensor(opp_card,dtype=torch.long),torch.tensor(opp_tile,dtype=torch.long)))
        prev_known.append(torch.tensor(known_row,dtype=torch.bool)); dts.append(torch.tensor(dt_row,dtype=torch.float32)); masks.append(torch.stack(mask_row)); targets.append(torch.tensor(tgt_row,dtype=torch.long)); returns.append(torch.tensor(ret_row,dtype=torch.float32)); resets.append(torch.tensor(reset_row,dtype=torch.bool))

    belief_targets=None
    if all(ep.privileged_states is not None for ep,_ in windows):
        from .training.belief import targets_from_true_states
        belief_targets=[]
        for t in range(total):
            true_states=[ep.privileged_states[start+t] for ep,start in windows]
            belief_targets.append(targets_from_true_states(true_states,tensorizer.vocab,side='self'))

    return RecurrentBCBatch(
        states=states,
        prev_own_actions=torch.stack(prev_own),
        prev_opp_actions=prev_opp,
        prev_opp_known=torch.stack(prev_known),
        dt_s=torch.stack(dts),
        legal_masks=torch.stack(masks),
        expert_actions=torch.stack(targets),
        return_targets=torch.stack(returns),
        belief_targets=belief_targets,
        reset_before=torch.stack(resets),
        loss_mask=loss_mask,
    )
