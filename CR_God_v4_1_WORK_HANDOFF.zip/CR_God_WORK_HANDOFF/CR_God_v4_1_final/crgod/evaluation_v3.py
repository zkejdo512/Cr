from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable

from crgod.contracts import ObservedOpponentActionV1
from crgod.training.selfplay_v3 import RecurrentPolicyActor
from crgod.evaluation_v2 import PairedOutcome, paired_ab_gate, ABGateResult


@dataclass(frozen=True)
class EvaluationMatch:
    candidate_score: float
    steps: int
    seed: int
    candidate_seat: str


def run_eval_match(sim, actor_a:RecurrentPolicyActor, actor_b:RecurrentPolicyActor, *, seed:int, max_steps:int=2000)->float:
    """Deterministic policy evaluation on one simulator instance."""
    frame=sim.reset(seed=seed); frame.validate(); actor_a.reset(); actor_b.reset()
    prev_own=[0,0]; prev_opp=[ObservedOpponentActionV1.pass_action(),ObservedOpponentActionV1.pass_action()]
    known=[False,False]; dt=[0.,0.]
    for _ in range(max_steps):
        ia,*_=actor_a.act(frame.seat_a.observation,frame.seat_a.legal_action_indices,prev_own_action=prev_own[0],prev_opp_action=prev_opp[0],prev_opp_known=known[0],dt_s=dt[0],deterministic=True)
        ib,*_=actor_b.act(frame.seat_b.observation,frame.seat_b.legal_action_indices,prev_own_action=prev_own[1],prev_opp_action=prev_opp[1],prev_opp_known=known[1],dt_s=dt[1],deterministic=True)
        tr=sim.step(ia,ib); tr.validate()
        if tr.done:
            if tr.outcome_a is None:
                raise RuntimeError('terminal evaluation requires explicit outcome_a; shaped reward may not define wins')
            return float(tr.outcome_a)
        frame=tr.next_frame; prev_own=[ia,ib]; prev_opp=[tr.action_b_observed_by_a,tr.action_a_observed_by_b]
        known=[tr.action_b_known_to_a,tr.action_a_known_to_b]; dt=[tr.elapsed_s,tr.elapsed_s]
    raise RuntimeError(f'eval match did not terminate within {max_steps} decisions')


def paired_seat_swap_eval(sim_factory:Callable[[],object],candidate_factory:Callable[[],RecurrentPolicyActor],baseline_factory:Callable[[],RecurrentPolicyActor],
                          seeds:Iterable[int],*,archetype:str='unknown',max_steps:int=2000)->list[PairedOutcome]:
    """Pair every seed with a seat swap to cancel fixed-seat simulator bias."""
    rows=[]
    for seed in seeds:
        s1=run_eval_match(sim_factory(),candidate_factory(),baseline_factory(),seed=int(seed),max_steps=max_steps)
        # second match: baseline is seat A, candidate seat B; convert A outcome to candidate score.
        a2=run_eval_match(sim_factory(),baseline_factory(),candidate_factory(),seed=int(seed),max_steps=max_steps)
        s2=1.0-a2 if a2 in (0.0,1.0) else .5
        cand=(s1+s2)/2.0; base=1.0-cand
        rows.append(PairedOutcome(base,cand,int(seed),archetype))
    return rows


def evaluate_candidate_gate(sim_factory,candidate_factory,baseline_factory,seeds,**gate_kwargs)->ABGateResult:
    rows=paired_seat_swap_eval(sim_factory,candidate_factory,baseline_factory,seeds)
    return paired_ab_gate(rows,**gate_kwargs)
