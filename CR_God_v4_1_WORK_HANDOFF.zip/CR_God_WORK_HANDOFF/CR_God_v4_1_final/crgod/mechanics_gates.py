from __future__ import annotations
from dataclasses import dataclass, asdict
import json
from pathlib import Path


@dataclass(frozen=True)
class MechanicsThresholds:
    # Engineering gates, not claims about official tolerances. Tighten after
    # collecting enough real-match calibration data.
    max_spell_timing_mae_ms: float = 60.0
    max_path_position_mae_tiles: float = 0.35
    max_collision_delay_mae_ms: float = 120.0


@dataclass(frozen=True)
class MechanicsCalibrationReport:
    king_activation_verified: bool = False
    pocket_deploy_verified: bool = False
    tiebreak_absolute_hp_verified: bool = False
    spell_timing_samples: int = 0
    spell_timing_mae_ms: float | None = None
    path_samples: int = 0
    path_position_mae_tiles: float | None = None
    collision_samples: int = 0
    collision_delay_mae_ms: float | None = None

    def blockers(self, thresholds: MechanicsThresholds = MechanicsThresholds()) -> list[str]:
        out: list[str] = []
        if not self.king_activation_verified:
            out.append('king activation parity not verified')
        if not self.pocket_deploy_verified:
            out.append('post-princess-tower deployment parity not verified')
        if not self.tiebreak_absolute_hp_verified:
            out.append('tiebreak absolute-HP rule not verified')
        if self.spell_timing_samples <= 0 or self.spell_timing_mae_ms is None:
            out.append('spell timing has no real-match calibration samples')
        elif self.spell_timing_mae_ms > thresholds.max_spell_timing_mae_ms:
            out.append(f'spell timing MAE {self.spell_timing_mae_ms:.1f}ms exceeds gate')
        if self.path_samples <= 0 or self.path_position_mae_tiles is None:
            out.append('pathing has no real-match calibration samples')
        elif self.path_position_mae_tiles > thresholds.max_path_position_mae_tiles:
            out.append(f'path position MAE {self.path_position_mae_tiles:.3f} tiles exceeds gate')
        if self.collision_samples <= 0 or self.collision_delay_mae_ms is None:
            out.append('collision/pull has no real-match calibration samples')
        elif self.collision_delay_mae_ms > thresholds.max_collision_delay_mae_ms:
            out.append(f'collision delay MAE {self.collision_delay_mae_ms:.1f}ms exceeds gate')
        return out

    def assert_paid_training_ready(self, thresholds: MechanicsThresholds = MechanicsThresholds()) -> None:
        blockers = self.blockers(thresholds)
        if blockers:
            raise RuntimeError('paid training blocked:\n- ' + '\n- '.join(blockers))

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> 'MechanicsCalibrationReport':
        allowed=set(cls.__dataclass_fields__)
        unknown=set(d)-allowed
        if unknown:
            raise ValueError(f'unknown mechanics calibration fields: {sorted(unknown)}')
        return cls(**d)

    @classmethod
    def load_json(cls, path: str | Path) -> 'MechanicsCalibrationReport':
        return cls.from_dict(json.loads(Path(path).read_text(encoding='utf8')))

    def save_json(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(self.to_dict(), indent=2, sort_keys=True), encoding='utf8')
