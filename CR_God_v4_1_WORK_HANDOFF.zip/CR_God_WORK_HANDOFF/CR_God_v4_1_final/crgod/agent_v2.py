from __future__ import annotations
from dataclasses import dataclass
import torch
from crgod.action_codec import decode_action
from crgod.contracts import ActionV2, ObservedOpponentActionV1, PlayerObservationV1
from crgod.opponent_codec import OpponentActionBatch, PASS_TILE, encode_observed_action
from crgod.planning import FastSlowPlanner, DecisionTrace, RolloutEstimate


@dataclass
class AgentDecision:
    action: ActionV2
    action_index: int
    value: float
    opponent_elixir_belief: float
    trace: DecisionTrace


class CRGodV2Agent:
    """Stateful inference wrapper. Keeps belief memory across decisions."""
    def __init__(self, model, tensorizer, planner: FastSlowPlanner | None = None,
                 device: str = 'cpu'):
        self.model=model.to(device).eval(); self.tensorizer=tensorizer
        self.planner=planner or FastSlowPlanner(); self.device=torch.device(device)
        self.reset()

    def reset(self):
        self.hidden=None
        self.prev_own_action=0

    @torch.no_grad()
    def decide(self, obs: PlayerObservationV1, legal_mask: torch.Tensor,
               observed_opponent_action: ObservedOpponentActionV1 | None,
               opponent_action_known: bool, dt_s: float,
               rollout=None, force_slow: bool=False) -> AgentDecision:
        if not isinstance(obs, PlayerObservationV1):
            raise TypeError('CRGodV2Agent accepts PlayerObservationV1 only')
        tb=self.tensorizer.one(obs).to(self.device)
        z=self.model.encoder(tb)
        if self.hidden is None:
            self.hidden=self.model.initial_belief(1,self.device,z.dtype)
        if observed_opponent_action is None:
            opp=OpponentActionBatch.pass_batch(1, self.device)
        else:
            kind,card,tile=encode_observed_action(observed_opponent_action,self.tensorizer.vocab)
            opp=OpponentActionBatch(torch.tensor([kind],dtype=torch.long,device=self.device),
                                    torch.tensor([card],dtype=torch.long,device=self.device),
                                    torch.tensor([tile],dtype=torch.long,device=self.device))
        own=torch.tensor([self.prev_own_action],dtype=torch.long,device=self.device)
        known=torch.tensor([opponent_action_known],dtype=torch.bool,device=self.device)
        dt=torch.tensor([float(dt_s)],dtype=z.dtype,device=self.device)
        bp=self.model.update_belief(z,own,opp,known,dt,self.hidden)
        self.hidden=bp.hidden
        lm=legal_mask.to(self.device).bool()
        if lm.ndim==1: lm=lm.unsqueeze(0)
        logits,value=self.model.head(z,self.hidden,lm)
        trace=self.planner.decide(logits[0],lm[0],rollout,force_slow)
        self.prev_own_action=trace.chosen_action
        return AgentDecision(decode_action(trace.chosen_action),trace.chosen_action,float(value[0]),
                             float(bp.opponent_elixir[0]),trace)
