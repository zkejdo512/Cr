#!/usr/bin/env python3
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import copy
import random
import torch

from crgod.envs.toy_joint import ToyJointSimulator,ToyJointConfig
from crgod.sim_protocol import audit_training_simulator
from crgod.vocab import CardVocabulary
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.training.selfplay_v3 import RecurrentPolicyActor,collect_joint_unroll
from crgod.training.ppo_from_unroll import actor_unroll_to_ppo_batch
from crgod.training.ppo_trainer import RecurrentPPOTrainer,PPOTrainerConfig
from crgod.training.vtrace import recurrent_vtrace_step
from crgod.training.async_buffer import FreshUnrollBuffer,VersionedItem
from crgod.training.league_manager_v3 import LeagueManagerV3,SnapshotRule
from crgod.league_v2 import LeagueMember


def main():
    torch.manual_seed(1); random.seed(1)
    sim=ToyJointSimulator(ToyJointConfig(horizon=10)); audit_training_simulator(sim)
    vocab=CardVocabulary.from_card_ids(list(range(10,15))+list(range(20,25)))
    ten=BattleTensorizer(vocab,max_entities=8,max_events=16)
    net=CRGodV2Net(vocab.size,latent_dim=64,belief_dim=48,entity_vocab_size=vocab.size)
    opponent=copy.deepcopy(net)
    a=RecurrentPolicyActor(net,ten,actor_id='main',policy_version=0); b=RecurrentPolicyActor(opponent,ten,actor_id='opp',policy_version=0)
    joint=collect_joint_unroll(sim,a,b,unroll_length=8,seed=4)
    ppo_batch=actor_unroll_to_ppo_batch(joint.seat_a,net,ten,expected_policy_version=0)
    opt=torch.optim.Adam(net.parameters(),lr=1e-4)
    pm=RecurrentPPOTrainer(net,opt,PPOTrainerConfig(epochs=2,target_kl=.2,hard_stop_kl=.5)).update([ppo_batch],rng=random.Random(0))
    # Simulate one stale actor version and show V-trace can safely consume it.
    old=copy.deepcopy(net); oa=RecurrentPolicyActor(old,ten,actor_id='old',policy_version=0); ob=RecurrentPolicyActor(copy.deepcopy(old),ten,actor_id='old-opp',policy_version=0)
    stale=collect_joint_unroll(sim,oa,ob,unroll_length=6,seed=8).seat_a
    vm=recurrent_vtrace_step(net,stale,ten,opt)
    buf=FreshUnrollBuffer(capacity=8,max_policy_lag=2); assert buf.push(VersionedItem(stale,0,'old'),1)
    league=LeagueManagerV3(LeagueMember('main','main.pt','main'),snapshot_rule=SnapshotRule(max_steps_between_snapshots=1))
    league.progress.learner_steps=1; league.register_snapshot('hist.pt')
    print(f'PPO updates={pm.updates} mean_kl={pm.mean_kl:.6f}')
    print(f'VTRACE rho={vm.mean_rho:.4f} loss={vm.loss:.4f}')
    print(f'buffer={len(buf)} league_members={len(league.league.members)}')
    print('smoke_v3_training: OK')

if __name__=='__main__':main()
