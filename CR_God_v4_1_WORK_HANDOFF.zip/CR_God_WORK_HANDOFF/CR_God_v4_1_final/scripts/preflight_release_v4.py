#!/usr/bin/env python3
from __future__ import annotations
import argparse, copy, json, math, sys
from pathlib import Path
import torch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from crgod.checkpointing_v4 import assert_checkpoint_compatible_v4
from crgod.models.crgod_v4 import CRGodV4Net
from crgod.sim_audit_v4 import load_simulator_factory,stress_audit_simulator
from crgod.supervisor import AtomicCheckpointStore
from crgod.tensorizer import BattleTensorizer
from crgod.training.ppo_from_unroll import actor_unroll_to_ppo_batch
from crgod.training.ppo_v2 import recurrent_ppo_step
from crgod.training.selfplay_v3 import RecurrentPolicyActor,SelfPlaySession
from crgod.vocab import CardVocabulary


def main():
    ap=argparse.ArgumentParser(description='Frozen CR-God v4 release preflight before any paid training')
    ap.add_argument('--sim-factory',required=True)
    ap.add_argument('--run-dir',required=True)
    ap.add_argument('--checkpoint-name',default='best')
    ap.add_argument('--audit-episodes',type=int,default=2)
    ap.add_argument('--unroll-length',type=int,default=32)
    ap.add_argument('--max-steps',type=int,default=2000)
    ap.add_argument('--seed',type=int,default=12345)
    ap.add_argument('--device',default='cpu')
    args=ap.parse_args()
    if min(args.audit_episodes,args.unroll_length,args.max_steps)<=0: raise ValueError('counts must be positive')
    device=torch.device(args.device); sf=load_simulator_factory(args.sim_factory)
    audit=stress_audit_simulator(sf(),episodes=args.audit_episodes,max_steps_per_episode=args.max_steps,seed=args.seed)
    run=Path(args.run_dir).resolve();cv=CardVocabulary.load(run/'card_vocab.json');ev=CardVocabulary.load(run/'entity_vocab.json')
    ten=BattleTensorizer(cv,entity_vocab=ev)
    model=CRGodV4Net(cv.size,entity_vocab_size=ev.size).to(device)
    meta=AtomicCheckpointStore(run).load(args.checkpoint_name,model,map_location=device)
    assert_checkpoint_compatible_v4(meta,cv,ev,audit.simulator_id)
    # Collect from frozen snapshots.
    a=RecurrentPolicyActor(model,ten,device=device,actor_id='preflight-a',policy_version=0)
    b=RecurrentPolicyActor(model,ten,device=device,actor_id='preflight-b',policy_version=0)
    sess=SelfPlaySession(sf(),a,b);sess.reset(seed=args.seed+999)
    joint=sess.collect(unroll_length=args.unroll_length,learner_step=0,burn_in_length=0)
    batch=actor_unroll_to_ppo_batch(joint.seat_a,model,ten,device=device,expected_policy_version=0)
    tensors=(batch.old_logprob,batch.advantages,batch.returns,batch.old_values)
    if any(x is None or not bool(torch.isfinite(x).all()) for x in tensors): raise RuntimeError('non-finite PPO preflight tensor')
    # One update on a disposable copy catches device/autograd/optimizer integration bugs.
    probe=copy.deepcopy(model).to(device);opt=torch.optim.AdamW(probe.parameters(),lr=1e-6)
    m=recurrent_ppo_step(probe,batch.to(device),opt,max_grad_norm=1.0)
    vals=(m.loss,m.policy_loss,m.value_loss,m.entropy,m.approx_kl,m.clip_fraction,m.grad_norm)
    if not all(math.isfinite(float(x)) for x in vals): raise RuntimeError('non-finite dry PPO update')
    print(json.dumps({'status':'PASS','simulator_audit':audit.__dict__,'checkpoint':args.checkpoint_name,
                      'unroll_steps':len(joint.seat_a.steps),'dry_ppo_metrics':m.__dict__},indent=2))

if __name__=='__main__':main()
