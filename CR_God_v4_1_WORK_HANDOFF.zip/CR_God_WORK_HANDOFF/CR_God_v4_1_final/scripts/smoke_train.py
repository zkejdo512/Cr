#!/usr/bin/env python3
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
import argparse,copy,random,torch
from crgod.data import build_card_vocab,collect_toy_expert,discounted_return_targets,sample_transition_batch
from crgod.evaluation import evaluate_bc
from crgod.models.crgod import CRGodNet
from crgod.models.opponent import OpponentModel
from crgod.models.world_ensemble import WorldModelEnsemble
from crgod.opponent_codec import OpponentActionBatch,encode_observed_action
from crgod.tensorizer import BattleTensorizer
from crgod.training.bc import bc_step
from crgod.training.opponent import opponent_step
from crgod.training.world import world_ensemble_step
from crgod.training.imagination import imagination_actor_critic_step

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--device',default='cpu'); ap.add_argument('--bc-steps',type=int,default=100); ap.add_argument('--opponent-steps',type=int,default=20); ap.add_argument('--world-steps',type=int,default=80); ap.add_argument('--imagine-steps',type=int,default=10); a=ap.parse_args(); torch.manual_seed(0); random.seed(0); torch.set_num_threads(1); dev=torch.device(a.device)
    data=collect_toy_expert(40,0); H=60; train=data[:30*H]; val=data[30*H:]; vocab=build_card_vocab(data); ten=BattleTensorizer(vocab,16,16); tr=discounted_return_targets(train); vr=discounted_return_targets(val); net=CRGodNet(vocab.size).to(dev); world=WorldModelEnsemble(3,card_vocab_size=vocab.size).to(dev); opp=OpponentModel(vocab.size).to(dev)
    opt=torch.optim.AdamW(net.parameters(),lr=3e-4)
    for _ in range(a.bc_steps): b=sample_transition_batch(train,ten,48,return_targets=tr).to(dev); bm=bc_step(net,b.state,b.own_action,opt,b.legal_mask,b.return_target)
    before=evaluate_bc(net,val,ten,vr,dev); print(f'BC loss={bm.loss:.4f} holdout={before.accuracy:.3f} value_mae={before.value_mae:.4f}')
    seq=train[:8*H]
    with torch.no_grad(): z=net.encoder(ten.batch([x.state for x in seq]).to(dev))
    zs=z.view(8,H,-1).transpose(0,1).contiguous(); eo=[encode_observed_action(x.opponent_action,vocab) for x in seq]; targets=OpponentActionBatch(torch.tensor([x[0] for x in eo],device=dev).view(8,H).T.contiguous().long(),torch.tensor([x[1] for x in eo],device=dev).view(8,H).T.contiguous(),torch.tensor([x[2] for x in eo],device=dev).view(8,H).T.contiguous()); oo=torch.optim.AdamW(opp.parameters(),lr=3e-4)
    for _ in range(a.opponent_steps): ol,oa=opponent_step(opp,zs,targets,oo)
    print(f'OPP loss={ol:.4f} joint_acc={oa:.3f}')
    wo=torch.optim.AdamW(world.parameters(),lr=2e-4)
    for _ in range(a.world_steps): b=sample_transition_batch(train,ten,48).to(dev); wm=world_ensemble_step(net.encoder,world,b.state,b.next_state,b.own_action,b.opp_action,b.reward,b.done,b.dt_s,b.opp_action_known,b.next_legal_mask,b.next_legal_mask_known,wo)
    print(f'WORLD loss={wm.loss:.4f} latent={wm.latent:.4f} legal={wm.legal:.4f}')
    ref=copy.deepcopy(net.head).to(dev).eval(); [p.requires_grad_(False) for p in ref.parameters()]; po=torch.optim.AdamW(net.head.parameters(),lr=2e-5); b=sample_transition_batch(train,ten,24).to(dev)
    with torch.no_grad(): z=net.encoder(b.state)
    h=opp.initial(z.shape[0],dev)
    for _ in range(a.imagine_steps): im=imagination_actor_critic_step(net.head,world,opp,z,h,po,b.legal_mask,ref,horizon=6,dt_s=float(b.dt_s.median().item()))
    after=evaluate_bc(net,val,ten,vr,dev); print(f'IMAGINE KL={im.mean_kl_to_reference:.5f} unc={im.mean_uncertainty:.4f} holdout={after.accuracy:.3f} illegal={after.illegal_argmax_rate:.3f}')
    # Structural smoke: capability improvement belongs to paired A/B eval, not
    # this tiny stochastic toy run. Here we only fail on numerical/legality faults.
    vals=(bm.loss,before.accuracy,before.value_mae,ol,oa,wm.loss,wm.latent,wm.legal,im.mean_kl_to_reference,im.mean_uncertainty,after.accuracy,after.illegal_argmax_rate)
    if not all(torch.isfinite(torch.tensor(float(x))) for x in vals): raise RuntimeError('non-finite structural smoke metric')
    if after.illegal_argmax_rate>0: raise RuntimeError('policy selected illegal action in structural smoke')
    if after.accuracy+.05<before.accuracy: print('WARNING: toy skill regressed; capability must be judged by paired A/B gate, not smoke')
    print('smoke_train: OK')
if __name__=='__main__': main()
