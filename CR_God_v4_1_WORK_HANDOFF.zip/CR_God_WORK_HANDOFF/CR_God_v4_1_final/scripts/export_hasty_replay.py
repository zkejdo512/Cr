#!/usr/bin/env python3
from __future__ import annotations
import argparse,pathlib,sys,random
ROOT=pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from crgod.adapters.hasty import HastyEnvAdapter
from crgod.contracts import ActionV2
from crgod.sequence import Episode
from crgod.replay_io import save_jsonl

p=argparse.ArgumentParser(description='Export parity-checked Hasty simulator episodes to CR-God v2.1 JSONL')
p.add_argument('hasty_root'); p.add_argument('output'); p.add_argument('--episodes',type=int,default=4); p.add_argument('--seed',type=int,default=1000); p.add_argument('--opponent',default='brain',choices=['brain','meta','simple','mirror']); a=p.parse_args()
all_eps=[]; rng=random.Random(a.seed)
for ep_i in range(a.episodes):
    env=HastyEnvAdapter(a.hasty_root,seed=a.seed+ep_i,opponent=a.opponent); obs,mask,true=env.reset(a.seed+ep_i); trs=[]; done=False
    while not done:
        legal=[i for i,x in enumerate(mask) if x]
        # Data plumbing smoke only: random legal action, not a training teacher.
        idx=rng.choice(legal); tr=env.step(idx); trs.append(tr); mask=[i in set(tr.next_legal_action_indices or ()) for i in range(2321)]; done=tr.done
    all_eps.append(Episode(tuple(trs),f'hasty-{a.seed+ep_i}'))
save_jsonl(all_eps,a.output)
print(f'wrote {len(all_eps)} episodes / {sum(len(x.transitions) for x in all_eps)} transitions to {a.output}')
