#!/usr/bin/env python3
from __future__ import annotations

import argparse,json,random,sys
from pathlib import Path
import torch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from crgod.checkpointing import RuntimeContract
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.replay_io import load_jsonl
from crgod.sequence import build_recurrent_bc_batch
from crgod.supervisor import AtomicCheckpointStore
from crgod.tensorizer import BattleTensorizer
from crgod.training.bc_v2 import recurrent_bc_step
from crgod.training.eval_recurrent import evaluate_recurrent_policy
from crgod.training.replay_split import chronological_episode_split
from crgod.vocab import CardVocabulary


def _used_ids(episodes):
    cards=set(); entities=set()
    for ep in episodes:
        for tr in ep.transitions:
            for s in (tr.state,tr.next_state):
                cards.update(c.card_id for c in s.hand)
                if s.next_card is not None: cards.add(s.next_card.card_id)
                cards.update(ev.card_id for ev in s.recent_events if ev.card_id>=0)
                entities.update(e.card_id for e in s.entities if e.card_id>=0)
            if not tr.opponent_action.is_pass: cards.add(int(tr.opponent_action.card_id))
    return cards,entities


def main():
    ap=argparse.ArgumentParser(description='CR-God v2.2 recurrent behavior-cloning trainer')
    ap.add_argument('--replay',required=True)
    ap.add_argument('--card-vocab',required=True,help='complete playable-card vocabulary JSON')
    ap.add_argument('--entity-vocab',required=True,help='battlefield entity/species vocabulary JSON')
    ap.add_argument('--out',default='runs/bc_v22')
    ap.add_argument('--updates',type=int,default=1000)
    ap.add_argument('--batch-size',type=int,default=8)
    ap.add_argument('--train-steps',type=int,default=32)
    ap.add_argument('--burn-in',type=int,default=8)
    ap.add_argument('--eval-every',type=int,default=100)
    ap.add_argument('--lr',type=float,default=3e-4)
    ap.add_argument('--seed',type=int,default=0)
    ap.add_argument('--device',default='cpu')
    ap.add_argument('--hasty-commit',default=None)
    args=ap.parse_args()

    random.seed(args.seed); torch.manual_seed(args.seed)
    episodes=load_jsonl(args.replay); splits=chronological_episode_split(episodes)
    card_vocab=CardVocabulary.load(args.card_vocab); entity_vocab=CardVocabulary.load(args.entity_vocab)
    cards,entities=_used_ids(episodes)
    card_vocab.assert_covers(cards,'BC replay card vocabulary')
    entity_vocab.assert_covers(entities,'BC replay entity vocabulary')
    ten=BattleTensorizer(card_vocab,entity_vocab=entity_vocab)
    model=CRGodV2Net(card_vocab.size,entity_vocab_size=entity_vocab.size).to(args.device)
    opt=torch.optim.AdamW(model.parameters(),lr=args.lr)
    rng=random.Random(args.seed)
    store=AtomicCheckpointStore(ROOT/args.out)
    contract=RuntimeContract.build(card_vocab,args.hasty_commit,entity_vocab)
    best=-1.0; history=[]

    for update in range(1,args.updates+1):
        batch=build_recurrent_bc_batch(splits.train,ten,args.batch_size,args.train_steps,args.burn_in,rng).to(args.device)
        model.train(); m=recurrent_bc_step(model,batch,opt)
        if update==1 or update%args.eval_every==0 or update==args.updates:
            ev=evaluate_recurrent_policy(model,splits.val,ten,args.device)
            row={'update':update,**m.__dict__,'val_accuracy':ev.accuracy,'val_illegal':ev.illegal_argmax_rate,'val_decisions':ev.decisions}
            history.append(row); print(json.dumps(row))
            if ev.illegal_argmax_rate>0: raise RuntimeError('validation policy selected illegal action')
            if ev.accuracy>best:
                best=ev.accuracy
                meta={**contract.metadata(),'update':update,'val_accuracy':best,'seed':args.seed}
                store.save('best',model,opt,meta)

    test=evaluate_recurrent_policy(model,splits.test,ten,args.device)
    out=ROOT/args.out; out.mkdir(parents=True,exist_ok=True)
    card_vocab.save(out/'card_vocab.json'); entity_vocab.save(out/'entity_vocab.json')
    report={'best_val_accuracy':best,'test':test.__dict__,'history':history,'episodes':{'train':len(splits.train),'val':len(splits.val),'test':len(splits.test)},'runtime_contract':contract.metadata()['runtime_contract']}
    (out/'train_report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps(report['test'],indent=2))

if __name__=='__main__': main()
