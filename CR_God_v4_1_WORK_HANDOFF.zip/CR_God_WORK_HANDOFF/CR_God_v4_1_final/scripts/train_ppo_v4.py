#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
import random
import sys
from pathlib import Path

import torch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0,str(ROOT))

from crgod.checkpointing_v4 import assert_checkpoint_compatible_v4, RuntimeContractV4
from crgod.evaluation_v3 import paired_seat_swap_eval
from crgod.models.crgod_v4 import CRGodV4Net
from crgod.sim_audit_v4 import load_simulator_factory, stress_audit_simulator
from crgod.supervisor import AtomicCheckpointStore
from crgod.tensorizer import BattleTensorizer
from crgod.training.discounts import HalfLifeSchedule
from crgod.training.ppo_from_unroll import actor_unroll_to_ppo_batch
from crgod.training.ppo_trainer import RecurrentPPOTrainer, PPOTrainerConfig
from crgod.training.reward_guard import GuardedRewardMixer
from crgod.training.rewarding import RewardMixer
from crgod.training.selfplay_v3 import RecurrentPolicyActor, SelfPlaySession
from crgod.training.supervisor_v4 import TrainingSupervisorV4, HealthSnapshot
from crgod.vocab import CardVocabulary


def _load_model(run_dir:Path,name:str,card_vocab:CardVocabulary,entity_vocab:CardVocabulary,
                simulator_id:str,device:str):
    model=CRGodV4Net(card_vocab.size,entity_vocab_size=entity_vocab.size).to(device)
    store=AtomicCheckpointStore(run_dir)
    metadata=store.load(name,model,map_location=device)
    assert_checkpoint_compatible_v4(metadata,card_vocab,entity_vocab,simulator_id)
    return model,metadata


def _actor_factory(model,tensorizer,device,actor_id,version):
    def make():
        return RecurrentPolicyActor(copy.deepcopy(model),tensorizer,device=device,
                                    actor_id=actor_id,policy_version=version,clone_model=False)
    return make


def _eval_score(sim_factory,candidate,baseline,tensorizer,device,seeds,max_steps):
    cand=_actor_factory(candidate,tensorizer,device,'candidate-eval',0)
    base=_actor_factory(baseline,tensorizer,device,'baseline-eval',0)
    rows=paired_seat_swap_eval(sim_factory,cand,base,seeds,max_steps=max_steps)
    score=sum(r.candidate_score for r in rows)/len(rows)
    return score,rows


def _collect_complete_episodes(sim_factory,model,tensorizer,*,device,policy_version,
                               episodes,unroll_length,max_steps,seed_base,reward_mixer,
                               discount_schedule,learner_step):
    batches=[]; outcomes=[]; total_steps=0
    for ep in range(episodes):
        sim=sim_factory()
        if str(sim.simulator_id)=='' or float(sim.decision_interval_s)<=0:
            raise RuntimeError('invalid simulator runtime identity')
        a=RecurrentPolicyActor(model,tensorizer,device=device,actor_id=f'self-a-{ep}',policy_version=policy_version)
        b=RecurrentPolicyActor(model,tensorizer,device=device,actor_id=f'self-b-{ep}',policy_version=policy_version)
        sess=SelfPlaySession(sim,a,b,reward_mixer=reward_mixer)
        sess.reset(seed=seed_base+ep)
        steps=0
        while sess.active:
            remaining=max_steps-steps
            if remaining<=0:
                raise RuntimeError(f'PPO collection episode {ep} exceeded max_steps={max_steps}')
            joint=sess.collect(unroll_length=min(unroll_length,remaining),learner_step=learner_step,burn_in_length=0)
            for u in (joint.seat_a,joint.seat_b):
                batches.append(actor_unroll_to_ppo_batch(
                    u,model,tensorizer,device=device,expected_policy_version=policy_version,
                    discount_schedule=discount_schedule,learner_step=learner_step))
            steps += len(joint.seat_a.steps)
        outcomes.append(joint.outcome_a)
        total_steps += steps
    return batches,outcomes,total_steps


def main():
    ap=argparse.ArgumentParser(description='CR-God v4 synchronous recurrent PPO trainer')
    ap.add_argument('--sim-factory',required=True,help='package.module:factory implementing TrainingSimulator')
    ap.add_argument('--init-run',required=True,help='v4 BC/checkpoint run directory containing vocab JSON files')
    ap.add_argument('--init-name',default='best')
    ap.add_argument('--out',default='runs/ppo_v4')
    ap.add_argument('--updates',type=int,default=50)
    ap.add_argument('--episodes-per-update',type=int,default=4)
    ap.add_argument('--unroll-length',type=int,default=96)
    ap.add_argument('--max-steps-per-episode',type=int,default=2000)
    ap.add_argument('--ppo-epochs',type=int,default=4)
    ap.add_argument('--lr',type=float,default=1e-5)
    ap.add_argument('--clip-eps',type=float,default=.2)
    ap.add_argument('--value-clip-eps',type=float,default=.2)
    ap.add_argument('--entropy-coef',type=float,default=.01)
    ap.add_argument('--value-coef',type=float,default=.5)
    ap.add_argument('--target-kl',type=float,default=.02)
    ap.add_argument('--hard-stop-kl',type=float,default=.06)
    ap.add_argument('--max-grad-norm',type=float,default=1.0)
    ap.add_argument('--supervisor-max-grad-norm',type=float,default=1000.0,help='pre-clipping gradient norm circuit breaker')
    ap.add_argument('--eval-every',type=int,default=5)
    ap.add_argument('--eval-pairs',type=int,default=20,help='seat-swapped seed pairs per periodic safety eval')
    ap.add_argument('--preflight-episodes',type=int,default=4)
    ap.add_argument('--seed',type=int,default=0)
    ap.add_argument('--device',default='cpu')
    ap.add_argument('--dense-reward',action='store_true',help='enable bounded/annealed reward shaping; terminal-only is safer default')
    args=ap.parse_args()
    if min(args.updates,args.episodes_per_update,args.unroll_length,args.max_steps_per_episode,args.ppo_epochs,args.eval_every,args.eval_pairs,args.preflight_episodes)<=0:
        raise ValueError('all count arguments must be positive')
    if args.lr<=0: raise ValueError('lr must be positive')

    random.seed(args.seed); torch.manual_seed(args.seed)
    device=torch.device(args.device)
    sim_factory=load_simulator_factory(args.sim_factory)
    audit=stress_audit_simulator(sim_factory(),episodes=args.preflight_episodes,
                                 max_steps_per_episode=args.max_steps_per_episode,seed=args.seed)
    simulator_id=audit.simulator_id

    init_run=Path(args.init_run).resolve()
    card_vocab=CardVocabulary.load(init_run/'card_vocab.json')
    entity_vocab=CardVocabulary.load(init_run/'entity_vocab.json')
    tensorizer=BattleTensorizer(card_vocab,entity_vocab=entity_vocab)
    model,init_meta=_load_model(init_run,args.init_name,card_vocab,entity_vocab,simulator_id,str(device))
    baseline=copy.deepcopy(model).to(device).eval()

    optimizer=torch.optim.AdamW(model.parameters(),lr=args.lr)
    trainer=RecurrentPPOTrainer(model,optimizer,PPOTrainerConfig(
        epochs=args.ppo_epochs,target_kl=args.target_kl,hard_stop_kl=args.hard_stop_kl,
        clip_eps=args.clip_eps,value_coef=args.value_coef,entropy_coef=args.entropy_coef,
        max_grad_norm=args.max_grad_norm,value_clip_eps=args.value_clip_eps))
    schedule=HalfLifeSchedule()
    reward_mixer=GuardedRewardMixer(RewardMixer()) if args.dense_reward else None
    supervisor=TrainingSupervisorV4(max_kl=args.hard_stop_kl,max_grad_norm=args.supervisor_max_grad_norm,patience=2)

    out=(ROOT/args.out).resolve(); out.mkdir(parents=True,exist_ok=True)
    store=AtomicCheckpointStore(out)
    contract=RuntimeContractV4.build(card_vocab,entity_vocab,simulator_id)
    card_vocab.save(out/'card_vocab.json'); entity_vocab.save(out/'entity_vocab.json')
    # Frozen baseline makes the periodic score interpretable across the whole run.
    store.save('baseline_init',baseline,None,{**contract.metadata(),'source_run':str(init_run),'source_name':args.init_name,'role':'frozen_eval_baseline'})
    # A rollback target must exist before the first PPO gradient step.  The
    # frozen BC initialization is by definition a 0.5 score against itself.
    store.save('best',model,optimizer,{**contract.metadata(),'update':0,'policy_version':0,
                                      'paired_eval_score_vs_init':0.5,'role':'safe_initial_bc',
                                      'source_run':str(init_run),'source_name':args.init_name})

    best_score=0.5; policy_version=0; history=[]; bad_rollbacks=0
    eval_seeds=[args.seed+1_000_000+i for i in range(args.eval_pairs)]
    for update in range(1,args.updates+1):
        batches,outcomes,env_steps=_collect_complete_episodes(
            sim_factory,model,tensorizer,device=device,policy_version=policy_version,
            episodes=args.episodes_per_update,unroll_length=args.unroll_length,
            max_steps=args.max_steps_per_episode,seed_base=args.seed+update*10_000,
            reward_mixer=reward_mixer,discount_schedule=schedule,learner_step=update)
        metrics=trainer.update(batches,rng=random.Random(args.seed+update),device=device)
        policy_version+=1
        row={'update':update,'policy_version':policy_version,'env_steps':env_steps,
             'episodes':args.episodes_per_update,'mean_outcome_a':sum(float(x) for x in outcomes if x is not None)/len(outcomes),
             **metrics.__dict__}
        store.save('latest',model,optimizer,{**contract.metadata(),**row,'source_run':str(init_run),'source_name':args.init_name})

        if update==1 or update%args.eval_every==0 or update==args.updates:
            score,_=_eval_score(sim_factory,model,baseline,tensorizer,device,eval_seeds,args.max_steps_per_episode)
            row['paired_eval_score_vs_init']=score; row['paired_eval_pairs']=len(eval_seeds)
            health=HealthSnapshot(update,metrics.max_kl,metrics.mean_clip_fraction,metrics.max_grad_norm,
                                  metrics.mean_value_loss,metrics.mean_entropy,score,score,0.0)
            decision=supervisor.inspect(health); row['supervisor_action']=decision.action; row['supervisor_reasons']=decision.reasons
            if decision.action=='keep' and score>best_score:
                best_score=score; bad_rollbacks=0
                store.save('best',model,optimizer,{**contract.metadata(),**row,'source_run':str(init_run),'source_name':args.init_name})
            if decision.action in ('rollback','stop'):
                store.save('failed_candidate',model,optimizer,{**contract.metadata(),**row,'source_run':str(init_run),'source_name':args.init_name})
                if store.exists('best'):
                    store.load('best',model,optimizer,map_location=device)
                bad_rollbacks+=1
                history.append(row); print(json.dumps(row));
                if decision.action=='stop' or bad_rollbacks>=1:
                    break
        history.append(row); print(json.dumps(row))

    if not store.exists('best'):
        raise RuntimeError('PPO run never produced an evaluated best checkpoint')
    best_meta=store.load('best',model,optimizer,map_location=device)
    assert_checkpoint_compatible_v4(best_meta,card_vocab,entity_vocab,simulator_id)
    final_score,_=_eval_score(sim_factory,model,baseline,tensorizer,device,eval_seeds,args.max_steps_per_episode)
    report={'simulator_audit':audit.__dict__,'best_score_vs_init':final_score,'updates_completed':len(history),
            'dense_reward':bool(args.dense_reward),'history':history,'runtime_contract':best_meta['runtime_contract_v4'],
            'note':'Periodic eval is a safety signal, not the final promotion test. Run eval_ab_v4.py with >=100 fresh seed pairs.'}
    (out/'train_report.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps({'best_score_vs_init':final_score,'out':str(out)},indent=2))

if __name__=='__main__':
    main()
