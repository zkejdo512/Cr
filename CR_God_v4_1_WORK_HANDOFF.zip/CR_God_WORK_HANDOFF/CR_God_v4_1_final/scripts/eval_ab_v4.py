#!/usr/bin/env python3
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path
import torch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from crgod.checkpointing_v4 import assert_checkpoint_compatible_v4
from crgod.evaluation_v2 import paired_ab_gate
from crgod.evaluation_v3 import paired_seat_swap_eval
from crgod.models.crgod_v4 import CRGodV4Net
from crgod.sim_audit_v4 import load_simulator_factory,stress_audit_simulator
from crgod.supervisor import AtomicCheckpointStore
from crgod.tensorizer import BattleTensorizer
from crgod.training.selfplay_v3 import RecurrentPolicyActor
from crgod.vocab import CardVocabulary


def _load(run:Path,name:str,cv,ev,sim_id,device):
    m=CRGodV4Net(cv.size,entity_vocab_size=ev.size).to(device)
    meta=AtomicCheckpointStore(run).load(name,m,map_location=device)
    assert_checkpoint_compatible_v4(meta,cv,ev,sim_id)
    return m.eval(),meta


def main():
    ap=argparse.ArgumentParser(description='Paired seat-swap A/B evaluator for CR-God v4 checkpoints')
    ap.add_argument('--sim-factory',required=True)
    ap.add_argument('--candidate-run',required=True); ap.add_argument('--candidate-name',default='best')
    ap.add_argument('--baseline-run',required=True); ap.add_argument('--baseline-name',default='best')
    ap.add_argument('--pairs',type=int,default=100); ap.add_argument('--seed',type=int,default=9000000)
    ap.add_argument('--max-steps',type=int,default=2000); ap.add_argument('--min-delta',type=float,default=.02)
    ap.add_argument('--alpha',type=float,default=.05); ap.add_argument('--device',default='cpu')
    ap.add_argument('--out',default='')
    args=ap.parse_args()
    if args.pairs<=0 or args.max_steps<=0: raise ValueError('pairs/max-steps must be positive')
    sf=load_simulator_factory(args.sim_factory)
    audit=stress_audit_simulator(sf(),episodes=2,max_steps_per_episode=args.max_steps,seed=args.seed)
    cand_run=Path(args.candidate_run).resolve(); base_run=Path(args.baseline_run).resolve()
    cv=CardVocabulary.load(cand_run/'card_vocab.json'); ev=CardVocabulary.load(cand_run/'entity_vocab.json')
    cv2=CardVocabulary.load(base_run/'card_vocab.json'); ev2=CardVocabulary.load(base_run/'entity_vocab.json')
    if cv.fingerprint()!=cv2.fingerprint() or ev.fingerprint()!=ev2.fingerprint():
        raise RuntimeError('candidate/baseline vocabulary fingerprints differ')
    ten=BattleTensorizer(cv,entity_vocab=ev); device=torch.device(args.device)
    cand,_=_load(cand_run,args.candidate_name,cv,ev,audit.simulator_id,device)
    base,_=_load(base_run,args.baseline_name,cv,ev,audit.simulator_id,device)
    def cf(): return RecurrentPolicyActor(copy.deepcopy(cand),ten,device=device,actor_id='candidate',policy_version=0,clone_model=False)
    def bf(): return RecurrentPolicyActor(copy.deepcopy(base),ten,device=device,actor_id='baseline',policy_version=0,clone_model=False)
    seeds=[args.seed+i for i in range(args.pairs)]
    rows=paired_seat_swap_eval(sf,cf,bf,seeds,max_steps=args.max_steps)
    gate=paired_ab_gate(rows,min_pairs=args.pairs,min_delta=args.min_delta,alpha=args.alpha)
    payload={'simulator_audit':audit.__dict__,'gate':gate.__dict__,
             'pairs':[r.__dict__ for r in rows]}
    text=json.dumps(payload,indent=2)
    if args.out: Path(args.out).write_text(text,encoding='utf8')
    print(text)
    raise SystemExit(0 if gate.passed else 2)

if __name__=='__main__': main()
