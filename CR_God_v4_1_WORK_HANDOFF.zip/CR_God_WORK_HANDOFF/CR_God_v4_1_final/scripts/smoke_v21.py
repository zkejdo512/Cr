#!/usr/bin/env python3
from __future__ import annotations
import pathlib,sys,random,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
import torch
from crgod.data import collect_toy_expert,build_card_vocab
from crgod.sequence import split_episodes,build_recurrent_bc_batch
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.training.bc_v2 import recurrent_bc_step
from crgod.replay_io import save_jsonl,load_jsonl
from crgod.supervisor import TrainingSupervisor,TrainingSnapshot,Decision
from crgod.evaluation_v2 import PairedOutcome,paired_ab_gate


def main():
    torch.manual_seed(21); random.seed(21)
    data=collect_toy_expert(8,seed=21); eps=split_episodes(data); vocab=build_card_vocab(data); ten=BattleTensorizer(vocab,8,16)
    batch=build_recurrent_bc_batch(eps,ten,batch_size=4,train_steps=8,burn_in=4,rng=random.Random(21))
    net=CRGodV2Net(vocab.size); opt=torch.optim.AdamW(net.parameters(),lr=5e-4)
    m=None
    for _ in range(5): m=recurrent_bc_step(net,batch,opt)
    assert m is not None and m.loss==m.loss
    # Causality sentinel: episode start is always unknown/pass history.
    full=build_recurrent_bc_batch([eps[0]],ten,1,len(eps[0].transitions),0,random.Random(1))
    assert not bool(full.prev_opp_known[0,0])
    with tempfile.TemporaryDirectory() as td:
        p=pathlib.Path(td)/'toy.jsonl'; save_jsonl(eps,p); loaded=load_jsonl(p); assert len(loaded)==len(eps)
    sup=TrainingSupervisor(patience=2)
    assert sup.observe(TrainingSnapshot(1,.60,.50,0,.01,.7,100)).decision==Decision.KEEP_BEST
    sup.observe(TrainingSnapshot(2,.54,.48,0,.01,.7,100))
    assert sup.observe(TrainingSnapshot(3,.53,.47,0,.01,.7,100)).decision==Decision.ROLLBACK
    rows=[PairedOutcome(0,1,i,'a' if i%2 else 'b') for i in range(80)]+[PairedOutcome(.5,.5,80+i,'a' if i%2 else 'b') for i in range(40)]
    gate=paired_ab_gate(rows,min_pairs=100,min_delta=.1)
    assert gate.passed
    print(f'v2.1 recurrent BC loss={m.loss:.4f} acc={m.accuracy:.3f}')
    print(f'v2.1 A/B mean_delta={gate.mean_delta:.3f} p={gate.sign_test_p:.3g}')
    print('smoke_v21: OK')

if __name__=='__main__': main()
