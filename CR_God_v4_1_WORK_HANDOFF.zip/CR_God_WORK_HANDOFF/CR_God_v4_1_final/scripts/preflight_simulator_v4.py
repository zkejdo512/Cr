#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, pathlib, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from crgod.sim_audit_v4 import load_simulator_factory, stress_audit_simulator

p=argparse.ArgumentParser(description='CR-God v4 black-box simulator contract stress audit')
p.add_argument('--factory',required=True,help='Python factory as module.path:callable')
p.add_argument('--episodes',type=int,default=4)
p.add_argument('--max-steps',type=int,default=2000)
p.add_argument('--seed',type=int,default=0)
a=p.parse_args()
sim=load_simulator_factory(a.factory)()
r=stress_audit_simulator(sim,episodes=a.episodes,max_steps_per_episode=a.max_steps,seed=a.seed)
print(json.dumps(r.__dict__,indent=2,ensure_ascii=False))
