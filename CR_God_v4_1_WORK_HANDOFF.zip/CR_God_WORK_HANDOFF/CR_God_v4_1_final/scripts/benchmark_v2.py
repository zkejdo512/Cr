#!/usr/bin/env python3
from __future__ import annotations
import pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
import torch
from crgod.data import collect_toy_expert,build_card_vocab,sample_transition_batch
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v2 import CRGodV2Net

def main():
    torch.manual_seed(0); d=collect_toy_expert(2); v=build_card_vocab(d); t=BattleTensorizer(v,8,16); b=sample_transition_batch(d,t,8); n=CRGodV2Net(v.size).eval()
    with torch.no_grad():
        for _ in range(3): n(b.state,legal_mask=b.legal_mask)
        t0=time.perf_counter(); N=20
        for _ in range(N): n(b.state,legal_mask=b.legal_mask)
        dt=time.perf_counter()-t0
    print(f'v2 forward batch=8: {dt/N*1000:.2f} ms/batch ({dt/N/8*1000:.2f} ms/state), CPU reference only')
if __name__=='__main__': main()
