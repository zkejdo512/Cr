#!/usr/bin/env python3
from __future__ import annotations
import argparse,pathlib,sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from crgod.adapters.hasty import HastyRuntime

p=argparse.ArgumentParser(); p.add_argument('hasty_root'); p.add_argument('--seed',type=int,default=991); a=p.parse_args()
r=HastyRuntime(a.hasty_root).audit(a.seed); print(r.to_json()); r.assert_ok()
