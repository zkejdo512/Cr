#!/usr/bin/env python3
from __future__ import annotations

import argparse, json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from crgod.adapters.hasty import HastyRuntime, HastyEnvAdapter
from crgod.contracts import OBSERVATION_SCHEMA_VERSION
from crgod.mechanics_gates import MechanicsCalibrationReport
from crgod.tensorizer import BattleTensorizer
from crgod.training.gates_v22 import V22ReadinessReport


def main():
    ap=argparse.ArgumentParser(description='Fail-closed CR-God v2.2 preflight')
    ap.add_argument('--hasty-root',required=True)
    ap.add_argument('--expected-commit',default=None,help='exact git SHA (or unique prefix) approved for training')
    ap.add_argument('--mechanics-json',default=None)
    ap.add_argument('--entity-vocab-json',default=None,help='approved complete battlefield-entity vocabulary JSON')
    ap.add_argument('--ab-json',default=None,help='JSON containing {"passed": true} from paired held-out evaluation')
    ap.add_argument('--hasty-smoke-json',default=None,help='output from scripts/hasty_ppo_smoke.py')
    ap.add_argument('--run-tests',action='store_true')
    ap.add_argument('--out',default='runs/readiness_v22.json')
    args=ap.parse_args()

    tests_ok=False
    if args.run_tests:
        proc=subprocess.run([sys.executable,'-m','pytest','-q'],cwd=ROOT)
        tests_ok=(proc.returncode==0)

    rt=HastyRuntime(args.hasty_root)
    parity=rt.audit(); source=rt.source_audit(); sha=rt.commit_sha()
    commit_ok=bool(sha)
    if args.expected_commit:
        commit_ok=bool(sha and sha.startswith(args.expected_commit))

    schema_ok=False; vocab_ok=False; entity_vocab_ok=False
    try:
        adapter=HastyEnvAdapter(args.hasty_root,seed=991)
        obs,mask,_=adapter.reset(seed=991)
        vocab=adapter.build_vocab(); vocab.assert_covers(adapter.supported_card_ids(),'Hasty full supported-card vocabulary')
        entity_vocab=None
        if args.entity_vocab_json:
            from crgod.vocab import CardVocabulary
            entity_vocab=CardVocabulary.load(args.entity_vocab_json)
            # This only checks the current probe state. The file itself is treated
            # as an externally curated complete registry and is still bound into
            # checkpoint fingerprints later.
            entity_vocab.assert_covers((e.card_id for e in obs.entities),'current Hasty battlefield entities')
            entity_vocab_ok=True
        BattleTensorizer(vocab,entity_vocab=entity_vocab).one(obs)
        schema_ok=(obs.version==OBSERVATION_SCHEMA_VERSION)
        vocab_ok=True
    except Exception as exc:
        print(f'[preflight] adapter/schema/vocab probe failed: {exc}',file=sys.stderr)

    mechanics_ok=False
    if args.mechanics_json:
        try:
            mechanics=MechanicsCalibrationReport.load_json(args.mechanics_json)
            mechanics_ok=(not mechanics.blockers())
            if not mechanics_ok:
                print('[preflight] mechanics blockers:',*mechanics.blockers(),sep='\n- ',file=sys.stderr)
        except Exception as exc:
            print(f'[preflight] mechanics report invalid: {exc}',file=sys.stderr)

    hasty_smoke_ok=False
    if args.hasty_smoke_json:
        try:
            hasty_smoke_ok=bool(json.loads(Path(args.hasty_smoke_json).read_text(encoding='utf8')).get('passed',False))
        except Exception as exc:
            print(f'[preflight] Hasty PPO smoke report invalid: {exc}',file=sys.stderr)

    ab_ok=False
    if args.ab_json:
        try:
            ab_ok=bool(json.loads(Path(args.ab_json).read_text(encoding='utf8')).get('passed',False))
        except Exception as exc:
            print(f'[preflight] A/B report invalid: {exc}',file=sys.stderr)

    # Unit tests are evidence for internal invariants only. Hasty on-policy smoke,
    # real calibration and paired A/B remain separate external gates.
    report=V22ReadinessReport(
        regression_tests_pass=tests_ok,
        observation_schema_parity_pass=schema_ok,
        sequence_no_future_leakage_pass=tests_ok,
        replay_roundtrip_pass=tests_ok,
        full_card_vocab_pass=vocab_ok,
        full_entity_vocab_pass=entity_vocab_ok,
        recurrent_bc_smoke_pass=tests_ok,
        recurrent_ppo_smoke_pass=tests_ok,
        hasty_commit_pinned=commit_ok,
        hasty_runtime_parity_pass=parity.ok,
        hasty_source_audit_pass=source.ok,
        onpolicy_hasty_rollout_smoke_pass=hasty_smoke_ok,
        supervisor_rollback_pass=tests_ok,
        checkpoint_resume_pass=tests_ok,
        real_mechanics_calibration_pass=mechanics_ok,
        paired_ab_gate_pass=ab_ok,
    )
    out=ROOT/args.out
    out.parent.mkdir(parents=True,exist_ok=True); report.save(out)
    print(json.dumps({
        'commit':sha,
        'runtime_parity':json.loads(parity.to_json()),
        'source_audit':json.loads(source.to_json()),
        'readiness':report.to_dict(),
        'report_path':str(out),
    },indent=2))
    return 0 if report.ready_for_paid_training else 2

if __name__=='__main__': raise SystemExit(main())
