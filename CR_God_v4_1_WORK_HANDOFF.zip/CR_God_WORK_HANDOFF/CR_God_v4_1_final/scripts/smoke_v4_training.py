#!/usr/bin/env python3
from pathlib import Path
import sys,copy,random,torch
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))

from crgod.envs.toy_joint import ToyJointSimulator,ToyJointConfig
from crgod.vocab import CardVocabulary
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v4 import CRGodV4Net
from crgod.training.selfplay_v3 import RecurrentPolicyActor,SelfPlaySession
from crgod.training.ppo_from_unroll import actor_unroll_to_ppo_batch
from crgod.training.ppo_trainer import RecurrentPPOTrainer,PPOTrainerConfig
from crgod.training.discounts import HalfLifeSchedule
from crgod.training.hardcase import HardCaseBuffer,HardCaseSignal
from crgod.training.curriculum_v4 import HardCaseCurriculum
from crgod.planning_v4 import AdaptiveFastSlowPlannerV4,AdaptivePlanContext,RolloutEstimateV4


def main():
    random.seed(0);torch.manual_seed(0)
    vocab=CardVocabulary.from_card_ids(list(range(10,15))+list(range(20,25)))
    ten=BattleTensorizer(vocab,max_entities=8,max_events=16)
    net=CRGodV4Net(vocab.size,latent_dim=64,fast_belief_dim=32,slow_belief_dim=24,entity_vocab_size=vocab.size)
    behavior=copy.deepcopy(net).eval();sim=ToyJointSimulator(ToyJointConfig(horizon=12))
    a=RecurrentPolicyActor(behavior,ten,actor_id='main',policy_version=1);b=RecurrentPolicyActor(copy.deepcopy(behavior),ten,actor_id='opp',policy_version=1)
    sess=SelfPlaySession(sim,a,b);sess.reset(seed=7);u=sess.collect(unroll_length=6,burn_in_length=3).seat_a
    schedule=HalfLifeSchedule(45,180,0,1000,.5)
    batch=actor_unroll_to_ppo_batch(u,net,ten,expected_policy_version=1,discount_schedule=schedule,learner_step=100)
    opt=torch.optim.Adam(net.parameters(),lr=2e-4);m=RecurrentPPOTrainer(net,opt,PPOTrainerConfig(epochs=1)).update([batch])
    hc=HardCaseBuffer(capacity=16);hc.add('case-1',{'seed':7},'toy',HardCaseSignal(outcome_failure=.8,policy_entropy=.5))
    chosen,is_hard=HardCaseCurriculum(hc).choose(1_000_000,lambda:{'seed':0},random.Random(1))
    planner=AdaptiveFastSlowPlannerV4();logits=torch.zeros(6);mask=torch.ones(6,dtype=torch.bool)
    tr=planner.decide(logits,mask,lambda a,n:RolloutEstimateV4(float(a==3),.05,n),AdaptivePlanContext(1,1,1))
    assert m.mean_loss==m.mean_loss and len(hc)==1 and tr.chosen_action==3
    print(f'v4_smoke: OK loss={m.mean_loss:.4f} hardcase={is_hard} planner_samples={tr.budget.rollout_samples}')

if __name__=='__main__':main()
