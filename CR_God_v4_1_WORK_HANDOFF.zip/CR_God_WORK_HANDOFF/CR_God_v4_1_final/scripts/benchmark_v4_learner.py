#!/usr/bin/env python3
from pathlib import Path
import sys,copy,time,torch
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:sys.path.insert(0,str(ROOT))
from crgod.envs.toy_joint import ToyJointSimulator,ToyJointConfig
from crgod.vocab import CardVocabulary
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v4 import CRGodV4Net
from crgod.training.selfplay_v3 import RecurrentPolicyActor,SelfPlaySession
from crgod.training.ppo_from_unroll import actor_unroll_to_ppo_batch
from crgod.training.ppo_trainer import RecurrentPPOTrainer,PPOTrainerConfig

def main():
    torch.manual_seed(0);v=CardVocabulary.from_card_ids(list(range(10,15))+list(range(20,25)));t=BattleTensorizer(v,max_entities=8,max_events=16)
    n=CRGodV4Net(v.size,latent_dim=64,fast_belief_dim=32,slow_belief_dim=24,entity_vocab_size=v.size);opt=torch.optim.Adam(n.parameters(),lr=1e-4)
    start=time.perf_counter();updates=0
    for ep in range(3):
        old=copy.deepcopy(n).eval();sim=ToyJointSimulator(ToyJointConfig(horizon=12));a=RecurrentPolicyActor(old,t,policy_version=ep);b=RecurrentPolicyActor(copy.deepcopy(old),t,policy_version=ep)
        s=SelfPlaySession(sim,a,b);s.reset(seed=ep)
        while s.active:
            j=s.collect(unroll_length=6,burn_in_length=3)
            for u in (j.seat_a,j.seat_b):
                batch=actor_unroll_to_ppo_batch(u,n,t,expected_policy_version=ep);RecurrentPPOTrainer(n,opt,PPOTrainerConfig(epochs=1)).update([batch]);updates+=1
    dt=time.perf_counter()-start
    print(f'v4_learner_benchmark updates={updates} elapsed_s={dt:.3f} updates_per_s={updates/dt:.2f}')
if __name__=='__main__':main()
