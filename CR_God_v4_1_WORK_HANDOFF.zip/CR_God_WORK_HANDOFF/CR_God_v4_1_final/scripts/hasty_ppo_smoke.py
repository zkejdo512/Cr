#!/usr/bin/env python3
from __future__ import annotations

import argparse, json, math, sys
from pathlib import Path
import torch

ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))

from crgod.adapters.hasty import HastyRuntime, HastyEnvAdapter
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.tensorizer import BattleTensorizer
from crgod.training.rollout_v22 import collect_complete_episode, build_ppo_chunks
from crgod.training.ppo_v2 import recurrent_ppo_step


def main():
    ap=argparse.ArgumentParser(description='Short Hasty→CR-God recurrent PPO integration smoke')
    ap.add_argument('--hasty-root',required=True)
    ap.add_argument('--expected-commit',default=None)
    ap.add_argument('--device',default='cpu')
    ap.add_argument('--seed',type=int,default=991)
    ap.add_argument('--sim-seconds',type=int,default=20,help='truncate smoke after this simulated time')
    ap.add_argument('--seq-len',type=int,default=16)
    ap.add_argument('--out',default='runs/hasty_ppo_smoke.json')
    args=ap.parse_args()

    rt=HastyRuntime(args.hasty_root)
    rt.audit(args.seed).assert_ok(); rt.source_audit().assert_ok()
    sha=rt.commit_sha()
    if args.expected_commit and not (sha and sha.startswith(args.expected_commit)):
        raise RuntimeError(f'Hasty commit mismatch: got {sha}, expected prefix {args.expected_commit}')

    adapter=HastyEnvAdapter(args.hasty_root,seed=args.seed,max_ms=args.sim_seconds*1000)
    vocab=adapter.build_vocab(); vocab.assert_covers(adapter.supported_card_ids(),'Hasty supported-card vocabulary')
    tensorizer=BattleTensorizer(vocab)
    model=CRGodV2Net(vocab.size).to(args.device)
    opt=torch.optim.Adam(model.parameters(),lr=1e-4)

    ep=collect_complete_episode(adapter,model,tensorizer,device=args.device,seed=args.seed,max_steps=max(8,args.sim_seconds*4))
    chunks=build_ppo_chunks([ep],tensorizer,seq_len=args.seq_len)
    metrics=[]
    model.train()
    for chunk in chunks[:2]:
        m=recurrent_ppo_step(model,chunk.to(args.device),opt,entropy_coef=0.0)
        metrics.append(m.__dict__)
    finite=all(math.isfinite(float(v)) for row in metrics for v in row.values())
    result={
        'passed': bool(finite and len(ep.steps)>0 and len(chunks)>0),
        'commit': sha,
        'steps': len(ep.steps),
        'chunks': len(chunks),
        'metrics': metrics,
        'vocab_size': vocab.size,
    }
    out=ROOT/args.out; out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,indent=2),encoding='utf8')
    print(json.dumps(result,indent=2))
    return 0 if result['passed'] else 2

if __name__=='__main__': raise SystemExit(main())
