#!/usr/bin/env python3
"""Fail-fast static audit for a locally cloned Hasty-CR checkout.

Static source checks are intentionally conservative. Passing this script is not
runtime parity or real-game calibration; failing it means the checkout is known
incompatible with CR-God v2.2.
"""
from pathlib import Path
import argparse, re, sys
ROOT=Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
from crgod.adapters.hasty import ABILITY_CAPABILITY_FIELDS


def need(text: str, pattern: str, label: str, failures: list[str]):
    if re.search(pattern, text, re.M) is None: failures.append(label)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('repo'); args=ap.parse_args()
    root=Path(args.repo); env=(root/'sim'/'env.py').read_text(encoding='utf8'); match=(root/'sim'/'match.py').read_text(encoding='utf8')
    failures=[]
    need(env,r'CARD_ACTIONS\s*=\s*1\s*\+\s*NUM_SLOTS\s*\*\s*TILES','2305 card-action layout missing',failures)
    need(env,r'ABILITY_SLOTS\s*=\s*16','16 ability slots missing',failures)
    need(env,r'ACTIONS\s*=\s*CARD_ACTIONS\s*\+\s*ABILITY_SLOTS','2321 total action layout missing',failures)
    need(env,r'mask\[CARD_ACTIONS\s*\+\s*rank\]\s*=\s*True','ability legal mask missing',failures)
    # ability_entities must be able to enumerate every currently activatable
    # ability family, not merely self-buff heroes.
    m=re.search(r'def ability_entities\(.*?\n(?=def |class |@dataclass|# -)',env,re.S)
    block=m.group(0) if m else ''
    missing=[f for f in sorted(ABILITY_CAPABILITY_FIELDS) if f not in block]
    if missing: failures.append('ability_entities misses: '+', '.join(missing)+'; apply patches/hasty_env_ability_entities.patch')
    need(match,r'def _wake_kings','king activation logic missing',failures)
    need(env,r'deploy_area_ok\(','post-tower deployment geometry hook missing',failures)
    try: tb=match[match.index('    def _tiebreak'):][:900]
    except ValueError: tb=''
    if 'hitpoints' not in tb or 'hp_fraction' in tb or not re.search(r'[\"\']king[\"\']',tb):
        failures.append('tiebreak is not absolute HP across remaining crown towers; apply patches/hasty_match_tiebreak.patch')
    if failures:
        print('HASTY AUDIT: FAIL'); [print('-',x) for x in failures]; raise SystemExit(2)
    print('HASTY AUDIT: STATIC PASS (dynamic parity/calibration still required)')

if __name__=='__main__': main()
