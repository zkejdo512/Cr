#!/usr/bin/env python3
from __future__ import annotations
import subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def run(args):
    p=subprocess.run(args,cwd=ROOT,text=True,capture_output=True)
    print(p.stdout,end='')
    if p.returncode:
        print(p.stderr,file=sys.stderr,end=''); raise SystemExit(p.returncode)

def main():
    run([sys.executable,'-m','pytest','-q'])
    run([sys.executable,'scripts/smoke_v3_training.py'])
    print('CR-God v3 local training-core preflight: PASS')
    print('NOTE: this does not certify an external simulator. Run its contract/parity tests separately.')
if __name__=='__main__':main()
