#!/usr/bin/env python3
from __future__ import annotations
import pathlib,sys,random,math
ROOT=pathlib.Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))
import torch
from crgod.data import collect_toy_expert,build_card_vocab,_mask_from_indices
from crgod.sequence import split_episodes,build_recurrent_bc_batch
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.training.bc_v2 import recurrent_bc_step
from crgod.planning import FastSlowPlanner,RolloutEstimate
from crgod.league_v2 import PFSPLeague,LeagueMember


def main():
    torch.manual_seed(11); random.seed(11); torch.set_num_threads(1)
    data=collect_toy_expert(2,seed=11); eps=split_episodes(data); vocab=build_card_vocab(data); ten=BattleTensorizer(vocab,8,8)
    net=CRGodV2Net(vocab.size,latent_dim=96,belief_dim=64); opt=torch.optim.AdamW(net.parameters(),lr=3e-4)
    batch=build_recurrent_bc_batch(eps,ten,batch_size=1,train_steps=2,burn_in=1,rng=random.Random(11))
    m=recurrent_bc_step(net,batch,opt)
    obs=eps[0].transitions[0].state; mask,_=_mask_from_indices(eps[0].transitions[0].legal_action_indices)
    with torch.no_grad():
        tb=ten.one(obs); z=net.encoder(tb); h=net.initial_belief(1); logits,val=net.head(z,h,mask.unsqueeze(0))
    planner=FastSlowPlanner(entropy_threshold=0.0,margin_threshold=999,top_k=4)
    trace=planner.decide(logits[0],mask,lambda a: RolloutEstimate(float(a%7)/7.0,.05,4),force_slow=True)
    L=PFSPLeague(); L.add(LeagueMember('main','main.pt','main')); L.add(LeagueMember('old','old.pt','historical')); L.add(LeagueMember('exploit','x.pt','exploiter'))
    for _ in range(4): L.record('main','old',1.0); L.record('main','exploit',0.0)
    pick=L.sample_opponent('main',random.Random(2)).member_id
    print(f'V2 recurrent BC loss={m.loss:.4f} acc={m.accuracy:.3f}')
    print(f'Planner fast={trace.fast_action} chosen={trace.chosen_action} candidates={len(trace.candidates)}')
    print(f'League sample={pick} worst={L.worst_matchup("main")}')
    vals=(m.loss,m.policy_loss,m.value_loss,m.belief_loss,m.accuracy,float(val[0]))
    if not all(math.isfinite(float(x)) for x in vals): raise RuntimeError('v2 smoke produced non-finite metric')
    if not bool(mask[trace.chosen_action]): raise RuntimeError('planner chose illegal action')
    print('smoke_v2: OK')
if __name__=='__main__': main()
