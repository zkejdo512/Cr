import copy, random
import torch

from crgod.envs.toy_joint import ToyJointSimulator, ToyJointConfig
from crgod.vocab import CardVocabulary
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v4 import CRGodV4Net
from crgod.training.selfplay_v3 import RecurrentPolicyActor, collect_joint_unroll
from crgod.training.hardcase import HardCaseBuffer, HardCaseSignal
from crgod.training.curriculum_v4 import HardCaseCurriculum, HardCaseMixSchedule
from crgod.training.exploiters_v4 import AutoExploiterFactory, FailureSlice
from crgod.training.discounts import gamma_from_half_life, half_life_from_gamma, HalfLifeSchedule
from crgod.planning_v4 import AdaptiveFastSlowPlannerV4, AdaptivePlanContext, RolloutEstimateV4
from crgod.action_codec import NUM_ACTIONS
from crgod.evaluation_v4 import SliceMetric, summarize_slices, robust_promotion_gate
from crgod.training.rewarding import RewardMixer, DenseRewardWeights, RewardAnneal
from crgod.training.reward_guard import GuardedRewardMixer, RewardGuardConfig
from crgod.sim_protocol import RewardComponents
from crgod.training.planner_feedback import PlannerCorrectionBuffer, PlannerCorrection
from crgod.training.supervisor_v4 import TrainingSupervisorV4, HealthSnapshot
from crgod.training.ppo_from_unroll import actor_unroll_to_ppo_batch
from crgod.training.ppo_v2 import recurrent_ppo_step


def setup_v4():
    sim=ToyJointSimulator(ToyJointConfig(horizon=10))
    vocab=CardVocabulary.from_card_ids(list(range(10,15))+list(range(20,25)))
    ten=BattleTensorizer(vocab,max_entities=8,max_events=16)
    net=CRGodV4Net(vocab.size,latent_dim=64,fast_belief_dim=32,slow_belief_dim=24,entity_vocab_size=vocab.size)
    return sim,vocab,ten,net


def test_multiscale_belief_is_drop_in_and_both_timescales_train():
    sim,v,t,net=setup_v4(); a=RecurrentPolicyActor(net,t,actor_id='a',policy_version=1)
    b=RecurrentPolicyActor(copy.deepcopy(net),t,actor_id='b',policy_version=1)
    u=collect_joint_unroll(sim,a,b,unroll_length=6,seed=4).seat_a
    batch=actor_unroll_to_ppo_batch(u,net,t,expected_policy_version=1)
    before_fast=net.belief.fast_gru.weight_hh.detach().clone(); before_slow=net.belief.slow_gru.weight_hh.detach().clone()
    m=recurrent_ppo_step(net,batch,torch.optim.Adam(net.parameters(),lr=3e-4))
    assert m.loss==m.loss
    assert not torch.equal(before_fast,net.belief.fast_gru.weight_hh.detach())
    assert not torch.equal(before_slow,net.belief.slow_gru.weight_hh.detach())


def test_multiscale_slow_gate_is_finite_and_bounded():
    sim,v,t,net=setup_v4(); frame=sim.reset(seed=1)
    tb=t.one(frame.seat_a.observation); z=net.encoder(tb)
    h=net.initial_belief(1,z.device,z.dtype)
    from crgod.opponent_codec import OpponentActionBatch
    bp=net.update_belief(z,torch.zeros(1,dtype=torch.long),OpponentActionBatch.pass_batch(1),torch.tensor([False]),torch.tensor([.5]),h)
    assert bp.hidden.shape[-1]==56 and torch.isfinite(bp.hidden).all()
    assert bool(((bp.slow_gate>=0)&(bp.slow_gate<=1)).all())


def test_hardcase_buffer_prioritizes_and_caps_archetype():
    b=HardCaseBuffer(capacity=10,max_archetype_fraction=.5)
    for i in range(8):b.add(f'h{i}',i,'hog',HardCaseSignal(outcome_failure=.1+i*.01))
    assert len(b)==8  # early single-archetype data must not collapse capacity
    for i in range(5):b.add(f'x{i}',i,'xbow',HardCaseSignal(outcome_failure=.8))
    assert len(b)==10
    counts=b.archetype_counts(); assert counts.get('xbow',0)>=2
    xs=b.sample(3,random.Random(3)); assert len(xs)==3


def test_hardcase_curriculum_never_eliminates_broad_play():
    b=HardCaseBuffer();b.add('a','hard','hog',HardCaseSignal(outcome_failure=1.0))
    sched=HardCaseMixSchedule(start_fraction=0.,peak_fraction=.5,peak_step=10,end_fraction=.25,end_step=20)
    c=HardCaseCurriculum(b,sched); rng=random.Random(7)
    seen_normal=False
    for _ in range(30):
        x,is_hard=c.choose(10,lambda:'normal',rng)
        seen_normal|=not is_hard
    assert seen_normal


def test_auto_exploiter_targets_measured_weakness_only():
    f=AutoExploiterFactory(min_games=20,min_weakness=.05,max_new=2)
    specs=f.propose([FailureSlice('bait',100,.30,.02),FailureSlice('easy',100,.70,0.),FailureSlice('tiny',5,.0,1.)],3)
    assert len(specs)==1 and specs[0].target_slice=='bait'


def test_discount_half_life_roundtrip_and_schedule_lengthens_horizon():
    g=gamma_from_half_life(60,.5); assert abs(half_life_from_gamma(g,.5)-60)<1e-6
    s=HalfLifeSchedule(45,180,0,100,.5); assert s.gamma(100)>s.gamma(0)


def test_adaptive_planner_allocates_more_compute_for_critical_uncertain_state():
    p=AdaptiveFastSlowPlannerV4(); logits=torch.full((NUM_ACTIONS,),-9.0); mask=torch.zeros(NUM_ACTIONS,dtype=torch.bool)
    mask[[0,5,6,7,8,9]]=True; logits[[0,5,6,7,8,9]]=0.0
    calls=[]
    def rollout(a,n):calls.append((a,n));return RolloutEstimateV4(mean_value=float(a==7),std_value=.1,samples=n)
    tr=p.decide(logits,mask,rollout,AdaptivePlanContext(terminal_urgency=1,value_uncertainty=1,archetype_risk=1))
    assert tr.budget.use_slow and tr.budget.rollout_samples>1 and tr.chosen_action==7 and calls


def test_planner_correction_buffer_only_keeps_meaningful_overrides():
    b=PlannerCorrectionBuffer(capacity=3,min_regret=.05)
    assert not b.add(PlannerCorrection(None,1,1,.5,.1))
    assert not b.add(PlannerCorrection(None,1,2,.01,.1))
    assert b.add(PlannerCorrection('x',1,2,.2,.4))
    assert b.sample(1,random.Random(1))[0].payload=='x'


def test_robust_eval_gate_catches_slice_regression_despite_overall_gain():
    base=summarize_slices([SliceMetric('hog',100,55),SliceMetric('bait',100,55)])
    cand=summarize_slices([SliceMetric('hog',100,75),SliceMetric('bait',100,45)])
    ok,why=robust_promotion_gate(cand,base,min_overall_delta=.01,max_worst_slice_regression=.05,require_ci_noninferior=False)
    assert not ok and any('bait' in x for x in why)


def test_reward_guard_clips_dense_and_rejects_spike():
    base=RewardMixer(DenseRewardWeights(tower_damage=1.,crown=0.,elixir=0.,tactical=0.),RewardAnneal(0,10,1.,1.))
    g=GuardedRewardMixer(base,RewardGuardConfig(max_dense_per_step=.1,max_abs_component=2.))
    assert abs(g(RewardComponents(terminal=0,tower_damage=1.),0)-.1)<1e-6
    try:g(RewardComponents(tower_damage=99),0)
    except ValueError:pass
    else:raise AssertionError('spike should fail closed')


def test_supervisor_v4_rolls_back_training_instability():
    s=TrainingSupervisorV4(max_kl=.05,max_clip_fraction=.6,max_grad_norm=10.)
    d=s.inspect(HealthSnapshot(1,.1,.2,1.,.1,.5,.5,.5,.0)); assert d.action=='rollback'
    d=s.inspect(HealthSnapshot(2,.01,.8,1.,.1,.5,.5,.5,.0)); assert d.action=='rollback'


def test_value_clipped_ppo_batch_carries_behavior_values():
    sim,v,t,net=setup_v4(); a=RecurrentPolicyActor(net,t,actor_id='a',policy_version=1);b=RecurrentPolicyActor(copy.deepcopy(net),t,actor_id='b',policy_version=1)
    u=collect_joint_unroll(sim,a,b,unroll_length=5,seed=2).seat_a
    batch=actor_unroll_to_ppo_batch(u,net,t,expected_policy_version=1)
    assert batch.old_values is not None and batch.old_values.shape==batch.returns.shape
    m=recurrent_ppo_step(net,batch,torch.optim.Adam(net.parameters(),lr=1e-4),value_clip_eps=.2)
    assert m.value_loss==m.value_loss

def test_v4_recurrent_bc_supports_privileged_belief_targets():
    from crgod.training.bc_v2 import RecurrentBCBatch, recurrent_bc_step
    from crgod.training.belief import BeliefTargets
    from crgod.opponent_codec import OpponentActionBatch
    from crgod.data import _mask_from_indices
    sim,v,t,net=setup_v4(); f=sim.reset(seed=2); B=1; T=2
    states=[]; opps=[]; masks=[]
    for _ in range(T):
        states.append(t.one(f.seat_a.observation))
        opps.append(OpponentActionBatch.pass_batch(1))
        m,_=_mask_from_indices(f.seat_a.legal_action_indices);masks.append(m.unsqueeze(0))
    V=v.size
    bt=[]
    for _ in range(T):
        bt.append(BeliefTargets(torch.tensor([.5]),torch.zeros(1,V),torch.zeros(1,dtype=torch.long),torch.tensor([False])))
    batch=RecurrentBCBatch(states,torch.zeros(T,B,dtype=torch.long),opps,torch.zeros(T,B,dtype=torch.bool),torch.full((T,B),.5),torch.stack(masks),torch.zeros(T,B,dtype=torch.long),belief_targets=bt)
    m=recurrent_bc_step(net,batch,torch.optim.Adam(net.parameters(),lr=1e-4),belief_weight=.2)
    assert m.loss==m.loss


def test_slow_memory_starts_slow_not_half_overwritten_each_frame():
    sim,v,t,net=setup_v4(); frame=sim.reset(seed=1); tb=t.one(frame.seat_a.observation);z=net.encoder(tb);h=net.initial_belief(1)
    from crgod.opponent_codec import OpponentActionBatch
    bp=net.update_belief(z,torch.zeros(1,dtype=torch.long),OpponentActionBatch.pass_batch(1),torch.tensor([False]),torch.tensor([.5]),h)
    assert float(bp.slow_gate.item())<.2

def test_v4_checkpoint_contract_is_simulator_agnostic_and_binds_model_family():
    from crgod.checkpointing_v4 import RuntimeContractV4,assert_checkpoint_compatible_v4
    c=CardVocabulary.from_card_ids([1,2,3]);e=CardVocabulary.from_card_ids([10,11])
    meta=RuntimeContractV4.build(c,e,'my-simulator@deadbeef').metadata()
    assert_checkpoint_compatible_v4(meta,c,e,'my-simulator@deadbeef')
    try:assert_checkpoint_compatible_v4(meta,c,e,'my-simulator@different')
    except RuntimeError as ex:assert 'simulator_fingerprint' in str(ex)
    else:raise AssertionError('simulator mismatch must fail')

def test_trace_eval_records_trajectory_and_true_outcome():
    from crgod.eval_harness_v4 import run_trace_match,EvalSuiteV4
    sim,v,t,net=setup_v4(); a=RecurrentPolicyActor(net,t,actor_id='a');b=RecurrentPolicyActor(copy.deepcopy(net),t,actor_id='b')
    tr=run_trace_match(ToyJointSimulator(ToyJointConfig(horizon=5)),a,b,seed=1,max_steps=10)
    assert len(tr.decisions)==5 and 0<=tr.outcome_a<=1 and tr.simulator_id
    assert EvalSuiteV4('hidden','hidden',(1,2)).kind=='hidden'


def test_rollout_actor_owns_snapshot_and_requires_explicit_version_sync():
    sim,v,t,net=setup_v4()
    actor=RecurrentPolicyActor(net,t,actor_id='snapshot',policy_version=3)
    # Mutating the learner must not silently mutate the actor snapshot.
    ap=next(actor.model.parameters()).detach().clone()
    with torch.no_grad():
        next(net.parameters()).add_(1.0)
    assert torch.equal(ap,next(actor.model.parameters()).detach())
    frame=sim.reset(seed=9)
    actor.act(frame.seat_a.observation,frame.seat_a.legal_action_indices,
              prev_own_action=0,prev_opp_action=__import__('crgod.contracts',fromlist=['ObservedOpponentActionV1']).ObservedOpponentActionV1.pass_action(),
              prev_opp_known=False,dt_s=0.0)
    try:
        actor.sync_from(net,policy_version=4)
    except RuntimeError as e:
        assert 'mid-memory' in str(e)
    else:
        raise AssertionError('actor sync must not silently mix recurrent states across policy versions')
    actor.reset(); actor.sync_from(net,policy_version=4)
    assert actor.policy_version==4


def test_async_buffer_rejects_future_policy_versions():
    from crgod.training.async_buffer import FreshUnrollBuffer,VersionedItem
    b=FreshUnrollBuffer(capacity=4,max_policy_lag=2)
    try:
        b.push(VersionedItem('x',behavior_version=6),learner_version=5)
    except ValueError as e:
        assert 'newer' in str(e)
    else:
        raise AssertionError('future actor versions must fail closed')


def test_persistent_session_keeps_v4_memory_across_unroll_chunks():
    from crgod.training.selfplay_v3 import SelfPlaySession
    sim=ToyJointSimulator(ToyJointConfig(horizon=20))
    vocab=CardVocabulary.from_card_ids(list(range(10,15))+list(range(20,25)))
    ten=BattleTensorizer(vocab,max_entities=8,max_events=16)
    net=CRGodV4Net(vocab.size,latent_dim=64,fast_belief_dim=32,slow_belief_dim=24,entity_vocab_size=vocab.size)
    a=RecurrentPolicyActor(net,ten,actor_id='a',policy_version=1)
    b=RecurrentPolicyActor(net,ten,actor_id='b',policy_version=1)
    sess=SelfPlaySession(sim,a,b); sess.reset(seed=12)
    u1=sess.collect(unroll_length=4,burn_in_length=2)
    assert not u1.seat_a.terminal
    hidden_before_second=a.hidden.detach().clone()[0]
    u2=sess.collect(unroll_length=4,burn_in_length=2)
    assert torch.allclose(u2.seat_a.initial_hidden,hidden_before_second)
    assert len(u2.seat_a.burnin_steps)==2


def test_hierarchical_head_fuzz_masks_never_prefers_illegal_action():
    sim,v,t,net=setup_v4(); frame=sim.reset(seed=21)
    z=net.encoder(t.one(frame.seat_a.observation)); h=net.initial_belief(1,z.device,z.dtype)
    g=torch.Generator().manual_seed(123)
    for _ in range(32):
        mask=(torch.rand(NUM_ACTIONS,generator=g)<0.02)
        mask[0]=True
        logits,value=net.head(z,h,mask.unsqueeze(0))
        assert torch.isfinite(logits).all() and torch.isfinite(value).all()
        idx=int(logits[0].argmax())
        assert bool(mask[idx])
    mask=torch.zeros(NUM_ACTIONS,dtype=torch.bool); mask[0]=True
    logits,_=net.head(z,h,mask.unsqueeze(0))
    assert int(logits[0].argmax())==0


def test_simulator_blackbox_stress_audit_catches_clock_and_termination_contract():
    from crgod.sim_audit_v4 import stress_audit_simulator
    r=stress_audit_simulator(ToyJointSimulator(ToyJointConfig(horizon=6)),episodes=2,max_steps_per_episode=20,seed=4)
    assert r.terminals==2 and r.steps>=2 and r.max_clock_error_s<1e-9

    class BadClock(ToyJointSimulator):
        def step(self,a,b):
            from dataclasses import replace
            tr=super().step(a,b)
            return replace(tr,elapsed_s=tr.elapsed_s*2)
    try:
        stress_audit_simulator(BadClock(ToyJointConfig(horizon=3)),episodes=1,max_steps_per_episode=5)
    except ValueError as e:
        assert 'clock mismatch' in str(e)
    else:
        raise AssertionError('clock/discount mismatch must fail closed')


def test_replay_optional_privileged_sidecar_feeds_belief_targets(tmp_path):
    from crgod.sequence import Episode, build_recurrent_bc_batch
    from crgod.replay_io import save_jsonl,load_jsonl
    from crgod.contracts import ActionV2,ObservedOpponentActionV1,TransitionV1
    from crgod.data import _mask_from_indices
    sim=ToyJointSimulator(ToyJointConfig(horizon=6)); frame=sim.reset(seed=3)
    trs=[]; privileged=[]
    for _ in range(6):
        privileged.append(frame.privileged_state)
        a=frame.seat_a.legal_action_indices[1]; b=frame.seat_b.legal_action_indices[2]
        step=sim.step(a,b)
        from crgod.action_codec import decode_action
        trs.append(TransitionV1(frame.seat_a.observation,decode_action(a),step.action_b_observed_by_a,step.reward_a,
                                step.next_frame.seat_a.observation,step.done,step.action_b_known_to_a,
                                frame.seat_a.legal_action_indices,step.next_frame.seat_a.legal_action_indices))
        frame=step.next_frame
    ep=Episode(tuple(trs),'priv',tuple(privileged)); ep.validate()
    path=tmp_path/'p.jsonl'; save_jsonl([ep],path); loaded=load_jsonl(path)
    assert loaded[0].privileged_states is not None and len(loaded[0].privileged_states)==6
    ids=list(range(10,15))+list(range(20,25)); vocab=CardVocabulary.from_card_ids(ids)
    ten=BattleTensorizer(vocab,max_entities=8,max_events=16)
    batch=build_recurrent_bc_batch(loaded,ten,batch_size=1,train_steps=3,burn_in=1,rng=random.Random(1))
    assert batch.belief_targets is not None and len(batch.belief_targets)==4
    assert bool(batch.belief_targets[0].hand_presence[:,vocab.encode(20)].any())

def test_terminal_objective_is_explicit_and_never_inferred_from_shaped_reward():
    from dataclasses import replace
    from crgod.envs.toy_joint import ToyJointSimulator,ToyJointConfig
    sim=ToyJointSimulator(ToyJointConfig(horizon=2)); frame=sim.reset(seed=1)
    r1=sim.step(0,0)
    try: replace(r1,outcome_a=.5).validate()
    except ValueError: pass
    else: raise AssertionError('nonterminal step must not expose final outcome')
    r2=sim.step(0,0)
    assert r2.done and r2.outcome_a is not None
    try: replace(r2,outcome_a=None).validate()
    except ValueError: pass
    else: raise AssertionError('terminal step must provide explicit outcome')


def test_replay_loader_rejects_noncontiguous_episode_ids(tmp_path):
    from crgod.data import collect_toy_expert
    from crgod.sequence import split_episodes
    from crgod.replay_io import save_jsonl,load_jsonl
    eps=split_episodes(collect_toy_expert(3,seed=5))
    p=tmp_path/'x.jsonl';save_jsonl(eps,p)
    lines=p.read_text().splitlines()
    # Move the first row of episode 0 after episode 1 begins, so episode 0
    # reappears later and chronological train/val/test order is ambiguous.
    e1=next(i for i,x in enumerate(lines) if '"episode_id":"1"' in x)
    bad=lines[1:e1+1]+[lines[0]]+lines[e1+1:]
    q=tmp_path/'bad.jsonl';q.write_text('\n'.join(bad)+'\n')
    try: load_jsonl(q)
    except ValueError: pass
    else: raise AssertionError('non-contiguous episode ids must be rejected')
