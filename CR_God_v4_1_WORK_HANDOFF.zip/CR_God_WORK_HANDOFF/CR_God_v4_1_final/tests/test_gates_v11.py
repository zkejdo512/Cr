from crgod.training.gates import gate_bc,gate_mask_coverage,gate_world,gate_world_rollout,gate_short_rl

def test_gates():
    assert gate_bc(.8).passed and not gate_bc(.2).passed
    assert gate_mask_coverage(1.).passed and not gate_mask_coverage(.5).passed
    assert gate_world(.7,1.).passed and not gate_world(.95,1.).passed
    assert gate_world_rollout(.1,.2).passed and not gate_world_rollout(.1,.8).passed
    assert gate_short_rl(.6,.59,.02).passed and not gate_short_rl(.6,.5,.02).passed
