import math, sys, textwrap
from pathlib import Path
import torch

from crgod.action_codec import decode_action
from crgod.checkpointing import RuntimeContract, assert_checkpoint_compatible
from crgod.contracts import OBSERVATION_SCHEMA_VERSION, TransitionV1
from crgod.data import _mask_from_indices
from crgod.envs.toy_duel import ToyDuelEnv, ToyConfig
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.supervisor import AtomicCheckpointStore
from crgod.tensorizer import BattleTensorizer
from crgod.training.ppo_v2 import recurrent_ppo_step
from crgod.training.rollout_v22 import collect_complete_episode, build_ppo_chunks
from crgod.vocab import CardVocabulary


class ToyAdapter:
    def __init__(self,horizon=6,seed=0):
        self.horizon=horizon; self.seed=seed; self.env=None; self.obs=None; self.legal=None
    def reset(self,seed=None):
        seed=self.seed if seed is None else seed
        self.env=ToyDuelEnv(ToyConfig(self.horizon,seed)); self.obs=self.env.state()
        self.legal=tuple(self.env.legal_action_indices()); mask,_=_mask_from_indices(self.legal)
        return self.obs,mask.numpy(),self.env.true_state()
    def step(self,idx):
        state=self.obs; legal=self.legal; action=decode_action(int(idx)); opp=self.env.opponent_action()
        nxt,reward,done,_=self.env.step(action,opp)
        next_legal=tuple(self.env.legal_action_indices())
        tr=TransitionV1(state,action,opp,reward,nxt,done,True,legal,next_legal)
        self.obs=nxt; self.legal=next_legal
        return tr


def _toy_stack(horizon=6):
    vocab=CardVocabulary.from_card_ids(list(range(5))+list(range(100,105)))
    ten=BattleTensorizer(vocab,8,16); net=CRGodV2Net(vocab.size)
    return vocab,ten,net


def test_schema_constant_tensorizes_and_project_version_does_not():
    vocab,ten,_=_toy_stack(); env=ToyDuelEnv(ToyConfig(2,1)); obs=env.state()
    assert obs.version==OBSERVATION_SCHEMA_VERSION
    ten.one(obs)
    bad=type(obs)('2.1',obs.t_s,obs.own_elixir,obs.own_towers,obs.opponent_towers,obs.hand,obs.next_card,obs.entities,obs.recent_events,obs.source)
    try: ten.one(bad)
    except ValueError as e: assert 'observation schema' in str(e)
    else: raise AssertionError('project version must not masquerade as observation schema')


def test_onpolicy_collector_builds_exact_recurrent_chunks_and_ppo_updates():
    vocab,ten,net=_toy_stack(); adapter=ToyAdapter(horizon=7,seed=4)
    ep=collect_complete_episode(adapter,net,ten,seed=4,max_steps=20)
    assert len(ep.steps)==7 and ep.steps[-1].done
    assert ep.steps[0].prev_opponent_known is False
    assert ep.steps[1].prev_opponent_known is True
    chunks=build_ppo_chunks([ep],ten,seq_len=3)
    assert len(chunks)==3 and chunks[1].initial_hidden is not None
    assert float(chunks[1].initial_hidden.abs().sum())>0
    opt=torch.optim.Adam(net.parameters(),lr=1e-4)
    m=recurrent_ppo_step(net,chunks[1],opt,entropy_coef=0.0)
    assert all(math.isfinite(float(x)) for x in m.__dict__.values())


def test_checkpoint_runtime_contract_catches_same_size_wrong_vocab(tmp_path):
    a=CardVocabulary.from_card_ids([10,20,30]); b=CardVocabulary.from_card_ids([11,20,30])
    assert a.size==b.size and a.fingerprint()!=b.fingerprint()
    meta=RuntimeContract.build(a,'abc123').metadata()
    assert_checkpoint_compatible(meta,a,'abc123',True)
    try: assert_checkpoint_compatible(meta,b,'abc123',True)
    except RuntimeError as e: assert 'vocabulary fingerprint' in str(e)
    else: raise AssertionError('same-size different vocabulary must be rejected')


def test_atomic_checkpoint_restores_model_and_optimizer(tmp_path):
    model=torch.nn.Linear(3,2); opt=torch.optim.Adam(model.parameters(),lr=1e-3)
    x=torch.randn(4,3); loss=model(x).square().mean(); loss.backward(); opt.step()
    expected={k:v.detach().clone() for k,v in model.state_dict().items()}
    store=AtomicCheckpointStore(tmp_path); store.save('best',model,opt,{'step':7})
    with torch.no_grad():
        for p in model.parameters(): p.add_(10)
    meta=store.load('best',model,opt)
    assert meta['step']==7
    for k,v in model.state_dict().items(): assert torch.allclose(v,expected[k])


def _write_fake_hasty(root:Path,patched:bool):
    (root/'sim').mkdir(parents=True); (root/'sim'/'__init__.py').write_text('')
    fields=[
        'ability_buff','ability_buff_ms','ability_dash_range_mt','ability_spawn_character','ability_area_damage',
        'ability_deploy_character','ability_lane_switch','ability_link_target','ability_level_adjustments',
        'ability_taunt_radius_mt','ability_hurl_radius_mt','ability_siege_range_mt','ability_split_character',
        'ability_reroll_range_mt','ability_spin_seek_radius_mt','ability_reinforcement_character',
        'ability_transform_character','ability_warp_backward_mt','ability_warp_to_target_speed',
        'ability_temporary_character','ability_summon_character','ability_extra_projectiles','ability_drop_character']
    pred=' or '.join(f'getattr(entity,{f!r},0)' for f in fields) if patched else 'entity.ability_buff'
    (root/'sim'/'env.py').write_text(textwrap.dedent(f'''
        import numpy as np
        GRID_W,GRID_H=18,32; TILES=576; CARD_ACTIONS=2305; ABILITY_SLOTS=16; ACTIONS=2321; DECIDE_EVERY_MS=500
        def ability_entities(match,side):
            return [entity for entity in match.battle.entities.values() if {pred}]
        class ClashEnv:
            def __init__(self,seed=0,**kw): self.seed=seed
            @staticmethod
            def decode(a):
                if a<=0:return None
                if a>=CARD_ACTIONS:return ('ability',a-CARD_ACTIONS)
                z=a-1; slot,cell=divmod(z,TILES); y,x=divmod(cell,GRID_W); return slot,x,y
            @staticmethod
            def encode(slot,x,y): return 1+slot*TILES+y*GRID_W+x
            @staticmethod
            def encode_ability(rank): return CARD_ACTIONS+rank
            def reset(self,seed=None):
                return {{'planes':np.zeros((8,32,18),np.float32),'scalars':np.zeros(47,np.float32)}},{{'action_mask':np.ones(ACTIONS,dtype=bool)}}
            def step(self,a): return self.reset()[0],0.0,False,False,self.reset()[1]
    '''))
    if patched:
        tb='''\n    def _tiebreak(self):\n        towers=[self.towers[1][lane] for lane in ("left","right","king")]\n        return min(float(t.hitpoints) for t in towers if t.alive)\n'''
    else:
        tb='''\n    def _tiebreak(self):\n        towers=[self.towers[1][lane] for lane in ("left","right")]\n        return min(t.hp_fraction for t in towers if t.alive)\n'''
    (root/'sim'/'match.py').write_text('class Match:'+tb)


def test_hasty_source_audit_fails_old_source_and_accepts_hardened_source(tmp_path):
    from crgod.adapters.hasty import HastyRuntime
    old=tmp_path/'old'; _write_fake_hasty(old,False)
    for k in list(sys.modules):
        if k=='sim' or k.startswith('sim.'): del sys.modules[k]
    r=HastyRuntime(old).source_audit(); assert not r.ok and not r.ability_enumeration_ok and not r.tiebreak_absolute_hp_ok
    new=tmp_path/'new'; _write_fake_hasty(new,True)
    for k in list(sys.modules):
        if k=='sim' or k.startswith('sim.'): del sys.modules[k]
    r=HastyRuntime(new).source_audit(); assert r.ok and not r.missing_ability_fields


def test_entity_vocab_is_separate_from_playable_card_vocab():
    from crgod.contracts import EntityState
    vocab=CardVocabulary.from_card_ids([1,2,3,4,5]); entity_vocab=CardVocabulary.from_card_ids([1,2,999])
    env=ToyDuelEnv(ToyConfig(2,3)); obs=env.state()
    obs2=type(obs)(obs.version,obs.t_s,obs.own_elixir,obs.own_towers,obs.opponent_towers,obs.hand,obs.next_card,
                   (EntityState(1,'opponent',999,'troop',.5,.5,100,100),),obs.recent_events,obs.source)
    ten=BattleTensorizer(vocab,8,8,entity_vocab=entity_vocab); b=ten.one(obs2)
    assert int(b.entity_card_ids[0,0])==entity_vocab.encode(999)
    assert int(b.entity_card_ids[0,0])!=vocab.encode(999)


def test_checkpoint_contract_also_binds_entity_vocabulary():
    card=CardVocabulary.from_card_ids([1,2,3]); e1=CardVocabulary.from_card_ids([10,20]); e2=CardVocabulary.from_card_ids([11,20])
    meta=RuntimeContract.build(card,'abc',e1).metadata()
    assert_checkpoint_compatible(meta,card,'abc',True,e1)
    try: assert_checkpoint_compatible(meta,card,'abc',True,e2)
    except RuntimeError as e: assert 'entity vocabulary fingerprint' in str(e)
    else: raise AssertionError('entity vocabulary mismatch must be rejected')


def test_chronological_episode_split_never_crosses_match_boundaries():
    from crgod.data import collect_toy_expert
    from crgod.sequence import split_episodes
    from crgod.training.replay_split import chronological_episode_split
    eps=split_episodes(collect_toy_expert(10,seed=1)); s=chronological_episode_split(eps,.7,.2)
    assert len(s.train)==7 and len(s.val)==2 and len(s.test)==1
    ids=[{e.episode_id for e in x} for x in (s.train,s.val,s.test)]
    assert not ids[0]&ids[1] and not ids[0]&ids[2] and not ids[1]&ids[2]
