import copy
import random
import torch

from crgod.envs.toy_joint import ToyJointSimulator, ToyJointConfig
from crgod.sim_protocol import audit_training_simulator, RewardComponents
from crgod.vocab import CardVocabulary
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.training.selfplay_v3 import RecurrentPolicyActor, collect_joint_unroll
from crgod.training.vtrace import vtrace_targets, recurrent_vtrace_step
from crgod.training.async_buffer import FreshUnrollBuffer, VersionedItem
from crgod.training.rewarding import RewardMixer, RewardAnneal, DenseRewardWeights
from crgod.training.regularizers import masked_policy_kl
from crgod.training.league_manager_v3 import LeagueManagerV3, SnapshotRule
from crgod.league_v2 import LeagueMember
from crgod.training.curriculum_v3 import TrainingCurriculumV3, StageEvidence, TrainingStage


def setup():
    sim=ToyJointSimulator(ToyJointConfig(horizon=8))
    # toy hidden/next cards included so belief heads are never UNK by construction
    vocab=CardVocabulary.from_card_ids(list(range(10,15))+list(range(20,25)))
    ten=BattleTensorizer(vocab,max_entities=8,max_events=16)
    net=CRGodV2Net(vocab.size,latent_dim=64,belief_dim=48,entity_vocab_size=vocab.size)
    return sim,vocab,ten,net


def test_sim_protocol_and_joint_selfplay_are_causal_and_symmetric():
    sim,v,t,net=setup(); f=audit_training_simulator(sim)
    assert f.seat_a.observation.hand[0].card_id==10 and f.seat_b.observation.hand[0].card_id==20
    a=RecurrentPolicyActor(net,t,actor_id='a',policy_version=3); b=RecurrentPolicyActor(copy.deepcopy(net),t,actor_id='b',policy_version=2)
    u=collect_joint_unroll(sim,a,b,unroll_length=4,seed=7)
    assert len(u.seat_a.steps)==4 and len(u.seat_b.steps)==4
    assert u.seat_a.steps[0].prev_opponent_known is False
    # Current interval's opponent action appears only at the following recurrent input.
    assert u.seat_a.steps[1].prev_opponent_known is True
    assert u.seat_a.behavior_version==3 and u.seat_b.behavior_version==2


def test_vtrace_identity_matches_multistep_return_when_onpolicy_gamma_one():
    behavior=torch.log(torch.tensor([.5,.5])); target=behavior.clone()
    r=torch.tensor([1.,2.]); v=torch.tensor([0.,0.]); done=torch.tensor([False,True]); dt=torch.tensor([.5,.5])
    out=vtrace_targets(behavior,target,r,v,torch.tensor(0.),done,dt,gamma=1.0,clip_rho=1.,clip_pg_rho=1.,clip_c=1.)
    assert torch.allclose(out.vs,torch.tensor([3.,2.]),atol=1e-6)
    assert torch.allclose(out.rhos,torch.ones(2),atol=1e-6)


def test_recurrent_vtrace_updates_network_from_policy_lagged_actor():
    sim,v,t,net=setup(); behavior=copy.deepcopy(net)
    actor=RecurrentPolicyActor(behavior,t,actor_id='old',policy_version=1); opp=RecurrentPolicyActor(copy.deepcopy(behavior),t,actor_id='opp',policy_version=1)
    u=collect_joint_unroll(sim,actor,opp,unroll_length=6,seed=2).seat_a
    with torch.no_grad():
        for p in net.parameters(): p.add_(torch.randn_like(p)*1e-4)
    before=net.head.slot_head.weight.detach().clone(); opt=torch.optim.Adam(net.parameters(),lr=1e-4)
    m=recurrent_vtrace_step(net,u,t,opt)
    assert m.loss==m.loss and m.mean_rho>0 and not torch.equal(before,net.head.slot_head.weight.detach())


def test_fresh_buffer_rejects_stale_policy_lag():
    b=FreshUnrollBuffer(capacity=4,max_policy_lag=2)
    assert not b.push(VersionedItem('x',behavior_version=1),learner_version=4)
    assert b.push(VersionedItem('y',behavior_version=3),learner_version=4)
    assert len(b)==1 and b.dropped_stale==1


def test_reward_shaping_anneals_to_true_terminal_objective():
    mixer=RewardMixer(DenseRewardWeights(tower_damage=1.,crown=1.,elixir=1.,tactical=1.),RewardAnneal(0,100,1.,0.))
    c=RewardComponents(terminal=.7,tower_damage=.1,crown=.2,elixir=.3,tactical=.4)
    assert mixer(c,0)>.7
    assert abs(mixer(c,100)-.7)<1e-7


def test_masked_policy_kl_ignores_illegal_logits():
    s=torch.tensor([[1.,2.,999.]])
    teacher=torch.tensor([[2.,1.,-999.]])
    mask=torch.tensor([[True,True,False]])
    k1=masked_policy_kl(s,teacher,mask)
    s2=s.clone(); s2[0,2]=-99999.
    k2=masked_policy_kl(s2,teacher,mask)
    assert torch.allclose(k1,k2)


def test_league_manager_keeps_history_and_exploiter_roles():
    lm=LeagueManagerV3(LeagueMember('main','m','main'),snapshot_rule=SnapshotRule(max_steps_between_snapshots=10),history_mix=1.0)
    lm.progress.learner_steps=10
    hist=lm.register_snapshot('h')
    exp=LeagueMember('x','x','exploiter'); lm.add_exploiter(exp)
    assert hist.role=='historical' and 'x' in lm.league.members
    pick=lm.choose_opponent(random.Random(1)); assert pick.role=='historical'


def test_curriculum_is_fail_closed():
    c=TrainingCurriculumV3()
    try:c.promote(StageEvidence(10,.2,0.,0.))
    except RuntimeError:pass
    else:raise AssertionError('insufficient evidence must block promotion')
    nxt=c.promote(StageEvidence(120,.03,-.01,0.)); assert nxt==TrainingStage.PPO_BOOTSTRAP

def test_generic_joint_unroll_converts_to_strict_ppo_batch():
    from crgod.training.ppo_from_unroll import actor_unroll_to_ppo_batch
    sim,v,t,net=setup(); a=RecurrentPolicyActor(net,t,actor_id='a',policy_version=7); b=RecurrentPolicyActor(copy.deepcopy(net),t,actor_id='b',policy_version=7)
    u=collect_joint_unroll(sim,a,b,unroll_length=5,seed=3).seat_a
    batch=actor_unroll_to_ppo_batch(u,net,t,expected_policy_version=7)
    assert batch.actions.shape==(5,1) and torch.isfinite(batch.advantages).all()
    try:actor_unroll_to_ppo_batch(u,net,t,expected_policy_version=8)
    except RuntimeError:pass
    else:raise AssertionError('PPO must reject stale behavior version')


def test_planner_target_distills_only_searched_legal_actions():
    from crgod.training.planner_distill import planner_target_from_q,planner_distillation_loss
    from crgod.action_codec import NUM_ACTIONS
    mask=torch.zeros(NUM_ACTIONS,dtype=torch.bool); mask[[0,10,20]]=True
    target=planner_target_from_q({10:1.0,20:2.0},mask,temperature=.5)
    assert abs(float(target.probabilities.sum())-1)<1e-6 and target.probabilities[20]>target.probabilities[10] and target.probabilities[0]==0
    logits=torch.zeros(NUM_ACTIONS,requires_grad=True); loss=planner_distillation_loss(logits,target); loss.backward(); assert torch.isfinite(logits.grad).all()


def test_v3_training_gate_fails_closed():
    from crgod.training.gates_v3 import TrainingReadinessV3
    r=TrainingReadinessV3(regression_tests_pass=True,simulator_contract_pass=True)
    assert not r.ready and len(r.blockers())>5
    try:r.assert_ready()
    except RuntimeError:pass
    else:raise AssertionError('v3 gate must fail closed')

def test_paired_seat_swap_eval_runs_without_seat_leakage():
    from crgod.evaluation_v3 import paired_seat_swap_eval
    sim,v,t,net=setup()
    def sf():return ToyJointSimulator(ToyJointConfig(horizon=6))
    def af():return RecurrentPolicyActor(copy.deepcopy(net),t,actor_id='p',policy_version=0)
    rows=paired_seat_swap_eval(sf,af,af,[1,2,3],max_steps=20)
    assert len(rows)==3
    assert all(0<=x.candidate_score<=1 for x in rows)

def test_selfplay_session_preserves_long_match_memory_across_unrolls():
    from crgod.training.selfplay_v3 import SelfPlaySession
    sim,v,t,net=setup(); sim=ToyJointSimulator(ToyJointConfig(horizon=10))
    a=RecurrentPolicyActor(net,t,actor_id='a',policy_version=1); b=RecurrentPolicyActor(copy.deepcopy(net),t,actor_id='b',policy_version=1)
    sess=SelfPlaySession(sim,a,b); sess.reset(seed=9)
    u1=sess.collect(unroll_length=3); assert not u1.seat_a.terminal
    last_t=u1.seat_a.steps[-1].state.t_s; last_action=u1.seat_a.final_prev_own_action
    u2=sess.collect(unroll_length=3); assert u2.seat_a.steps[0].state.t_s>last_t
    assert u2.seat_a.steps[0].prev_own_action==last_action
    assert u2.seat_a.steps[0].prev_opponent_known is True

def test_vtrace_burnin_prefix_rebuilds_recurrent_state_across_chunks():
    from crgod.training.selfplay_v3 import SelfPlaySession
    sim,v,t,net=setup(); sim=ToyJointSimulator(ToyJointConfig(horizon=14))
    behavior=copy.deepcopy(net)
    a=RecurrentPolicyActor(behavior,t,actor_id='old',policy_version=1); b=RecurrentPolicyActor(copy.deepcopy(behavior),t,actor_id='opp',policy_version=1)
    sess=SelfPlaySession(sim,a,b); sess.reset(seed=12)
    u1=sess.collect(unroll_length=4,burn_in_length=3)
    assert len(u1.seat_a.burnin_steps)==0
    u2=sess.collect(unroll_length=4,burn_in_length=3)
    assert len(u2.seat_a.burnin_steps)==3 and u2.seat_a.burnin_initial_hidden is not None
    # learner weights may have moved; burn-in must still produce finite V-trace update
    with torch.no_grad():
        for p in net.parameters(): p.add_(torch.randn_like(p)*5e-5)
    m=recurrent_vtrace_step(net,u2.seat_a,t,torch.optim.Adam(net.parameters(),lr=1e-4))
    assert m.loss==m.loss and m.mean_rho>0

def test_ppo_bootstrap_is_frozen_at_rollout_time_not_recomputed_by_learner():
    from crgod.training.ppo_from_unroll import actor_unroll_to_ppo_batch
    sim,v,t,net=setup(); sim=ToyJointSimulator(ToyJointConfig(horizon=12))
    a=RecurrentPolicyActor(net,t,actor_id='a',policy_version=11)
    b=RecurrentPolicyActor(copy.deepcopy(net),t,actor_id='b',policy_version=11)
    u=collect_joint_unroll(sim,a,b,unroll_length=4,seed=21).seat_a
    assert not u.terminal and u.behavior_bootstrap_value==u.behavior_bootstrap_value
    batch1=actor_unroll_to_ppo_batch(u,net,t,expected_policy_version=11)
    with torch.no_grad():
        for p in net.parameters(): p.add_(torch.randn_like(p)*0.1)
    batch2=actor_unroll_to_ppo_batch(u,net,t,expected_policy_version=11)
    assert torch.allclose(batch1.advantages,batch2.advantages)
    assert torch.allclose(batch1.returns,batch2.returns)
