import copy
import random
import torch

from crgod.action_codec import NUM_ACTIONS, ABILITY_BASE, encode_action
from crgod.contracts import ActionV2
from crgod.data import collect_toy_expert, build_card_vocab, sample_transition_batch
from crgod.tensorizer import BattleTensorizer
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.models.hierarchical_policy import HierarchicalPolicyValueHead
from crgod.opponent_codec import OpponentActionBatch, PASS_TILE
from crgod.planning import FastSlowPlanner, RolloutEstimate
from crgod.league_v2 import PFSPLeague, LeagueMember
from crgod.training.ppo_v2 import RecurrentPPOBatch, recurrent_ppo_step
from crgod.training.gates_v2 import V2ReadinessReport


def setup(n=8):
    data=collect_toy_expert(n)
    vocab=build_card_vocab(data)
    ten=BattleTensorizer(vocab,8,16)
    return data,vocab,ten


def test_hierarchical_head_preserves_canonical_action_space_and_mask():
    d,v,t=setup(2); b=sample_transition_batch(d,t,8); net=CRGodV2Net(v.size)
    z=net.encoder(b.state); h=net.initial_belief(z.shape[0],z.device,z.dtype)
    comp,val=net.head.components(z,h,b.legal_mask)
    assert comp.flat_logits.shape==(z.shape[0],NUM_ACTIONS)
    assert comp.tile_logits.shape==(z.shape[0],4,18*32)
    assert comp.ability_logits.shape==(z.shape[0],16)
    assert torch.all(comp.flat_logits[~b.legal_mask] < -1e8)
    assert val.shape==(z.shape[0],)


def test_belief_unknown_action_does_not_leak_placeholder_card_or_tile():
    d,v,t=setup(2); b=sample_transition_batch(d,t,4); net=CRGodV2Net(v.size)
    z=net.encoder(b.state); h=net.initial_belief(4,z.device,z.dtype)
    own=torch.zeros(4,dtype=torch.long); known=torch.zeros(4,dtype=torch.bool); dt=torch.ones(4)
    a=OpponentActionBatch(torch.tensor([False]*4),torch.tensor([min(v.size-1,2)]*4),torch.tensor([13]*4))
    p1=net.belief.step(z,own,a,known,dt,h)
    a2=OpponentActionBatch(torch.tensor([True]*4),torch.zeros(4,dtype=torch.long),torch.full((4,),PASS_TILE,dtype=torch.long))
    p2=net.belief.step(z,own,a2,known,dt,h)
    assert torch.allclose(p1.hidden,p2.hidden,atol=1e-6)


def test_belief_memory_changes_with_known_opponent_history():
    d,v,t=setup(2); b=sample_transition_batch(d,t,4); net=CRGodV2Net(v.size)
    z=net.encoder(b.state); h=net.initial_belief(4,z.device,z.dtype); own=torch.zeros(4,dtype=torch.long); dt=torch.ones(4); known=torch.ones(4,dtype=torch.bool)
    a_left=OpponentActionBatch(torch.zeros(4,dtype=torch.bool),torch.ones(4,dtype=torch.long),torch.tensor([10]*4))
    a_right=OpponentActionBatch(torch.zeros(4,dtype=torch.bool),torch.ones(4,dtype=torch.long),torch.tensor([500]*4))
    l=net.belief.step(z,own,a_left,known,dt,h).hidden
    r=net.belief.step(z,own,a_right,known,dt,h).hidden
    assert not torch.allclose(l,r)


def test_fast_slow_planner_can_override_fast_action_only_with_legal_candidate():
    logits=torch.full((NUM_ACTIONS,),-20.0); legal=torch.zeros(NUM_ACTIONS,dtype=torch.bool); legal[0]=True; legal[10]=True; legal[20]=True
    logits[10]=2.0; logits[20]=1.9; logits[0]=0.0
    planner=FastSlowPlanner(top_k=3,margin_threshold=.2,entropy_threshold=0.0,uncertainty_penalty=.5,prior_weight=0.0)
    def rollout(a):
        return RolloutEstimate(2.0 if a==20 else 0.5,0.0,8)
    tr=planner.decide(logits,legal,rollout)
    assert tr.fast_action==10 and tr.used_slow and tr.chosen_action==20
    assert all(legal[x.action_index] for x in tr.candidates)
    assert 'chosen_action' in tr.to_json()


def test_pfsp_prefers_a_known_exploiter_that_main_loses_to():
    L=PFSPLeague(exploiter_multiplier=2.0)
    L.add(LeagueMember('main','m.pt','main'))
    L.add(LeagueMember('easy','e.pt','historical'))
    L.add(LeagueMember('exploit','x.pt','exploiter'))
    for _ in range(20):
        L.record('main','easy',1.0); L.record('main','exploit',0.0)
    rng=random.Random(7); picks=[L.sample_opponent('main',rng).member_id for _ in range(200)]
    assert picks.count('exploit') > picks.count('easy') * 3
    assert L.worst_matchup('main')[0]=='exploit'


def _old_sequence_stats(net, states, prev_own, prev_opp, known, dt, masks, actions):
    B=actions.shape[1]; h=net.initial_belief(B,actions.device); lps=[]; vals=[]
    with torch.no_grad():
        for i,s in enumerate(states):
            z=net.encoder(s); bp=net.update_belief(z,prev_own[i],prev_opp[i],known[i],dt[i],h); h=bp.hidden
            logits,v=net.head(z,h,masks[i]); dist=torch.distributions.Categorical(logits=logits); lps.append(dist.log_prob(actions[i])); vals.append(v)
    return torch.stack(lps),torch.stack(vals)


def test_recurrent_ppo_updates_encoder_belief_and_hierarchical_head():
    d,v,t=setup(3); net=CRGodV2Net(v.size); T=3; B=2; states=[]; masks=[]; actions=[]; opps=[]
    for step in range(T):
        xs=[d[step],d[step+3]]; states.append(t.batch([x.state for x in xs]))
        sb=sample_transition_batch(xs,t,2); masks.append(sb.legal_mask); actions.append(sb.own_action); opps.append(sb.opp_action)
    masks=torch.stack(masks); actions=torch.stack(actions)
    prev_own=torch.zeros(T,B,dtype=torch.long); known=torch.ones(T,B,dtype=torch.bool); dt=torch.ones(T,B)
    old_lp,old_v=_old_sequence_stats(net,states,prev_own,opps,known,dt,masks,actions)
    batch=RecurrentPPOBatch(states,prev_own,opps,known,dt,masks,actions,old_lp,
                            torch.tensor([[-1.,1.],[.5,-.5],[1.,-1.]]),old_v.detach()+.1)
    before_enc=copy.deepcopy(net.encoder.fuse[-2].weight.detach()); before_bel=copy.deepcopy(net.belief.gru.weight_hh.detach()); before_head=copy.deepcopy(net.head.slot_head.weight.detach())
    opt=torch.optim.Adam(net.parameters(),lr=3e-4); m=recurrent_ppo_step(net,batch,opt)
    assert m.loss==m.loss
    assert not torch.equal(before_enc,net.encoder.fuse[-2].weight.detach())
    assert not torch.equal(before_bel,net.belief.gru.weight_hh.detach())
    assert not torch.equal(before_head,net.head.slot_head.weight.detach())


def test_v2_paid_gate_fails_closed():
    r=V2ReadinessReport(v12_regression_tests_pass=True,recurrent_belief_smoke_pass=True)
    assert len(r.blockers())>=5
    try:
        r.assert_paid_training_ready()
    except RuntimeError as e:
        assert 'paid training blocked' in str(e)
    else:
        raise AssertionError('gate must fail closed')


def test_privileged_belief_targets_are_targets_only_and_correct_side():
    from crgod.training.belief import targets_from_true_states
    from crgod.envs.toy_duel import ToyDuelEnv, ToyConfig
    env=ToyDuelEnv(ToyConfig(5,1)); ts=env.true_state()
    d,v,t=setup(1)
    # extend vocab with the hidden toy cards for supervised belief labels
    from crgod.vocab import CardVocabulary
    vv=CardVocabulary.from_card_ids(list(range(5))+list(range(100,105)))
    y=targets_from_true_states([ts],vv,'self')
    assert abs(float(y.opponent_elixir[0])-.925)<1e-6
    assert sum(int(y.hand_presence[0,vv.encode(i)].item()) for i in range(100,104))==4
    assert int(y.next_card[0])==vv.encode(104)


def test_stateful_agent_keeps_belief_and_never_accepts_true_state():
    from crgod.agent_v2 import CRGodV2Agent
    from crgod.envs.toy_duel import ToyDuelEnv, ToyConfig
    from crgod.data import _mask_from_indices
    d,v,t=setup(2); net=CRGodV2Net(v.size); agent=CRGodV2Agent(net,t)
    env=ToyDuelEnv(ToyConfig(5,1)); obs=env.state(); mask,_=_mask_from_indices(tuple(env.legal_action_indices()))
    oa=env.opponent_action(); first=agent.decide(obs,mask,oa,True,1.0)
    h1=agent.hidden.clone(); second=agent.decide(obs,mask,oa,True,1.0); h2=agent.hidden.clone()
    assert first.action_index>=0 and second.action_index>=0 and not torch.allclose(h1,h2)
    try:
        agent.decide(env.true_state(),mask,oa,True,1.0)
    except TypeError:
        pass
    else:
        raise AssertionError('agent must reject privileged TrueBattleState')


def test_belief_supervision_refuses_observed_only_incomplete_vocab():
    from crgod.training.belief import targets_from_true_states
    from crgod.envs.toy_duel import ToyDuelEnv, ToyConfig
    env=ToyDuelEnv(ToyConfig(5,1)); ts=env.true_state()
    d,v,t=setup(1)  # observed-only toy vocab excludes hidden 100..104
    try:
        targets_from_true_states([ts],v,'self')
    except RuntimeError as e:
        assert 'belief training vocabulary is incomplete' in str(e)
    else:
        raise AssertionError('incomplete hidden-card vocabulary must be rejected')


def test_recurrent_bc_trains_memory_from_expert_sequences():
    from crgod.training.bc_v2 import RecurrentBCBatch, recurrent_bc_step
    d,v,t=setup(3); net=CRGodV2Net(v.size); T=3; B=2; states=[]; masks=[]; actions=[]; opps=[]
    for step in range(T):
        xs=[d[step],d[step+3]]; states.append(t.batch([x.state for x in xs])); sb=sample_transition_batch(xs,t,2)
        masks.append(sb.legal_mask); actions.append(sb.own_action); opps.append(sb.opp_action)
    batch=RecurrentBCBatch(states,torch.zeros(T,B,dtype=torch.long),opps,torch.ones(T,B,dtype=torch.bool),
                           torch.ones(T,B),torch.stack(masks),torch.stack(actions))
    before=net.belief.gru.weight_ih.detach().clone(); opt=torch.optim.Adam(net.parameters(),lr=3e-4)
    m=recurrent_bc_step(net,batch,opt)
    assert m.loss==m.loss and not torch.equal(before,net.belief.gru.weight_ih.detach())


def test_gae_respects_terminal_boundary():
    from crgod.training.ppo_v2 import compute_gae
    r=torch.tensor([[1.0],[1.0],[10.0]]); v=torch.zeros_like(r); d=torch.tensor([[False],[True],[False]])
    adv,ret=compute_gae(r,v,d,torch.tensor([2.0]),gamma=1.0,lam=1.0)
    # terminal at t=1 prevents the large t=2 reward from leaking backward.
    assert float(ret[1,0])==1.0 and float(ret[0,0])==2.0 and float(ret[2,0])==12.0
