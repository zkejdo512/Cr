import random, sys, textwrap
from pathlib import Path
import torch

from crgod.contracts import ObservedOpponentActionV1
from crgod.data import collect_toy_expert, build_card_vocab
from crgod.sequence import split_episodes, build_recurrent_bc_batch
from crgod.tensorizer import BattleTensorizer
from crgod.opponent_codec import (encode_observed_action, OPP_PASS, OPP_PLAY_CARD,
                                  OPP_ABILITY, PASS_TILE)
from crgod.models.crgod_v2 import CRGodV2Net
from crgod.replay_io import save_jsonl, load_jsonl
from crgod.supervisor import TrainingSupervisor, TrainingSnapshot, Decision
from crgod.evaluation_v2 import PairedOutcome, paired_ab_gate


def _episode_and_tensorizer():
    data=collect_toy_expert(1,seed=77)
    eps=split_episodes(data)
    vocab=build_card_vocab(data)
    return eps, BattleTensorizer(vocab,8,16), vocab


def test_recurrent_sequence_is_causally_shifted_and_has_burnin():
    eps,ten,vocab=_episode_and_tensorizer(); ep=eps[0]
    # Use an exact-length synthetic slice so sampling start is deterministic.
    total=min(4,len(ep.transitions)); ep=type(ep)(ep.transitions[:total-1]+(ep.transitions[total-1],),ep.episode_id)
    # If the slice is not terminal, force use the full natural episode instead.
    if not ep.transitions[-1].done: ep=eps[0]
    train_steps=min(2,len(ep.transitions)-1); burn=1
    batch=build_recurrent_bc_batch([ep],ten,1,train_steps,burn,random.Random(0))
    # First decision in a sampled window may start mid-episode, but current-step
    # opponent action must never be fed into the same action prediction.
    # Wherever two consecutive source steps are present, t uses t-1 opponent action.
    assert batch.loss_mask.shape[1]==1 and not bool(batch.loss_mask[0,0])
    # Verify at least the post-burn-in input is a legal encoded historical kind.
    assert int(batch.prev_opp_actions[burn].kind[0]) in (OPP_PASS,OPP_PLAY_CARD,OPP_ABILITY)


def test_episode_start_never_leaks_current_opponent_action():
    eps,ten,vocab=_episode_and_tensorizer(); ep=eps[0]
    # Build a full-window batch beginning at zero by asking for its exact length.
    batch=build_recurrent_bc_batch([ep],ten,1,len(ep.transitions),0,random.Random(1))
    assert int(batch.prev_opp_actions[0].kind[0])==OPP_PASS
    assert not bool(batch.prev_opp_known[0,0])
    # Step 1 sees step-0 opponent action, not step-1.
    k0,c0,t0=encode_observed_action(ep.transitions[0].opponent_action,ten.vocab)
    assert (int(batch.prev_opp_actions[1].kind[0]),int(batch.prev_opp_actions[1].card_token[0]),int(batch.prev_opp_actions[1].tile[0]))==(k0,c0,t0)


def test_opponent_ability_is_not_collapsed_into_pass():
    eps,ten,vocab=_episode_and_tensorizer()
    card_id=eps[0].transitions[0].state.hand[0].card_id
    a=ObservedOpponentActionV1.activate_ability(card_id)
    kind,card,tile=encode_observed_action(a,vocab)
    assert kind==OPP_ABILITY and tile==PASS_TILE and card!=0
    net=CRGodV2Net(vocab.size); s=ten.batch([eps[0].transitions[0].state]); z=net.encoder(s); h=net.initial_belief(1)
    from crgod.opponent_codec import OpponentActionBatch
    known=torch.ones(1,dtype=torch.bool); dt=torch.ones(1); own=torch.zeros(1,dtype=torch.long)
    ability=OpponentActionBatch(torch.tensor([OPP_ABILITY]),torch.tensor([card]),torch.tensor([PASS_TILE]))
    passed=OpponentActionBatch.pass_batch(1)
    ha=net.belief.step(z,own,ability,known,dt,h).hidden
    hp=net.belief.step(z,own,passed,known,dt,h).hidden
    assert not torch.allclose(ha,hp)


def test_jsonl_replay_roundtrip_preserves_episode_and_ability(tmp_path):
    eps,ten,vocab=_episode_and_tensorizer(); path=tmp_path/'r.jsonl'
    save_jsonl(eps,path); got=load_jsonl(path)
    assert len(got)==len(eps) and len(got[0].transitions)==len(eps[0].transitions)
    assert got[0].transitions[0].action.kind==eps[0].transitions[0].action.kind


def test_supervisor_rolls_back_on_persistent_real_eval_regression():
    sup=TrainingSupervisor(min_eval_games=60,patience=2,max_regression=.03)
    e=sup.observe(TrainingSnapshot(100,.60,.50,0,.01,.8,100)); assert e.decision==Decision.KEEP_BEST
    e=sup.observe(TrainingSnapshot(200,.55,.49,0,.01,.8,100)); assert e.decision==Decision.CONTINUE
    e=sup.observe(TrainingSnapshot(300,.54,.48,0,.01,.8,100)); assert e.decision==Decision.ROLLBACK
    e=sup.observe(TrainingSnapshot(400,.62,.52,0,.2,.8,100)); assert e.decision==Decision.ROLLBACK


def test_paired_ab_gate_requires_signal_and_checks_worst_archetype():
    rows=[]
    for i in range(120):
        # Candidate strictly better in 80/120, tie in 40/120.
        rows.append(PairedOutcome(.0,1.0,i,'cycle' if i%2==0 else 'control') if i<80 else PairedOutcome(.5,.5,i,'cycle' if i%2==0 else 'control'))
    r=paired_ab_gate(rows,min_pairs=100,min_delta=.1,alpha=.05)
    assert r.passed and r.sign_test_p<.05 and r.mean_delta>.6


def test_hasty_runtime_audit_catches_live_codec_contract(tmp_path):
    root=tmp_path/'hasty'; (root/'sim').mkdir(parents=True); (root/'sim'/'__init__.py').write_text('')
    (root/'sim'/'env.py').write_text(textwrap.dedent('''
        import numpy as np
        GRID_W,GRID_H=18,32
        TILES=576; CARD_ACTIONS=2305; ABILITY_SLOTS=16; ACTIONS=2321; DECIDE_EVERY_MS=500
        class ClashEnv:
            def __init__(self,seed=0,**kw): self.seed=seed; self.t=0
            @staticmethod
            def decode(a):
                if a<=0:return None
                if a>=CARD_ACTIONS:return ('ability',a-CARD_ACTIONS)
                z=a-1; slot,cell=divmod(z,TILES); y,x=divmod(cell,GRID_W); return slot,x,y
            @staticmethod
            def encode(slot,x,y): return 1+slot*TILES+y*GRID_W+x
            @staticmethod
            def encode_ability(rank): return CARD_ACTIONS+rank
            def reset(self,seed=None):
                if seed is not None:self.seed=seed
                self.t=0; return {'planes':np.zeros((8,32,18),np.float32),'scalars':np.zeros(47,np.float32)},{'action_mask':np.ones(ACTIONS,dtype=bool)}
            def step(self,a):
                self.t+=1; return {'planes':np.zeros((8,32,18),np.float32),'scalars':np.zeros(47,np.float32)},0.0,False,False,{'action_mask':np.ones(ACTIONS,dtype=bool)}
    '''))
    # ensure the dynamic import points to this fixture, not a stale module
    for k in list(sys.modules):
        if k=='sim' or k.startswith('sim.'): del sys.modules[k]
    from crgod.adapters.hasty import HastyRuntime
    r=HastyRuntime(root).audit(); assert r.ok and r.full_codec_ok and r.deterministic_pass_probe_ok
