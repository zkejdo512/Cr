import torch
import pytest

from crgod.contracts import (
    TrueBattleStateV1, TowerState, CardRef, to_player_observation,
)
from crgod.data import discounted_return_targets
from crgod.training.ppo_v2 import compute_gae
from crgod.training.rollout_v22 import collect_complete_episode
from tests.test_v22_integration import ToyAdapter, _toy_stack


def _state_for_projection():
    own=(
        TowerState('self','left',100,True,.2,.1),
        TowerState('self','right',100,True,.8,.1),
        TowerState('self','king',100,True,.5,.05),
    )
    opp=(
        TowerState('opponent','left',100,True,.2,.9),
        TowerState('opponent','right',100,True,.8,.9),
        TowerState('opponent','king',100,True,.5,.95),
    )
    hand=tuple(CardRef(i) for i in range(4))
    ohand=tuple(CardRef(i+10) for i in range(4))
    return TrueBattleStateV1('1.0',0.0,5,5,own,opp,hand,None,ohand,None)


def test_opponent_canonical_rotation_swaps_left_right_lane_labels():
    obs=to_player_observation(_state_for_projection(),'opponent')
    by_lane={t.lane:t for t in obs.own_towers}
    assert by_lane['right'].x == pytest.approx(.8)  # original opponent-left rotates to screen-right
    assert by_lane['left'].x == pytest.approx(.2)   # original opponent-right rotates to screen-left


def test_ppo_collector_rejects_deterministic_argmax_collection():
    _,ten,net=_toy_stack()
    with pytest.raises(ValueError, match='evaluation-only'):
        collect_complete_episode(ToyAdapter(horizon=3,seed=1),net,ten,seed=1,deterministic=True,max_steps=10)


def test_time_aware_discounted_returns_change_with_transition_duration():
    from crgod.data import collect_toy_expert
    from dataclasses import replace
    data=collect_toy_expert(1,seed=2)
    tr0=data[0]
    # Keep same reward but double state->next_state duration.
    ns=replace(tr0.next_state,t_s=tr0.state.t_s+1.0)
    long=replace(tr0,next_state=ns,done=True,reward=1.0)
    short=replace(tr0,next_state=replace(tr0.next_state,t_s=tr0.state.t_s+.5),done=True,reward=1.0)
    # Terminal one-step reward itself is unchanged regardless of duration.
    assert discounted_return_targets([short]) == discounted_return_targets([long]) == [1.0]

    # For a preceding reward, the duration of that transition changes how much future reward is worth.
    s1=replace(short,done=False,reward=0.0)
    s2=replace(short,state=s1.next_state,next_state=replace(short.next_state,t_s=s1.next_state.t_s+.5),done=True,reward=1.0)
    l1=replace(s1,next_state=replace(s1.next_state,t_s=s1.state.t_s+1.0))
    l2=replace(s2,state=l1.next_state,next_state=replace(s2.next_state,t_s=l1.next_state.t_s+.5))
    rs=discounted_return_targets([s1,s2],gamma=.9,base_dt_s=.5)
    rl=discounted_return_targets([l1,l2],gamma=.9,base_dt_s=.5)
    assert rs[0] == pytest.approx(.9)
    assert rl[0] == pytest.approx(.81)


def test_time_aware_gae_uses_duration():
    rewards=torch.tensor([[0.0],[1.0]])
    values=torch.zeros_like(rewards)
    dones=torch.tensor([[False],[True]])
    short=torch.tensor([[.5],[.5]])
    long=torch.tensor([[1.0],[.5]])
    a_short,_=compute_gae(rewards,values,dones,torch.zeros(1),gamma=.9,lam=1.0,transition_dt_s=short,base_dt_s=.5)
    a_long,_=compute_gae(rewards,values,dones,torch.zeros(1),gamma=.9,lam=1.0,transition_dt_s=long,base_dt_s=.5)
    assert float(a_short[0]) == pytest.approx(.9)
    assert float(a_long[0]) == pytest.approx(.81)

def test_hasty_adapter_refuses_to_silently_drop_multiple_opponent_actions():
    from crgod.adapters.hasty import HastyEnvAdapter
    class Proxy:
        calls=2
        last_result=None
    a=object.__new__(HastyEnvAdapter)
    a._proxy=Proxy()
    with pytest.raises(RuntimeError, match='acted 2 times'):
        a._opponent_action()
