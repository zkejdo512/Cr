from dataclasses import replace
import torch
import pytest

from crgod.action_codec import (
    NUM_ACTIONS, NUM_CARD_ACTIONS, NUM_ABILITY_ACTIONS, ABILITY_BASE,
    encode_action, decode_action,
)
from crgod.contracts import (
    ActionV2, ObservedOpponentActionV1, TrueBattleStateV1,
    to_player_observation, CardRef, TowerState,
)
from crgod.data import build_card_vocab, collect_toy_expert, discounted_return_targets, sample_transition_batch
from crgod.envs.toy_duel import ToyDuelEnv, ToyConfig
from crgod.models.crgod import CRGodNet
from crgod.models.opponent import OpponentModel
from crgod.models.world_ensemble import WorldModelEnsemble
from crgod.rules import tiebreak_compare, tiebreak_min_absolute_hp
from crgod.tensorizer import BattleTensorizer
from crgod.training.bc import bc_step
from crgod.training.world import world_ensemble_step
from crgod.vocab import CardVocabulary, UNK_TOKEN
from crgod.adapters.base import HastyParitySpec


def setup():
    d = collect_toy_expert(4)
    v = build_card_vocab(d)
    return d, v, BattleTensorizer(v, 8, 8)


def test_real_card_ids_do_not_alias():
    v = CardVocabulary.from_card_ids([26000000, 26000001, 28000017])
    assert len({v.encode(26000000), v.encode(26000001), v.encode(28000017)}) == 3
    assert v.encode(999) == UNK_TOKEN


def test_action_space_matches_hasty_2321_and_roundtrips():
    assert NUM_CARD_ACTIONS == 2305
    assert NUM_ABILITY_ACTIONS == 16
    assert NUM_ACTIONS == 2321
    for s in range(4):
        for x, y in [(0, 0), (.5, .5), (1, 1)]:
            a = ActionV2.play_card(s, x, y)
            assert encode_action(decode_action(encode_action(a))) == encode_action(a)
    for ability in (0, 7, 15):
        a = ActionV2.activate_ability(ability)
        idx = encode_action(a)
        assert idx == ABILITY_BASE + ability
        assert decode_action(idx) == a


def test_hasty_parity_counts_fail_closed():
    spec = HastyParitySpec()
    spec.validate_counts(2321, 2305, 16)
    with pytest.raises(RuntimeError):
        spec.validate_counts(2305, 2305, 0)


def test_true_state_projection_hides_opponent_private_info():
    env = ToyDuelEnv(ToyConfig(10, 1))
    true = env.true_state()
    obs = to_player_observation(true, 'self')
    assert not hasattr(obs, 'opponent_elixir')
    assert not hasattr(obs, 'opponent_hand')
    assert [c.card_id for c in obs.hand] == [0, 1, 2, 3]
    assert 100 not in [c.card_id for c in obs.hand]


def test_tensorizer_rejects_privileged_true_state():
    env = ToyDuelEnv(ToyConfig(10, 1))
    data = collect_toy_expert(1)
    vocab = build_card_vocab(data)
    ten = BattleTensorizer(vocab, 8, 8)
    with pytest.raises(TypeError):
        ten.one(env.true_state())


def test_toy_expert_no_hidden_peek():
    a = ToyDuelEnv(ToyConfig(60, 1)); a.reset(0); x = a.expert_action()
    b = ToyDuelEnv(ToyConfig(60, 1)); b.reset(1)
    assert x == b.expert_action()


def test_masks_and_shapes_include_ability_actions_but_toy_keeps_them_illegal():
    d, v, t = setup(); b = sample_transition_batch(d, t, 8); n = CRGodNet(v.size)
    z, l, val = n(b.state, legal_mask=b.legal_mask)
    assert z.shape == (8, 256) and l.shape == (8, NUM_ACTIONS)
    assert torch.all(l[~b.legal_mask] < -1e8)
    assert not bool(b.legal_mask[:, ABILITY_BASE:].any())
    o = OpponentModel(v.size); p = o.predict(z, o.initial(8)); assert p.card_logits.shape == (8, v.size)
    w = WorldModelEnsemble(3, card_vocab_size=v.size)
    zn, r, c, lm, u = w.conservative_prediction(z, b.own_action, b.opp_action, b.dt_s)
    assert zn.shape == z.shape and lm.shape == (8, NUM_ACTIONS)


def test_critic_trains_and_unknown_opp_is_skipped():
    d, v, t = setup(); ret = discounted_return_targets(d)
    b = sample_transition_batch(d, t, 16, return_targets=ret); n = CRGodNet(v.size)
    opt = torch.optim.Adam(n.parameters(), lr=1e-3)
    before = [p.detach().clone() for p in n.head.value_out.parameters()]
    m = bc_step(n, b.state, b.own_action, opt, b.legal_mask, b.return_target)
    assert m.loss == m.loss
    assert any(not torch.equal(x, y.detach()) for x, y in zip(before, n.head.value_out.parameters()))
    du = [replace(x, opponent_action=ObservedOpponentActionV1(None, None, None), opponent_action_known=False) for x in d]
    bu = sample_transition_batch(du, t, 8); w = WorldModelEnsemble(2, card_vocab_size=v.size)
    wo = torch.optim.Adam(w.parameters(), lr=1e-3); params = [p.detach().clone() for p in w.parameters()]
    wm = world_ensemble_step(n.encoder, w, bu.state, bu.next_state, bu.own_action, bu.opp_action,
                             bu.reward, bu.done, bu.dt_s, bu.opp_action_known,
                             bu.next_legal_mask, bu.next_legal_mask_known, wo)
    assert wm.skipped and all(torch.equal(a, p.detach()) for a, p in zip(params, w.parameters()))


def test_tensor_inputs_bounded():
    d, v, t = setup(); x = t.one(d[0].state)
    assert x.global_features.shape == (1, 21)
    assert float(x.global_features.abs().max()) <= 1.5


def _tower(team, lane, hp, max_hp):
    return TowerState(team, lane, hp, hp > 0, 0.0, 0.0, max_hp=max_hp, active=True)


def test_tiebreak_uses_absolute_hp_and_includes_king():
    # Fractions would favor self (1000/2000=.5 vs 900/1000=.9 -> opponent),
    # but official-like absolute comparison is 1000 > 900 -> self.
    self_t = (_tower('self', 'left', 1000, 2000), _tower('self', 'right', 1500, 2000), _tower('self', 'king', 3000, 4000))
    opp_t = (_tower('opponent', 'left', 900, 1000), _tower('opponent', 'right', 1600, 2000), _tower('opponent', 'king', 3500, 4000))
    assert tiebreak_min_absolute_hp(self_t) == 1000
    assert tiebreak_min_absolute_hp(opp_t) == 900
    assert tiebreak_compare(self_t, opp_t) == 1
    # king tower must participate if it is the lowest surviving crown tower.
    self_low_king = (_tower('self', 'left', 1200, 2000), _tower('self', 'right', 1300, 2000), _tower('self', 'king', 700, 4000))
    assert tiebreak_min_absolute_hp(self_low_king) == 700


def test_deck_validation_blocks_incomplete_second_deck():
    from crgod.decks import DeckSpec
    DeckSpec('ok', tuple(range(8))).validate()
    with pytest.raises(ValueError):
        DeckSpec('incomplete', (1, 2, 3)).validate()


def test_mechanics_gate_blocks_uncalibrated_paid_training():
    from crgod.mechanics_gates import MechanicsCalibrationReport
    report = MechanicsCalibrationReport()
    blockers = report.blockers()
    assert any('king activation' in x for x in blockers)
    assert any('spell timing' in x for x in blockers)
    with pytest.raises(RuntimeError):
        report.assert_paid_training_ready()


def test_masked_ppo_never_samples_illegal_ability_and_updates():
    from crgod.training.ppo import sample_masked_action, ppo_step
    d, v, t = setup(); b = sample_transition_batch(d, t, 16); net = CRGodNet(v.size)
    with torch.no_grad():
        z = net.encoder(b.state)
    ctx = torch.zeros(z.shape[0], net.head.context_dim)
    with torch.no_grad():
        actions, old_lp, values = sample_masked_action(net.head, z, ctx, b.legal_mask)
    rows = torch.arange(actions.shape[0])
    assert bool(b.legal_mask[rows, actions].all())
    assert bool((actions < ABILITY_BASE).all())
    opt = torch.optim.Adam(net.head.parameters(), lr=1e-4)
    advantages = torch.linspace(-1, 1, actions.shape[0])
    returns = values.detach() + advantages * .1
    m = ppo_step(net.head, z.detach(), ctx, b.legal_mask, actions, old_lp,
                 advantages, returns, opt)
    assert all(torch.isfinite(torch.tensor(x)) for x in [m.loss, m.policy_loss, m.value_loss, m.entropy, m.approx_kl])


def test_opponent_observation_is_rotated_into_bottom_frame():
    from crgod.contracts import EntityState, DeploymentEvent
    env = ToyDuelEnv(ToyConfig(10, 1))
    ts = env.true_state()
    ts = replace(ts,
        entities=(EntityState(7, 'self', 42, 'troop', .2, .3, 10, 20, .4, -.6),),
        recent_events=(DeploymentEvent(0, 'self', 42, .1, .9),))
    obs = to_player_observation(ts, 'opponent')
    e = obs.entities[0]
    assert e.team == 'opponent'
    assert e.x == pytest.approx(.8) and e.y == pytest.approx(.7)
    assert e.vx == pytest.approx(-.4) and e.vy == pytest.approx(.6)
    ev = obs.recent_events[0]
    assert ev.team == 'opponent' and ev.x == pytest.approx(.9) and ev.y == pytest.approx(.1)


def test_unknown_legal_mask_fails_closed_to_pass_only():
    from crgod.data import _mask_from_indices
    mask, known = _mask_from_indices(None)
    assert not known
    assert bool(mask[0]) and int(mask.sum()) == 1
