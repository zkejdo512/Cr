# v2 controlled experiment plan

Do not compare architectures with different data or evaluation budgets.

## Baselines

A. v1.2 behavior clone only

B. v1.2 behavior clone -> masked PPO

C. v2 hierarchical + recurrent belief -> recurrent masked PPO

D. C + PFSP-style league

E. D + adaptive slow planner at inference

F. Optional: D/E + learned world-model auxiliary/imagination

## Fixed controls

- same expert replay split
- same supported deck(s)
- same Hasty commit and simulator calibration
- same number of simulator transitions for training comparisons
- same held-out seeds and opponent pool
- at least per-archetype reporting; never rely on aggregate win rate alone

## Report

- win rate + 95% interval
- worst-archetype win rate
- crown differential
- tower-damage differential
- illegal-action rate
- opponent-elixir MAE
- next-card / hand-belief accuracy where ground truth is available
- prediction-spell hit rate
- slow-planner usage rate and uplift vs fast action
- wall-clock training/inference cost
- sim-to-real divergence metrics

World-model variants survive only if they improve sample efficiency or held-out performance at matched cost.
