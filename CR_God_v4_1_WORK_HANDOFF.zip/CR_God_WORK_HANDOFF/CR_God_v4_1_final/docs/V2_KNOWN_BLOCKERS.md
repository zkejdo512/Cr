# Known blockers before paid long training

The code in this package is a tested research prototype, not proof of a strong Clash Royale agent.

Hard blockers:

1. Hasty dynamic observation/action parity fixtures are not bundled because the exact upstream checkout is not pinned here.
2. Real-match mechanics calibration is still required for King activation, pocket deployment, spell timing, pathing, collision/pull.
3. A production card vocabulary must be built from the complete supported card registry, not only cards observed in replay samples.
4. Real expert replay loader + chronological recurrent sequence builder are not yet connected.
5. The PFSP league scaffold does not yet launch distributed self-play workers/checkpoint lifecycle automatically.
6. Slow planning needs a pinned simulator snapshot/restore callback; the planner boundary exists but Hasty rollout integration is not filled in.
7. Belief auxiliary heads need real labels/reconstructed truth and calibration metrics before they should influence high-stakes planning.
8. No real-game result is claimed by the toy smoke tests.

Paid training remains blocked until `V2ReadinessReport` and `MechanicsCalibrationReport` are populated from real evidence.
