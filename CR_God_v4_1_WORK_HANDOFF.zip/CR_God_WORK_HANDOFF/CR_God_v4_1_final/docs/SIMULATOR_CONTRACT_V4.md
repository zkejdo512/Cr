# CR-God Simulator Contract v4

The simulator is an external dependency. CR-God training must not import its internal physics classes.

Implement `crgod.sim_protocol.TrainingSimulator`:

```python
class MySimulator:
    simulator_id = "my-cr-sim@<immutable-fingerprint>"
    decision_interval_s = 0.5

    def reset(self, *, seed=None, matchup=None) -> JointFrame:
        ...

    def step(self, action_a_index: int, action_b_index: int) -> JointStepResult:
        ...
```

## Observation boundary

`reset()` and every `step()` return a `JointFrame` with one `SeatFrame` per player.

Every seat must receive a `PlayerObservationV1`, canonicalized as **"I am bottom"**. Never place opponent-private hand, next-card or elixir information in a policy observation.

`JointFrame.privileged_state` may contain `TrueBattleStateV1` for:

- belief auxiliary labels;
- calibration;
- diagnostics.

It is not a policy input.

## Canonical action space

Training sees exactly 2321 action indices:

```text
0             pass
1..2304       4 hand slots × 18×32 deployment grid
2305..2320    16 ability slots
```

Every legal-action set must:

- be non-empty;
- contain action 0 (`pass`);
- contain no duplicates;
- stay inside `[0, 2320]`.

The simulator maps canonical indices into its own engine representation.

## Causality

Both players choose from the same decision frame.

The action taken during interval `t` may become the other player's recurrent input only at decision `t+1` if it was observable. Do not expose the opponent's current action before the player has committed its own current action.

`JointStepResult` therefore reports:

- `action_a_observed_by_b`;
- `action_b_observed_by_a`;
- corresponding `*_known_*` flags.

Unknown is not the same thing as pass.

## Time

`elapsed_s` is mandatory and positive.

The next frame's clock must satisfy, up to numerical tolerance:

```text
next_frame.t_s - current_frame.t_s == elapsed_s
```

Training uses elapsed simulated time for GAE/V-trace discounting. A clock mismatch silently changes the effective planning horizon and is therefore a hard failure.

## Terminal objective

On a terminal transition:

- `done=True`;
- `outcome_a` must be supplied as `1.0 / 0.5 / 0.0` for win/draw/loss.

Scalar rewards may include training shaping, but promotion/evaluation must use the true terminal outcome.

## Reward components

If provided, `RewardComponents` may contain dense aids such as tower damage or tactical terms. CR-God guards and anneals those components. They must not replace the match objective.

## Optional privileged labels

If `privileged_state` is provided, it may supervise hidden-hand/elixir belief heads during training. The policy tensorizer only accepts `PlayerObservationV1`; accidental TrueState policy input is a type error.

## Optional planner snapshots

Fast/Slow planning may additionally implement `SnapshotSimulator`:

```python
snapshot = sim.snapshot()
sim.restore(snapshot)
```

Snapshot/restore must be deterministic. BC/PPO/league training does not require it.

## Required preflight

After exposing a simulator factory, run:

```bash
python scripts/preflight_simulator_v4.py \
  --factory your_package.integration:make_training_simulator \
  --episodes 8 --max-steps 2000
```

Then run at least one recurrent on-policy rollout + PPO smoke with zero illegal actions before paid training.

The black-box preflight catches interface/time/numerical bugs. It cannot establish that card mechanics, collision, pathing or spell timing match real Clash Royale; those require separate simulator calibration.
