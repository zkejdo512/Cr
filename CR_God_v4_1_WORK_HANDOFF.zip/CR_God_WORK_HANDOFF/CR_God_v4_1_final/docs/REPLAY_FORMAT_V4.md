# CR-God v4 replay format

The current JSONL schema identifier remains `crgod.replay.v2.1` for backward compatibility. v4 adds an **optional** `privileged_state` sidecar to each step.

A normal real-player replay row may contain only:

```json
{
  "schema": "crgod.replay.v2.1",
  "episode_id": "match-123",
  "step": 0,
  "transition": { "...": "PlayerObservation/action transition" }
}
```

A simulator / memory-ground-truth replay may additionally contain:

```json
{
  "schema": "crgod.replay.v2.1",
  "episode_id": "match-123",
  "step": 0,
  "transition": { "...": "same policy-visible transition" },
  "privileged_state": { "...": "TrueBattleStateV1 aligned to this decision" }
}
```

Rules:

- privileged state must be present for **all or none** of an episode;
- its timestamp must equal the policy-visible state's timestamp;
- it never becomes policy input;
- it is used only to produce opponent-hand/elixir/next-card belief labels;
- if no privileged state exists, recurrent BC still trains normally without those auxiliary labels;
- card vocabularies must cover hidden cards before privileged belief training begins.

Use `scripts/train_recurrent_bc_v4.py` for the v4 BC entry point. It performs a chronological episode split and restores the **best validation checkpoint** before evaluating the untouched test partition.
