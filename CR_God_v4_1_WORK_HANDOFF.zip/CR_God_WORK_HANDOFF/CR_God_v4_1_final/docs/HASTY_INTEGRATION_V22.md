# Hasty integration contract — CR-God v2.2

1. Pin an exact Hasty-CR commit. A moving `main` branch is not a training dependency.
2. Apply the required patches in `patches/` to that exact checkout and commit/vendor the patched state separately.
3. Run:

```bash
python scripts/audit_hasty_repo.py /path/to/Hasty-CR
python scripts/hasty_ppo_smoke.py --hasty-root /path/to/Hasty-CR --expected-commit <sha>
```

4. The dynamic runtime audit exhaustively checks all 2321 canonical action indices, reset/mask shape, 500 ms decision interval and same-seed pass determinism.
5. `HastyEnvAdapter` projects privileged Match state into `PlayerObservationV1`; the policy never accepts `TrueBattleStateV1`.
6. Project release numbers such as 2.2 are **not** observation schema versions. The current observation contract is `OBSERVATION_SCHEMA_VERSION` from `crgod/contracts.py`.
7. Playable-card vocabulary and battlefield-entity vocabulary are separate. A checkpoint must load with exactly matching fingerprints.
8. Opponent action in decision `t` is the action observed during interval `t-1`. Current simultaneous opponent action must never enter the current policy input.
9. The short Hasty PPO smoke is integration evidence only. It is not evidence of skill.
10. Paid training additionally requires a passing real mechanics calibration report and paired held-out A/B evidence.
