# CR-God v4.1 Frozen Training Release

This is the training-side freeze intended for the first real simulator-coupled experiments.
It does not claim that any external simulator is physically accurate; it is designed to fail
closed when the training boundary is inconsistent.

## Mandatory launch order

1. `preflight_release_v4.py`
2. recurrent BC checkpoint exists and its vocab/runtime contract matches the live simulator
3. short synchronous `train_ppo_v4.py` run
4. `eval_ab_v4.py` with at least 100 fresh paired seed/seat-swap comparisons
5. only promote to longer PPO / league if the A/B gate passes

## Safety properties in the freeze

- policy never accepts privileged `TrueBattleStateV1`
- explicit 2321-action contract with fail-closed legal masking
- actor snapshots cannot silently alias learner weights
- whole-match policy version remains frozen during synchronous PPO collection
- PPO bootstrap value is captured at rollout time from the frozen actor
- recurrent match state persists across unroll chunks
- variable decision duration is used in GAE/V-trace discounting
- terminal `outcome_a` is mandatory and never inferred from shaped reward
- checkpoint is bound to card/entity vocab fingerprints + simulator fingerprint
- failed PPO candidates do not overwrite the safe rollback checkpoint
- non-contiguous replay episode IDs are rejected before chronological splitting
- async V-trace path has bounded policy lag and recurrent burn-in
- dense reward is optional; when enabled, use the guarded/annealed mixer

## What still requires empirical validation

- simulator game-mechanic fidelity
- real Clash Royale perception / observation fidelity
- optimal hyperparameters for the final simulator
- whether hard-case curriculum, league exploiters, planner, or world-model additions improve
  the BC→PPO baseline. Each must survive controlled A/B before becoming part of a long run.
