# v1.2 audit against the reported simulator/training defects

| Issue | v1.2 status |
|---|---|
| Policy can see full opponent hand/queue | **Fixed in CR-God contract.** Hidden information is confined to `TrueBattleStateV1`; tensorizer rejects it. |
| King Tower activation | Current Hasty source has wake logic. CR-God now blocks paid training until real-match parity is explicitly marked verified. |
| Princess Tower destruction should expand deployment area | Current Hasty source routes legal placement through `deploy_area_ok` with fallen enemy towers. CR-God still requires real calibration before paid training. |
| Overtime/tiebreak simplified | **Known Hasty defect patched in `patches/hasty_match_tiebreak.patch`.** CR-God rule test uses lowest surviving Crown Tower absolute HP and includes King Tower. |
| Fireball/Log/Arrows timing too approximate | Not safe to invent constants. Added required spell-timing calibration evidence and hard paid-training gate. |
| Pathing approximation | Cannot be repaired honestly without simulator/real trajectory data. Added path-position calibration gate. |
| Collision/mass/pull calibration | Added collision/pull calibration gate; no paid run allowed with zero evidence. |
| Second deck only 3 cards | **Structurally blocked.** `DeckSpec.validate()` requires exactly 8 unique cards. No fake five cards are invented. |
| No PPO discrete action/legal mask | **Fixed at CR-God layer.** 2321-way masked discrete PPO update and sampling are implemented/tested. Full Hasty rollout collector still needs integration. |
| BoardState is god-view with no true/observation split | **Fixed.** Separate privileged true state and policy observation types; direct privileged tensorization raises. |

## Important limitation

A calibration gate is not the same as a calibrated simulator. v1.2 prevents us
from silently training on unverified mechanics; it does not claim Fireball,
pathing or collision are now physically correct.
