# CR-God Simulator Contract v3

The simulator is an external dependency. The training code must not depend on its internal physics classes.

Implement `crgod.sim_protocol.TrainingSimulator`:

```python
class MySimulator:
    simulator_id = "my-cr-sim@<commit>"
    decision_interval_s = 0.5

    def reset(self, *, seed=None, matchup=None) -> JointFrame:
        ...

    def step(self, action_a_index: int, action_b_index: int) -> JointStepResult:
        ...
```

## `reset()` requirements

Return a `JointFrame` containing two `SeatFrame`s. Each seat must already be canonicalized as **"I am bottom"**.

Each `SeatFrame` contains:

- `PlayerObservationV1`, never `TrueBattleStateV1`
- exact legal canonical action indices
- action `0` (pass) must always be legal

A privileged `TrueBattleStateV1` may be attached to `JointFrame.privileged_state` for auxiliary belief labels and calibration. The policy never receives it.

## Canonical action boundary

Training sees exactly 2321 actions:

- `0`: pass
- `1..2304`: 4 card slots × 18×32 deployment tiles
- `2305..2320`: 16 ability slots

The simulator is responsible for mapping these canonical actions to its internal representation.

## `step(a, b)` requirements

Both seats choose from the same decision frame. `step()` returns `JointStepResult` with:

- next canonical observation for both seats
- legal actions for the next frame
- scalar reward for each seat
- whether the match ended
- action A as it became observable to B
- action B as it became observable to A
- whether each opponent action was actually observable
- exact elapsed simulated seconds
- terminal outcome for A (`1 / .5 / 0`) when available
- optional decomposed reward components

**Causality rule:** the opponent action generated during interval `t` becomes recurrent input only for decision `t+1`. Do not put the current opponent action in the current observation.

## Time

`elapsed_s` is mandatory and positive. Training discounts use real elapsed simulated time, not an assumed fixed number of steps.

## Reward

The safest objective is terminal win/draw/loss. Optional dense components may be supplied as `RewardComponents`, but CR-God anneals their contribution toward zero during training.

## Optional planner support

For Fast/Slow search, additionally implement `SnapshotSimulator`:

```python
snapshot = sim.snapshot()
sim.restore(snapshot)
```

Snapshot/restore must be deterministic. This is optional for BC/PPO/V-trace/league training.

## Minimum integration test

```python
from crgod.sim_protocol import audit_training_simulator
frame = audit_training_simulator(sim, seed=123)
```

Then collect at least one unroll through `collect_joint_unroll()` and verify zero illegal actions before paid training.
