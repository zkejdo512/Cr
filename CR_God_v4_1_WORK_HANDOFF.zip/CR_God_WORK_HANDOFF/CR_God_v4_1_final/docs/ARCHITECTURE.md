# CR-God v1 architecture

## Principle

The policy never consumes raw Hasty state, memory-reader state, YOLO output, or privileged `TrueBattleStateV1`.
Simulator privileged data is normalized into `TrueBattleStateV1`; only `PlayerObservationV1` may reach the policy. This prevents a silent
sim-to-real schema mismatch from poisoning a long run.

## Learning stack

1. **Expert prior (behavior cloning)** — move the initial policy into a region of
   sensible CR play instead of spending compute discovering basic legality and
   timing from sparse win/loss reward.
2. **Known simulator physics** — deterministic CR mechanics stay in the game
   simulator rather than being needlessly re-learned by a neural network.
3. **Residual latent world model** — learns what the simulator/observation stack
   misses. It is conditioned on *both* agents' actions to avoid treating an
   opponent habit as physics.
4. **Opponent model** — recurrent hidden state predicts a particular opponent's
   future actions and can adapt online.
5. **Imagination actor-critic** — cheap short latent rollouts provide additional
   policy updates between expensive real/simulator trajectories.
6. **Checkpoint league** — historical opponents reduce single-opponent
   overfitting and cyclic strategy collapse.

## Important non-claims

`ResidualWorldModel` is Dreamer-inspired but is not a reproduction of
DreamerV3/V4. It is a deliberately smaller structured-state baseline suitable
for an A/B test before committing expensive compute.

The toy environment is only a pipeline test. Passing it does not demonstrate
Clash Royale strength.
