# CR-God v2.3 adversarial audit

This release exists because v2.2 passed its original 43 tests and still contained bugs that could corrupt self-play or real replay training. Passing unit tests is therefore treated as evidence of covered invariants, not proof of correctness.

## Newly fixed

1. **Opponent canonical lane identity** — a 180-degree rotation swapped tower coordinates but not `left`/`right` labels. Fixed and regression-tested.
2. **Multiple opponent actions per decision interval** — the Hasty logging proxy retained only the last callback result. The adapter now fails closed instead of silently dropping history. A future contract may explicitly support action lists.
3. **Deterministic PPO collection** — argmax action collection is now rejected by the PPO collector. Evaluation may be greedy; PPO behavior trajectories must be sampled from the stored behavior distribution.
4. **Variable decision durations** — BC return targets and PPO GAE now exponentiate gamma/lambda by transition duration relative to the 500 ms base interval.
5. **Source-audit bypass** — `HastyEnvAdapter` runs `source_audit()` by default.
6. **Entity vocabulary gate** — paid-training readiness now distinguishes card vocabulary from battlefield entity/species vocabulary.

## Still not proven

- no exact Hasty checkout was available in this build container, so real Hasty runtime/source preflight must still be run on the pinned checkout
- Hasty itself documents uncalibrated body-block magnitude, charging-unit deadlocks, live unit-HP blindness, and additional calibration approximations
- no trained CR-God checkpoint has been shown to beat a human
- mechanics fidelity, vision parity, real replay correctness and BC→PPO held-out A/B remain mandatory external gates
- the single-opponent-action transition contract intentionally fails if upstream Hasty produces multiple opponent decisions inside one 500 ms interval; supporting such intervals requires a sequence-valued opponent action contract rather than silently collapsing them

## Verification performed on packaged tree

- `python -m pytest -q` -> 48 passed
- legacy structural smoke -> pass
- v2 recurrent/hierarchical/planner smoke -> pass
- 20 toy episodes / 240 steps / 60 recurrent PPO chunk updates -> all reported metrics finite
