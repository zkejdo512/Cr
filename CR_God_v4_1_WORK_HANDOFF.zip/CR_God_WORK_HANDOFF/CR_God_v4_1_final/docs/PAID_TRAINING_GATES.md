# Paid-training gates

Do not start a multi-day paid GPU run until all gates below pass.

- **G0 — repository health:** unit tests green; deterministic seed fixtures.
- **G1 — BC:** expert holdout top-1/action-region accuracy improves and gameplay
  remains legal. Save a frozen BC checkpoint.
- **G2 — world model:** holdout next-latent/reward loss beats a no-change/no-reward
  baseline. Test separately across opponent types.
- **G3 — A/B:** same replay budget, compare BC-only, BC+model-free RL and
  BC+world-model imagination. Imagination must add value rather than merely lower
  its own training loss.
- **G4 — short real simulator RL:** <=300k steps; held-out opponents cannot be
  worse than frozen BC beyond confidence noise. Auto-stop on regression.
- **G5 — only now:** 1M+ / paid long run with periodic rollback checkpoints.

The first paid experiment should have a hard dollar/time cap and a frozen
baseline. A run that cannot beat its baseline early is stopped, not extended.
