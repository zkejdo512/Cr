# CR-God v2 architecture

v2 is an intelligence-architecture prototype layered on top of the v1.2 safety/correctness hardening.
It intentionally keeps the old v1 model available as a baseline.

## Online information flow

```text
PlayerObservationV1
        |
StructuredStateEncoder
        | z_t
        v
RecurrentBeliefModel <--- previous own action / observed opponent action / dt
        |
        +-- opponent elixir belief
        +-- opponent hand-presence belief
        +-- opponent next-card belief
        +-- opponent style embedding
        |
        v
HierarchicalPolicyValueHead
        |
        +-- pass
        +-- slot × spatial tile
        +-- ability action
        |
        v
Fast path: policy action
        |
        +---- when uncertain/critical ----> Slow planner
                                         top-K candidates
                                         external simulator rollouts
                                         risk/uncertainty adjusted value
```

`TrueBattleStateV1` is never accepted by the policy or `CRGodV2Agent`.
Privileged state is permitted only for simulator calibration and auxiliary belief targets.

## Why the action head changed

The canonical action space remains 2321 actions for Hasty parity, but the network no longer treats all
2304 placement actions as unrelated classes. Placement logit is factorized into card-slot preference +
a spatial score produced from continuous/Fourier tile coordinates. The result is flattened back into the
canonical codec only at the boundary.

## Why world model is no longer the main path

Known mechanics should come from the calibrated simulator/real engine. Learned dynamics remain available
as an optional auxiliary module for residual uncertainty / hidden-state research. v2 does not require the
world model to pass the first BC→PPO baseline.

## League

`PFSPLeague` tracks pairwise payoff estimates and favors opponents that currently challenge or beat the
main policy. Exploiters receive additional sampling weight. This is a compact PFSP-style research scaffold,
not a full reproduction of AlphaStar's production league.

## Sequence training

Expert replay can train the recurrent memory before RL through `recurrent_bc_step`. PPO uses the same recurrent belief path with truncated sequence batches and GAE support. This avoids waiting for RL to discover whether historical context matters.
