# CR-God v4 research rationale

v4 deliberately combines only the parts of large-scale game agents that map cleanly to Clash Royale.

## What we keep

- **AlphaStar:** supervised imitation as a strong prior, automated league training, historical policies, exploiters, and continued distillation to reduce forgetting. DeepMind explicitly reports that naive self-play can cycle/forget and that exploiters expose main-agent weaknesses.
- **OpenAI Five:** recurrent policies, semantically factorized action heads, self-play PPO, long credit-assignment horizons, and historical-opponent training. OpenAI reported annealing the reward half-life from ~46 seconds toward multiple minutes.
- **IMPALA / V-trace:** decoupled actors and learner with explicit off-policy correction when actor count grows.
- **R2D2 lessons:** recurrent state staleness is real; use stored hidden state plus burn-in/reconstruction for replayed recurrent chunks.
- **MuZero / Dreamer:** spend more inference compute only on important uncertain positions; if a learned model is tested, predict decision-relevant latent/value information rather than rebuilding every visual detail.
- **Agent57:** exploration and time horizon should be adaptive rather than assumed fixed. In CR-God we use a simpler hard-case curriculum and half-life schedule instead of copying Agent57's full intrinsic-reward stack.
- **Agent evaluation practice:** keep capability and regression suites separate, store trajectory-level traces, use repeated trials, and verify true environmental outcomes instead of trusting proxy metrics.

## What we intentionally do NOT copy yet

- Full DreamerV3 as the main learner: the project already has an external simulator, so relearning known game physics may waste samples and create exploitable model errors.
- Full Agent57 intrinsic motivation: Clash Royale already supplies an adversarial curriculum via a league; novelty reward can incentivize strategically useless weirdness.
- A giant language model in the real-time control loop: latency and reproducibility are more important for the 5-10 Hz action policy. Slow planning is simulator-based and optional.
- Unbounded reward shaping: dense rewards are annealed and guarded; terminal match outcome remains the objective.

## Primary references

- AlphaStar (DeepMind, 2019): https://deepmind.google/blog/alphastar-grandmaster-level-in-starcraft-ii-using-multi-agent-reinforcement-learning/
- OpenAI Five (OpenAI, 2018): https://openai.com/index/openai-five/
- IMPALA / V-trace: https://arxiv.org/abs/1802.01561
- DreamerV3: https://arxiv.org/abs/2301.04104
- MuZero (DeepMind, 2020): https://deepmind.google/blog/muzero-mastering-go-chess-shogi-and-atari-without-rules/
- Agent57 (DeepMind, 2020): https://deepmind.google/blog/agent57-outperforming-the-human-atari-benchmark/
- Invalid action masking: https://arxiv.org/abs/2006.14171
- Anthropic agent evals: https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents

## Why privileged centralized critics are not default

The simulator can expose true opponent hand/elixir during training, so a privileged state-only centralized critic is tempting. v4 does **not** enable it by default.

Recent analysis of centralized critics in partially observable multi-agent reinforcement learning shows that critic centralization is not automatically beneficial; state-only critics can introduce policy-gradient bias and can increase variance relative to history-based critics. For CR-God, the main critic therefore stays conditioned on the same recurrent history/belief representation used by the acting policy. Privileged state is used for explicit auxiliary belief targets instead, where information flow is easy to audit.

A history+state critic may still be tested later as a controlled A/B experiment, but it must not become mainline merely because the simulator makes private state available.

Reference:
- Lyu et al., *On Centralized Critics in Multi-Agent Reinforcement Learning* (2024 preprint / related JAIR analysis): https://arxiv.org/abs/2408.14597

## Additional v4 reliability decisions

- Rollout actors own frozen parameter snapshots. Learner mutation cannot silently change a behavior policy without incrementing `policy_version`.
- Async buffers reject both stale policies and impossible actor versions newer than the learner.
- Simulator time is audited against `elapsed_s`; discount horizons are invalid if those disagree.
- Hard-case mining changes the training distribution through bounded sampling, not by deleting broad-play coverage.
- Hidden evaluation suites are kept outside curriculum mining so the trainer cannot optimize directly against its final exam.
