# CR-God v3 training system

v3 intentionally separates **training intelligence** from simulator physics.

## Recommended progression

1. **Recurrent expert BC**
   - use full-match sequences, causal opponent history and burn-in
   - train policy/value plus privileged belief auxiliary heads
2. **Synchronous recurrent PPO**
   - preferred while actor count is small and exact on-policy collection is affordable
   - hard KL circuit breaker and automatic rollback
3. **League self-play**
   - main + historical snapshots + exploiters
   - keep expert-policy distillation as an anti-forgetting anchor
4. **Asynchronous V-trace actor/learner**
   - use only when rollout throughput requires actor/learner decoupling
   - hard maximum policy lag in `FreshUnrollBuffer`
5. **Fast/Slow planner distillation**
   - planner is an optional teacher in hard states
   - distill searched Q-distribution back into the fast policy
6. **World model experiment**
   - optional and must beat the simpler baseline under equal simulator interactions

## Why both PPO and V-trace?

PPO is easier to audit and should be the default. With many rollout workers, strict synchronous PPO can waste simulator throughput. V-trace corrects moderate actor-policy lag and gives a safer asynchronous path. Do not mix them on the same trajectory: exact-version unrolls go to PPO; lagged unrolls go to V-trace.

## Anti-forgetting

During RL, periodically sample expert sequences and run `recurrent_policy_distill_step()` against a frozen expert/BC teacher. The anchor coefficient should decay, not instantly disappear.

## Reward shaping

Dense reward is only a curriculum aid. `RewardMixer` linearly anneals dense tower/crown/elixir/tactical shaping toward zero while preserving the terminal outcome objective.

## League

PFSP prioritizes opponents that currently expose weaknesses. Preserve frozen historical snapshots. Add exploiters whose purpose is to break the main agent, not maximize average win rate.

## Paid training rule

Do not pay for a long run until:

- simulator contract passes
- recurrent BC improves held-out replay metrics
- short PPO run beats BC in paired evaluation
- rollback/checkpoint resume are proven
- no illegal actions
- league sampling is stable
- if asynchronous actors are used, policy lag stays inside the configured V-trace window

Planner and world model are optional add-ons and must win controlled A/B tests before becoming part of the mainline.
