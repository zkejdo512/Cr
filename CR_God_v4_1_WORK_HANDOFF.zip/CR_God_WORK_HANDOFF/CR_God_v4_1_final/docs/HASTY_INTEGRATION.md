# Hasty-CR integration contract — v1.2

This repository intentionally does not vendor Hasty-CR.

Before training:

1. Pin an exact upstream commit and save the commit hash in the experiment metadata.
2. Run `python scripts/audit_hasty_repo.py /path/to/Hasty-CR`.
3. Apply any required patches from `patches/` to that exact checkout.
4. Export at least 100 deterministic state/action fixtures from upstream.
5. Build bidirectional parity tests:
   - Hasty `observe(side)` -> `PlayerObservationV1` -> expected tensors
   - Hasty privileged match -> `TrueBattleStateV1` only for teacher/calibration targets
   - CR-God canonical action -> Hasty native action -> expected effect
6. Explicitly test pass, all 4 hand slots, arena corners, illegal tiles, 16 ability
   actions, card rotation, King activation, one/both Princess towers down, and reset.
7. Policy code must never receive `TrueBattleStateV1`.
8. Only after dynamic parity and mechanics calibration gates pass may the adapter
   be used for paid training.

Current CR-God canonical action layout deliberately matches the current Hasty
layout: 2305 card/hold actions + 16 ability actions = 2321. This numeric match
is necessary but not sufficient; semantic fixture parity is still mandatory.
