# CR-God v1.2 known blockers — paid long training is still blocked

Fixed/hardened in v1.2:

- privileged `TrueBattleState` vs non-cheating `PlayerObservation` split
- runtime rejection of privileged policy input
- full 2321 action schema including 16 ability buttons
- masked discrete PPO update primitive
- incomplete-deck rejection
- tiebreak rule helper + Hasty patch
- explicit mechanics calibration gate
- direct smoke script import reliability

Still blocking expensive training:

1. **No pinned dynamic Hasty parity fixtures yet.** Static action counts are not enough.
2. **The tiebreak patch must be applied/tested in the exact Hasty commit we train on.**
3. **King activation and pocket deployment need real-match parity evidence.** Current source has logic, but source presence is not calibration.
4. **Spell timing needs measured real-game samples.** Prediction spell play is especially sensitive.
5. **Pathing/collision/pull need trajectory-level calibration.** Otherwise RL may exploit simulator-only movement artifacts.
6. **Full BC→PPO environment runner is not wired to Hasty yet.** The PPO update is implemented; rollout integration is not.
7. **World model is still not a recurrent belief-state model/MARSSM.** Opponent hidden hand/elixir/cycle belief remains future work.
8. **No production replay loader / episode train-val-test split yet.**
9. **No checkpoint/resume/optimizer-state/NaN watchdog/metrics persistence yet.**
10. **No multi-step world-model holdout gate in the main training script yet.**
11. **League helper remains Elo-based, not PFSP/payoff-matrix aware.**
12. **No perception-noise/domain-randomization curriculum yet.**

Paid training should remain blocked until at least 1–6 and 8–10 have automated gates.
