# CR-God v2.2 — known blockers before paid long training

v2.2 closes several silent-failure paths, but **paid long training remains blocked**.

## Closed in v2.2

- Hasty adapter now emits the observation schema version, not the project release version.
- Policy tensors use separate playable-card and battlefield-entity vocabularies.
- Checkpoints bind observation schema, 2321-action contract, card-vocab fingerprint, entity-vocab fingerprint, and optionally the exact Hasty commit.
- Real replay JSONL is episode-safe; recurrent BC windows are causally shifted and burn-in aware.
- On-policy recurrent rollout collection stores the exact hidden state at chunk start and builds GAE/PPO chunks without leaking the current opponent action.
- Atomic checkpoint restore includes optimizer state.
- Hasty source audit explicitly checks tiebreak semantics and the full current ability-family enumeration.
- Structural smoke tests are separated from capability A/B gates; tiny toy skill variance can no longer masquerade as a release failure.

## Still blocking paid long training

1. **Exact Hasty checkout must be pinned and patched.** Current upstream `ability_entities()` only enumerates `ability_buff`, while `can_activate_ability()` supports many more ability families. Current upstream tiebreak also still compares Princess Tower HP fractions. Apply/audit patches on the exact commit used for training.
2. **Run `scripts/hasty_ppo_smoke.py` on that exact checkout.** This repository cannot certify a Hasty checkout it has never executed.
3. **Real mechanics calibration remains mandatory:** King activation, post-Princess pocket geometry, spell timing, pathing, body-block/collision/pull.
4. **Full entity registry is not yet extracted automatically from Hasty card data.** v2.2 separates the entity vocabulary so spawned forms no longer silently alias card UNK, but production training still needs a complete entity/species registry rather than an observed-only replay vocabulary.
5. **Real expert replay capture/ground-truth generation is external.** Loader, chronological split, recurrent trainer and evaluator are implemented; capture from real CR / memory truth is not bundled.
6. **Slow planner still needs Hasty snapshot/restore rollout integration.** The planner interface and traces exist, but a calibrated branching simulator callback is not wired.
7. **PFSP league is local bookkeeping, not a distributed worker/checkpoint service.**
8. **Opponent-belief calibration on real matches is not measured yet.** Hidden hand/elixir heads must be scored before the Slow Brain is allowed to rely heavily on them.
9. **Perception noise/domain randomization is not yet in the main curriculum.** Training only on exact simulator state risks a sim→vision gap.
10. **BC→PPO, recurrent PPO, League, Planner and optional World Model still need matched-budget paired A/B results on held-out seeds/opponents.** Complexity is not kept unless it beats the simpler baseline.
11. **No real-human win claim.** Simulator strength is not evidence of ladder strength.

Run `scripts/preflight_v22.py` before any paid job. It is intentionally fail-closed.
