# CR-God v4.1 — Frozen Hardened Training Core

CR-God v4 is the **training side only**. The Clash Royale simulator is developed separately and connects through a narrow, versioned two-player interface.

The default training line is intentionally conservative:

```text
expert / strong-player replays
        ↓
recurrent behavior cloning
+ privileged belief auxiliaries (training only)
        ↓
short synchronous recurrent PPO
        ↓
hard-case curriculum + PFSP league
+ historical opponents + targeted exploiters
        ↓
adaptive Fast/Slow planner (optional)
        ↓
planner corrections distilled back into Fast Policy
        ↓
V-trace actor/learner only when rollout scale requires it
        ↓
world-model experiment only after controlled A/B evidence
```

The project does **not** assume that a more complicated algorithm is better. Every optional layer must beat the previous system on the same held-out opponents/seeds before it is retained.

## v4 status

Current packaged-tree verification:

```text
87 pytest tests passed
v4 structural smoke: PASS
v4 learner benchmark: PASS
v3 PPO/V-trace regression smoke: PASS
black-box simulator audit: PASS on toy simulator
Python compileall: PASS
```

These checks validate the training machinery and failure guards. They do **not** prove that an external simulator matches real Clash Royale or that a trained policy is strong.

## What v4 changes

### 1. Multi-timescale recurrent belief

`CRGodV4Net` replaces one undifferentiated memory with:

- **fast recurrent memory** for short tactical context;
- **slow recurrent memory** for card-cycle / opponent-style context;
- a learned, initially conservative slow-memory update gate.

The policy still receives only `PlayerObservationV1`. Private opponent hand/elixir may appear in `TrueBattleStateV1` only as **auxiliary training labels**; it is never a policy input.

Relevant files:

```text
crgod/models/multiscale_belief.py
crgod/models/crgod_v4.py
```

### 2. Structured 2321-action policy

The public action contract remains stable:

```text
0             pass
1..2304       4 hand slots × 18 × 32 placement tiles
2305..2320    16 ability slots
= 2321 total
```

Internally, placement decisions use a hierarchical slot + spatial-map head instead of treating every tile as an unrelated class. Invalid-action masking is fail-closed and `pass` must always be legal.

### 3. Recurrent BC → recurrent PPO

The base learner is still simple enough to audit:

- recurrent behavior cloning with burn-in;
- optional critic-return targets;
- privileged hand/elixir belief auxiliaries;
- recurrent on-policy PPO;
- GAE with **real elapsed-time discounting**;
- clipped policy and clipped value updates;
- KL circuit breaker;
- actor policy snapshots so learner updates cannot silently change rollout weights.

The discount is configured by a human-readable **reward half-life schedule**, not by assuming a fixed effective horizon forever.

### 4. Hard-case curriculum without losing broad play

Failures are mined into `HardCaseBuffer`, but difficult samples never replace the broad self-play distribution completely.

The initial implementation exposed a failure mode where a single early archetype could collapse the buffer. v4 stores broadly and enforces diversity during sampling/eviction instead.

Relevant files:

```text
crgod/training/hardcase.py
crgod/training/curriculum_v4.py
```

### 5. League + automatic exploiters

League training keeps:

- Main agent;
- frozen historical snapshots;
- exploiters;
- PFSP-style opponent selection;
- targeted exploiter proposals from measured failure slices.

Exploiters are created from **observed weaknesses**, not hand-written claims about what should beat the agent.

### 6. Adaptive Fast/Slow inference

Ordinary states stay on the fast recurrent policy. High-uncertainty / high-stakes states may spend more simulator compute on candidate rollouts.

Planner budget depends on:

- policy entropy;
- top-action margin;
- value uncertainty;
- terminal urgency;
- archetype risk.

Meaningful planner overrides enter a correction buffer and can be distilled back into the fast policy. The goal is for Slow Brain use to **teach** Fast Brain rather than become a permanent latency tax.

### 7. Reward-hacking guards

Dense reward is optional, bounded and annealed toward zero. Terminal match outcome remains the final objective.

`GuardedRewardMixer` fails on non-finite or implausibly large components and caps dense reward per step. Promotion uses independent outcome evaluation rather than training reward.

### 8. Evaluation is now a first-class subsystem

v4 separates:

- capability suites;
- regression suites;
- hidden suites.

It stores match-level decision traces and checks:

- overall win rate;
- worst evaluation slice;
- catastrophic-blunder rate;
- belief error;
- planner gain;
- paired seat-swap evidence.

A candidate is not promoted merely because its aggregate win rate increased while one matchup collapsed.

### 9. Synchronous PPO first, V-trace only when needed

Use PPO while rollout throughput permits it. When many independent simulator actors make synchronization wasteful, switch to the existing V-trace actor/learner path.

The async path includes:

- bounded policy lag;
- rejection of impossible "future" actor versions;
- recurrent burn-in under learner weights;
- vectorized observation encoding;
- persistent match chunks.

Do not train the same trajectory with PPO and V-trace simultaneously.

## Simulator contract

The external simulator should implement:

```python
class MySimulator:
    simulator_id = "my-sim@<commit-or-fingerprint>"
    decision_interval_s = 0.5

    def reset(self, *, seed=None, matchup=None) -> JointFrame:
        ...

    def step(self, action_a_index: int, action_b_index: int) -> JointStepResult:
        ...
```

See:

```text
docs/SIMULATOR_CONTRACT_V4.md
crgod/sim_protocol.py
```

Each player's observation must already be canonicalized as **"I am bottom"**. `TrueBattleStateV1` is privileged training metadata and must never replace the player observation.

### Black-box simulator preflight

Once the other simulator project exposes a Python factory:

```bash
python scripts/preflight_simulator_v4.py \
  --factory your_package.integration:make_training_simulator \
  --episodes 8 \
  --max-steps 2000
```

The stress audit checks, among other things:

- stable simulator fingerprint;
- observation/action contract;
- legal-action masks;
- finite rewards/observations;
- monotonic simulator time;
- exact agreement between `elapsed_s` and clock advance;
- episode termination;
- terminal objective availability.

It cannot prove the simulator's game physics are accurate. Real-mechanics calibration remains an external requirement.

## Rollout actors are snapshots, not learner aliases

`RecurrentPolicyActor` now deep-copies the learner by default. This is deliberate.

If a rollout actor referenced the live learner object, `optimizer.step()` could silently change rollout weights while `policy_version` stayed unchanged, invalidating PPO/V-trace corrections.

Refresh explicitly between recurrent-state boundaries:

```python
actor.reset()
actor.sync_from(learner, policy_version=next_version)
```

A mid-memory sync fails unless the caller explicitly accepts resetting recurrent memory.

## Long matches and recurrent chunks

Do not reset the simulator every unroll:

```python
session = SelfPlaySession(sim, actor_a, actor_b)
session.reset(seed=123)

u1 = session.collect(unroll_length=96, burn_in_length=24)
u2 = session.collect(unroll_length=96, burn_in_length=24)
```

The match, action history and recurrent state persist across chunks.

## Default v4 configuration

See:

```text
configs/training_v4.yaml
```

Important defaults are **starting hypotheses, not claimed optimal CR hyperparameters**:

- fast belief 128 / slow belief 96;
- BC burn-in 24, learning length 96;
- PPO unroll 96;
- reward half-life approximately 45 s → 180 s over training;
- PPO clip 0.2, value clip 0.2;
- target KL 0.02, hard stop 0.06;
- hard-case sampling 10% → 45% peak → 25%;
- expert anchor 0.20 → 0.02;
- 20% historical league mix;
- adaptive planner top-K 4..16, rollout samples 1..8;
- dense shaping annealed out by 5M learner steps.

## Recommended experiment ladder

```text
A  recurrent BC
B  A + synchronous recurrent PPO
C  B + hard-case curriculum
D  C + PFSP historical league
E  D + targeted exploiters
F  E + adaptive planner + planner distillation
G  F + V-trace only if actor scaling requires it
H  optional world-model experiment
```

Every row must beat the previous row using the same held-out evaluation protocol. If a component does not produce a reproducible gain, remove it.


## Frozen release workflow (v4.1)

Use this exact order before spending on long training:

```bash
# 1) Prove the external simulator contract and checkpoint/device integration.
python scripts/preflight_release_v4.py \
  --sim-factory your_package.integration:make_training_simulator \
  --run-dir runs/bc_v4 \
  --checkpoint-name best \
  --device cuda

# 2) Run a conservative short synchronous PPO experiment.
python scripts/train_ppo_v4.py \
  --sim-factory your_package.integration:make_training_simulator \
  --init-run runs/bc_v4 \
  --out runs/ppo_v4_short \
  --updates 25 \
  --device cuda

# 3) Promotion test on fresh paired seeds + seat swaps.
python scripts/eval_ab_v4.py \
  --sim-factory your_package.integration:make_training_simulator \
  --candidate-run runs/ppo_v4_short \
  --baseline-run runs/bc_v4 \
  --pairs 100 \
  --device cuda
```

`train_ppo_v4.py` defaults to a deliberately conservative `1e-5` PPO learning
rate.  Increase it only after the KL/clip/eval traces show headroom.  The PPO
collector keeps one frozen policy snapshot for a complete match, stores the
rollout-time bootstrap value, and updates the learner only after collection.
A failed candidate can never overwrite the safe `best` rollback target.

Terminal match outcome is explicit and mandatory. Evaluation never infers a
win from dense/shaped reward. JSONL replay episodes must be contiguous so the
chronological train/validation/test split cannot silently reorder matches.

## Paid-training gate

Do not launch a multi-day run until all of these are true:

1. complete regression tests are green;
2. simulator contract and black-box stress audit pass;
3. card and battlefield-entity vocabularies cover the supported environment;
4. simulator/checkpoint runtime fingerprint is pinned;
5. recurrent BC smoke and held-out replay evaluation pass;
6. on-policy PPO smoke passes with zero illegal actions;
7. checkpoint + optimizer resume has been exercised;
8. long recurrent chunk stress passes;
9. paired BC-vs-PPO A/B baseline exists;
10. hidden evaluation league exists;
11. reward guard is enabled if dense shaping is used;
12. rollback supervisor is active;
13. V-trace policy lag/burn-in tests pass before async scaling.

The correct first paid experiment is a **short gated run**, not a 2–3 day blind run.

## Local verification

```bash
python -m pytest -q
python scripts/smoke_v4_training.py
python scripts/benchmark_v4_learner.py
python -m compileall -q crgod scripts
```

## Research decisions

Read:

```text
docs/RESEARCH_RATIONALE_V4.md
```

The short version is: v4 borrows imitation/league/exploiters from AlphaStar, recurrent PPO + long horizon ideas from OpenAI Five, asynchronous correction/burn-in lessons from IMPALA/R2D2, and selective planning ideas from MuZero/Dreamer. It deliberately **does not** make a learned world model, intrinsic novelty reward, large language model controller, or privileged state-only centralized critic part of the default training path.
