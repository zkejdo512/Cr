# CR-God v4.1 FINAL — Work Handoff

## Mission
Take over the CR-God training project and integrate it with the separately developed Clash Royale simulator. The training core is frozen at v4.1. Do not redesign the simulator physics inside this repository. Treat the simulator as an external dependency that must satisfy `docs/SIMULATOR_CONTRACT_V4.md`.

## What is already implemented
- Recurrent behavior cloning from expert replay.
- Multi-timescale recurrent belief state for hidden opponent information.
- Hierarchical 2321-action policy with legal-action masking.
- Synchronous recurrent PPO with time-aware GAE and rollback supervision.
- Optional asynchronous V-trace actor/learner path with burn-in and policy-lag control.
- PFSP-style league roles: main, historical, exploiters.
- Hard-case curriculum and failure-driven exploiter generation.
- Adaptive fast/slow planner hooks and planner-to-policy distillation.
- Reward guards, paired seed + seat-swap evaluation, hidden test evaluation hooks.
- Checkpoint/runtime/vocabulary fingerprints.
- Simulator black-box preflight and release preflight.
- Optional privileged training targets for belief supervision; policy input remains player-visible observation only.

## Frozen release
Version: `crgod 0.4.1`
Canonical action count: `2321`
Primary observation schema: see the contracts and `SIMULATOR_CONTRACT_V4.md`.

## First actions — do these in order
1. Read:
   - `README.md`
   - `docs/FINAL_RELEASE_V4_1.md`
   - `docs/FINAL_VERIFICATION_V4_1.txt`
   - `docs/SIMULATOR_CONTRACT_V4.md`
   - `docs/REPLAY_FORMAT_V4.md`
   - `docs/RESEARCH_RATIONALE_V4.md`
2. Install the project in an isolated environment.
3. Run the full test suite.
4. Connect the external simulator through a factory compatible with the simulator contract.
5. Run `scripts/preflight_simulator_v4.py` and `scripts/preflight_release_v4.py` before any paid training.
6. Produce expert replay in the v4 replay format and run recurrent BC.
7. Freeze the BC baseline.
8. Run only a short PPO experiment first.
9. Compare PPO vs BC using paired fresh seeds + seat swap.
10. Scale training only if the paired evaluation shows a real improvement without unacceptable worst-slice regression.

## Training progression
Use this order unless evidence from controlled A/B testing justifies a change:

Expert Replay -> Recurrent BC -> Short Recurrent PPO -> Paired A/B -> PFSP League -> Targeted Exploiters -> Adaptive Planner -> Planner Distillation -> optional V-trace scaling -> optional World Model A/B.

World-model training is not the default mainline. The external simulator is the primary source of game dynamics.

## Hard safety / correctness rules
- The policy must never receive opponent hidden hand, queue, elixir, or other privileged state.
- Privileged true state may only be used for auxiliary belief targets / training-only diagnostics.
- Do not infer win/loss from shaped reward. Terminal outcome must be explicit.
- Do not bypass legal-action masks.
- Keep whole episodes separated across train/validation/test splits.
- Do not mix checkpoint and vocabulary/runtime contracts; fingerprint mismatches must fail closed.
- Do not use stale actor hidden state after learner synchronization; recurrent burn-in/snapshot rules must be respected.
- Do not start a multi-day GPU run merely because loss decreases. Promotion is based on held-out paired match evaluation.

## Minimum promotion gate before long training
At minimum require:
- Simulator preflight PASS.
- Release preflight PASS.
- No NaN/Inf or illegal actions.
- Recurrent BC baseline reproducible.
- Short PPO does not collapse BC behavior.
- Candidate beats or credibly improves on BC in paired fresh-seed + seat-swap evaluation.
- Worst important matchup / archetype slices do not catastrophically regress.
- Checkpoint rollback path has been tested.

## Important integration note
The simulator is being developed separately. Do not assume Hasty-specific internals. Use `SIMULATOR_CONTRACT_V4.md` as the boundary. Hasty-related adapters/patches are legacy/reference material only unless the chosen simulator explicitly uses them.

## Recommended deliverables back to the user
When integration succeeds, return:
1. The exact simulator commit/fingerprint.
2. The exact CR-God checkpoint/runtime contract fingerprint.
3. Preflight logs.
4. BC training curves and held-out metrics.
5. Short PPO curves and supervisor decisions.
6. Paired BC-vs-PPO A/B results with seeds and seat swaps.
7. A list of simulator mismatches or suspected exploits discovered during training.
8. Only after that, a recommendation on whether to scale training.

## Current verified state
The frozen v4.1 source was reported as passing 87/87 tests plus structural PPO/V-trace/recurrent/checkpoint/evaluation smoke and release checks before packaging. Re-run all verification in the Work environment; do not assume environment-specific success carries over automatically.
